# collage downloads and LLM

## CORE4D

Official pages:

```text
https://core4d.github.io/
https://github.com/leolyliu/CORE4D-Instructions
https://huggingface.co/datasets/leolyliu/CORE4D
```

Download CORE4D:

```bash
python tools/download_official_data.py \
  --dataset core4d \
  --out-root /data
```

Download selected CORE4D motion folders:

```bash
python tools/download_official_data.py \
  --dataset core4d \
  --out-root /data \
  --allow-pattern 'CORE4D_Real_human_object_motions_v2/*' \
  --allow-pattern 'CORE4D_Synthetic_V1/*' \
  --allow-pattern 'CORE4D_Real/action_labels.json'
```

Hugging Face CLI:

```bash
hf download leolyliu/CORE4D \
  --repo-type dataset \
  --local-dir /data/CORE4D
```

## InterHuman

Official pages:

```text
https://tr3e.github.io/intergen-page/
https://github.com/tr3e/intergen
https://drive.google.com/drive/folders/1oyozJ4E7Sqgsr7Q747Na35tWo5CjNYk3?usp=sharing
```

Download InterHuman:

```bash
pip install gdown
python tools/download_official_data.py \
  --dataset interhuman \
  --out-root /data
```

Place the extracted dataset here:

```text
/data/InterHuman/
  annots/
  motions/
  motions_processed/
  split/
```

## LLM

Download the default local collage cue LLM:

```bash
python tools/download_llm.py \
  --model-id Qwen/Qwen2.5-7B-Instruct \
  --out-dir llm_models/qwen2_5_7b_instruct \
  --verify-tokenizer
```

Shell command:

```bash
bash scripts/download_llm_qwen.sh
```

Hugging Face CLI:

```bash
hf download Qwen/Qwen2.5-7B-Instruct \
  --local-dir llm_models/qwen2_5_7b_instruct
```

Authenticated download:

```bash
hf auth login
python tools/download_llm.py \
  --model-id meta-llama/Llama-2-7b-chat-hf \
  --out-dir llm_models/llama2_7b_chat \
  --token "$HF_TOKEN" \
  --verify-tokenizer
```

## Generate collage cue cache

Caption CSV:

```csv
motion_number,Description
2763,"Two humans are picking up the object together."
```

CORE4D cue cache:

```bash
python tools/generate_llm_cues.py \
  --input /data/collage_captions.csv \
  --output data/plans/core4d_llm_cues.jsonl \
  --model-path llm_models/qwen2_5_7b_instruct \
  --model-id Qwen/Qwen2.5-7B-Instruct \
  --levels 6 \
  --resume
```

InterHuman cue cache:

```bash
python tools/preprocess_interhuman.py \
  --config configs/interhuman_preprocess.yaml \
  --raw-root /data/InterHuman \
  --out-dir /data/collage_processed/interhuman

python tools/generate_llm_cues.py \
  --input /data/collage_processed/interhuman/metadata.jsonl \
  --output data/plans/interhuman_llm_cues.jsonl \
  --model-path llm_models/qwen2_5_7b_instruct \
  --model-id Qwen/Qwen2.5-7B-Instruct \
  --levels 6 \
  --resume
```

4-bit cue cache:

```bash
pip install bitsandbytes
python tools/generate_llm_cues.py \
  --input /data/collage_captions.csv \
  --output data/plans/core4d_llm_cues.jsonl \
  --model-path llm_models/qwen2_5_7b_instruct \
  --model-id Qwen/Qwen2.5-7B-Instruct \
  --levels 6 \
  --load-in-4bit \
  --resume
```

## Use cue cache

```bash
python tools/train_vqvae.py \
  --config configs/train_vqvae_core4d.yaml \
  --data-root /data/collage_processed/core4d \
  --stats-path /data/collage_processed/core4d/stats.npz \
  --plan-cache data/plans/core4d_llm_cues.jsonl

python tools/train_association.py \
  --config configs/train_assoc_core4d.yaml \
  --data-root /data/collage_processed/core4d \
  --stats-path /data/collage_processed/core4d/stats.npz \
  --vqvae-ckpt runs/core4d_vqvae/checkpoints/best.pt \
  --plan-cache data/plans/core4d_llm_cues.jsonl

python tools/train_diffusion.py \
  --config configs/train_diffusion_core4d.yaml \
  --data-root /data/collage_processed/core4d \
  --stats-path /data/collage_processed/core4d/stats.npz \
  --vqvae-ckpt runs/core4d_vqvae/checkpoints/best.pt \
  --assoc-ckpt runs/core4d_assoc/checkpoints/best.pt \
  --plan-cache data/plans/core4d_llm_cues.jsonl
```
