# collage cue cache

```bash
python tools/generate_llm_cues.py --input /data/collage_captions.csv --output data/plans/core4d_llm_cues.jsonl --model-path llm_models/qwen2_5_7b_instruct
```
