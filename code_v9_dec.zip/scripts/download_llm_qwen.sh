set -euo pipefail
export PYTHONPATH="$(pwd):${PYTHONPATH:-}"
MODEL_ID="${LLM_MODEL_ID:-Qwen/Qwen2.5-7B-Instruct}"
OUT_DIR="${LLM_DIR:-llm_models/qwen2_5_7b_instruct}"
python tools/download_llm.py --model-id "$MODEL_ID" --out-dir "$OUT_DIR" --verify-tokenizer
