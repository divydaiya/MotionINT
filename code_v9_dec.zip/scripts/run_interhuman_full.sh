set -euo pipefail
export PYTHONPATH="$(pwd):${PYTHONPATH:-}"

RAW_ROOT="${INTERHUMAN_ROOT:-/data/InterHuman}"
PROCESSED="${PROCESSED_ROOT:-/data/collage_processed/interhuman}"
LLM_MODEL_ID="${LLM_MODEL_ID:-Qwen/Qwen2.5-7B-Instruct}"
LLM_DIR="${LLM_DIR:-llm_models/qwen2_5_7b_instruct}"
PLAN_CACHE="${PLAN_CACHE:-data/plans/interhuman_llm_cues.jsonl}"
LLM_EXTRA_ARGS="${LLM_EXTRA_ARGS:-}"

if [ "${SKIP_LLM_DOWNLOAD:-0}" != "1" ]; then
  python tools/download_llm.py \
    --model-id "$LLM_MODEL_ID" \
    --out-dir "$LLM_DIR" \
    --verify-tokenizer
fi

python tools/preprocess_interhuman.py \
  --config configs/interhuman_preprocess.yaml \
  --raw-root "$RAW_ROOT" \
  --out-dir "$PROCESSED"

python tools/generate_llm_cues.py \
  --input "$PROCESSED/metadata.jsonl" \
  --output "$PLAN_CACHE" \
  --model-path "$LLM_DIR" \
  --model-id "$LLM_MODEL_ID" \
  --levels 6 \
  --resume \
  $LLM_EXTRA_ARGS

python tools/compute_stats.py --data-root "$PROCESSED" --out-path "$PROCESSED/stats.npz"
python tools/train_vqvae.py --config configs/train_vqvae_interhuman.yaml --data-root "$PROCESSED" --stats-path "$PROCESSED/stats.npz" --plan-cache "$PLAN_CACHE"
python tools/train_association.py --config configs/train_assoc_interhuman.yaml --data-root "$PROCESSED" --stats-path "$PROCESSED/stats.npz" --plan-cache "$PLAN_CACHE"
python tools/train_diffusion.py --config configs/train_diffusion_interhuman.yaml --data-root "$PROCESSED" --stats-path "$PROCESSED/stats.npz" --plan-cache "$PLAN_CACHE"
python tools/infer.py \
  --config configs/infer_interhuman.yaml \
  --caption "Two people walk toward each other, interact, and separate." \
  --out-dir outputs/interhuman_demo \
  --plan-cache "$PLAN_CACHE"
