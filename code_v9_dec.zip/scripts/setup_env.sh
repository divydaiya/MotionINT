set -euo pipefail

ENV_NAME="${1:-collage-motion}"

conda env create -n "$ENV_NAME" -f environment.yml || conda env update -n "$ENV_NAME" -f environment.yml
conda activate "$ENV_NAME"
python -m pip install -e .
python - <<'PY'
import torch
print('PyTorch:', torch.__version__)
print('CUDA available:', torch.cuda.is_available())
PY
