set -euo pipefail
export PYTHONPATH="$(pwd):${PYTHONPATH:-}"

RAW_ROOT="${CORE4D_ROOT:-/data/CORE4D}"
CAPTIONS="${COLLAGE_CAPTIONS:-/data/collage_captions.csv}"
PROCESSED="${PROCESSED_ROOT:-/data/collage_processed/core4d}"
LLM_MODEL_ID="${LLM_MODEL_ID:-Qwen/Qwen2.5-7B-Instruct}"
LLM_DIR="${LLM_DIR:-llm_models/qwen2_5_7b_instruct}"
PLAN_CACHE="${PLAN_CACHE:-data/plans/core4d_llm_cues.jsonl}"
LLM_EXTRA_ARGS="${LLM_EXTRA_ARGS:-}"

if [ "${SKIP_LLM_DOWNLOAD:-0}" != "1" ]; then
  python tools/download_llm.py \
    --model-id "$LLM_MODEL_ID" \
    --out-dir "$LLM_DIR" \
    --verify-tokenizer
fi

python tools/generate_llm_cues.py \
  --input "$CAPTIONS" \
  --output "$PLAN_CACHE" \
  --model-path "$LLM_DIR" \
  --model-id "$LLM_MODEL_ID" \
  --levels 6 \
  --resume \
  $LLM_EXTRA_ARGS

python tools/preprocess_core4d.py \
  --config configs/core4d_preprocess.yaml \
  --raw-root "$RAW_ROOT" \
  --caption-csv "$CAPTIONS" \
  --out-dir "$PROCESSED"

python tools/compute_stats.py --data-root "$PROCESSED" --out-path "$PROCESSED/stats.npz"
python tools/train_vqvae.py --config configs/train_vqvae_core4d.yaml --data-root "$PROCESSED" --stats-path "$PROCESSED/stats.npz" --plan-cache "$PLAN_CACHE"
python tools/train_association.py --config configs/train_assoc_core4d.yaml --data-root "$PROCESSED" --stats-path "$PROCESSED/stats.npz" --plan-cache "$PLAN_CACHE"
python tools/train_diffusion.py --config configs/train_diffusion_core4d.yaml --data-root "$PROCESSED" --stats-path "$PROCESSED/stats.npz" --plan-cache "$PLAN_CACHE"
python tools/infer.py \
  --config configs/infer_core4d.yaml \
  --caption "Two humans pick up the object together and place it down." \
  --out-dir outputs/core4d_demo \
  --plan-cache "$PLAN_CACHE"
