from __future__ import annotations
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence
import torch
from collage_motion.llm.plan_schema import AGENT_KEYS, PAPER_LEVEL_NAMES, extract_cues, extract_entity_cues, normalize_plan_record
from collage_motion.models.text import build_text_encoder
_ACTION_WORDS = {'pick', 'pickup', 'pick-up', 'lift', 'carry', 'move', 'push', 'pull', 'rotate', 'place', 'put', 'handover', 'hand', 'walk', 'run', 'dance', 'fight', 'hug', 'bow', 'argue', 'sit', 'stand', 'throw', 'catch', 'drag'}
_OBJECT_WORDS = {'chair', 'box', 'table', 'desk', 'board', 'barrel', 'stick', 'object', 'sofa', 'bag', 'ball', 'door', 'cart'}
_SPATIAL_WORDS = {'left', 'right', 'front', 'behind', 'around', 'over', 'under', 'toward', 'away', 'side', 'together', 'apart'}

def _words(text: str) -> list[str]:
    return re.findall('[a-zA-Z0-9_-]+', text.lower())

def _select(words: list[str], vocab: set[str], fallback: str) -> str:
    picked = [w for w in words if w in vocab]
    return ', '.join(dict.fromkeys(picked)) if picked else fallback

def _norm_text(text: str) -> str:
    return re.sub('\\s+', ' ', text.strip().lower())

class PlanCache:

    def __init__(self, path: str | Path | None=None, levels: int=6) -> None:
        self.path = None if path is None else Path(path)
        self.levels = levels
        self.records: dict[str, dict[str, Any]] = {}
        if self.path is not None and self.path.exists():
            with self.path.open('r', encoding='utf-8') as f:
                for line in f:
                    if not line.strip():
                        continue
                    self._add_row(json.loads(line))

    def _add_key(self, key: Any, record: dict[str, Any]) -> None:
        if key is None:
            return
        key_str = str(key).strip()
        if not key_str:
            return
        self.records[key_str] = record
        self.records[_norm_text(key_str)] = record

    def _add_row(self, row: dict[str, Any]) -> None:
        caption = row.get('caption') or row.get('description') or row.get('text') or ''
        motion_id = row.get('motion_number') or row.get('motion_id') or row.get('sample_id') or row.get('id')
        record = normalize_plan_record(row.get('llm_plan', row), caption=str(caption), motion_id=motion_id, levels=self.levels, model_id=row.get('model_id'), prompt_version=row.get('prompt_version', 'cache'))
        self._add_key(caption, record)
        self._add_key(motion_id, record)
        if motion_id is not None and caption:
            self._add_key(f'{motion_id}:{caption}', record)

    def get_record(self, caption_or_id: str) -> dict[str, Any] | None:
        key = str(caption_or_id).strip()
        return self.records.get(key) or self.records.get(_norm_text(key))

    def __len__(self) -> int:
        return len(self.records)

@dataclass
class HierarchicalPlanner:
    levels: int = 6
    cache: PlanCache | None = None

    def _heuristic_record(self, caption: str) -> dict[str, Any]:
        ws = _words(caption)
        actions = _select(ws, _ACTION_WORDS, 'collaborative motion')
        objects = _select(ws, _OBJECT_WORDS, 'shared object or partner')
        spatial = _select(ws, _SPATIAL_WORDS, 'coordinated spacing')
        raw = {'caption': caption, 'task_summary': caption, 'entities': {'person_1': 'first collaborator', 'person_2': 'second collaborator', 'object': objects}, 'hierarchical_cues': [{'level': 1, 'name': PAPER_LEVEL_NAMES[0], 'person_1': f'Coordinate with person 2 to perform {actions}.', 'person_2': f'Coordinate with person 1 to perform {actions}.', 'object': objects, 'both': f'Complete the shared objective: {caption}.'}, {'level': 2, 'name': PAPER_LEVEL_NAMES[1], 'person_1': f'Approach while preserving {spatial}.', 'person_2': f'Approach from a complementary side while preserving {spatial}.', 'object': f'Stay reachable between the agents if {objects} is present.', 'both': 'Establish stable relative spacing before the main action.'}, {'level': 3, 'name': PAPER_LEVEL_NAMES[2], 'person_1': 'Use stable hand or body contact points.', 'person_2': 'Use complementary contact points and avoid crossing limbs.', 'object': 'Maintain plausible support/contact regions.', 'both': 'Synchronize contact timing and grip/release mechanics.'}, {'level': 4, 'name': PAPER_LEVEL_NAMES[3], 'person_1': 'Align torso, shoulders, elbows, and hands with the task direction.', 'person_2': 'Mirror or compensate with coordinated upper-body motion.', 'object': 'Follow the shared support direction.', 'both': 'Keep upper bodies balanced while the interaction evolves.'}, {'level': 5, 'name': PAPER_LEVEL_NAMES[4], 'person_1': 'Step smoothly with stable foot placement.', 'person_2': 'Synchronize cadence and root velocity with person 1.', 'object': 'Move consistently with the lower-body translation if present.', 'both': 'Coordinate stepping, balance, and relative distance.'}, {'level': 6, 'name': PAPER_LEVEL_NAMES[5], 'person_1': 'Refine hand, wrist, elbow, torso, and foot motion.', 'person_2': 'Refine complementary limb motion and ending pose.', 'object': 'Avoid jitter, penetration, and implausible jumps.', 'both': 'Preserve velocity continuity, stable contact, and smooth release.'}]}
        return normalize_plan_record(raw, caption=caption, levels=self.levels, model_id='heuristic')

    def record_one(self, caption: str) -> dict[str, Any]:
        if self.cache is not None:
            cached = self.cache.get_record(caption)
            if cached:
                return cached
        return self._heuristic_record(caption)

    def plan_one(self, caption: str) -> list[str]:
        return extract_cues(self.record_one(caption), levels=self.levels)

    def entity_plan_one(self, caption: str) -> dict[str, list[str]]:
        return extract_entity_cues(self.record_one(caption), levels=self.levels)

    def plan_batch(self, captions: Sequence[str]) -> list[list[str]]:
        return [self.plan_one(c) for c in captions]

    def entity_plan_batch(self, captions: Sequence[str]) -> list[dict[str, list[str]]]:
        return [self.entity_plan_one(c) for c in captions]

class PlanEncoder:

    def __init__(self, levels: int=6, text_dim: int=512, text_encoder: str='clip', plan_cache: str | Path | None=None, text_model_name: str | None=None, backend: str='cache_or_heuristic', openai_model: str='gpt-4') -> None:
        self.levels = levels
        self.text_dim = text_dim
        self.cache = PlanCache(plan_cache, levels=levels)
        self.planner = HierarchicalPlanner(levels=levels, cache=self.cache)
        self.encoder = build_text_encoder(text_encoder, dim=text_dim, model_name=text_model_name)
        self.backend = backend
        self.openai_model = openai_model
        self._openai_planner = None

    def _record(self, caption: str) -> dict[str, Any]:
        cached = self.cache.get_record(caption) if self.cache is not None else None
        if cached:
            return cached
        if self.backend == 'openai':
            if self._openai_planner is None:
                from collage_motion.llm.openai_planner import OpenAIPlanner, OpenAIPlannerConfig
                self._openai_planner = OpenAIPlanner(OpenAIPlannerConfig(model=self.openai_model, levels=self.levels))
            record = self._openai_planner.plan(caption)
            self.cache._add_row(record)
            return record
        return self.planner.record_one(caption)

    def plans(self, captions: Sequence[str]) -> list[list[str]]:
        return [extract_cues(self._record(c), levels=self.levels) for c in captions]

    def entity_plans(self, captions: Sequence[str]) -> list[dict[str, list[str]]]:
        return [extract_entity_cues(self._record(c), levels=self.levels) for c in captions]

    def encode(self, captions: Sequence[str], device: torch.device | str | None=None) -> torch.Tensor:
        plans = self.plans(captions)
        flat = [cue for cues in plans for cue in cues]
        encoded = self.encoder.encode(flat, device=device)
        return encoded.reshape(len(captions), self.levels, self.text_dim)

    def encode_entities(self, captions: Sequence[str], device: torch.device | str | None=None) -> dict[str, torch.Tensor]:
        entity_plans = self.entity_plans(captions)
        out: dict[str, torch.Tensor] = {}
        for key in AGENT_KEYS:
            flat = [cue for plans in entity_plans for cue in plans[key]]
            encoded = self.encoder.encode(flat, device=device).reshape(len(captions), self.levels, self.text_dim)
            out[key] = encoded
        return out
    def encode_entity_tensor(self, captions: Sequence[str], num_humans: int=2, num_objects: int=1, device: torch.device | str | None=None) -> torch.Tensor:
        entities = self.encode_entities(captions, device=device)
        seq: list[torch.Tensor] = []
        for idx in range(num_humans):
            key = 'person_1' if idx == 0 else 'person_2' if idx == 1 else 'both'
            seq.append(entities.get(key, entities['both']))
        for _ in range(num_objects):
            seq.append(entities.get('object', entities['both']))
        if not seq:
            return self.encode(captions, device=device)[:, :, None, :]
        return torch.stack(seq, dim=2)

