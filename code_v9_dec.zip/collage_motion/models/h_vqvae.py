from __future__ import annotations
from dataclasses import dataclass
from typing import Any
import torch
from torch import nn
import torch.nn.functional as F
from collage_motion.models.layers import CueConcatConditioner, FullyConnectedGraphAttentionBlock, TemporalConvBlock
from collage_motion.models.vq import EMAQuantizer
from collage_motion.training.losses import covariance_disentanglement_loss, masked_mse, velocity_smoothness_loss
from collage_motion.utils.geometry import contact_map_loss, infer_contact_map, mesh_penetration_loss, motion_to_entity_vertices

class BranchEncoderLevel(nn.Module):

    def __init__(self, dim: int, cue_dim: int, conv_depth: int=2, dropout: float=0.0) -> None:
        super().__init__()
        self.convs = nn.ModuleList([TemporalConvBlock(dim, dim, kernel_size=3, dropout=dropout) for _ in range(conv_depth)])
        self.cue = CueConcatConditioner(dim, cue_dim, dropout=dropout)
        self.norm = nn.LayerNorm(dim)

    def forward(self, x: torch.Tensor, cue: torch.Tensor, mask: torch.Tensor | None=None) -> torch.Tensor:
        if x.shape[2] == 0:
            return x
        for block in self.convs:
            x = block(x)
        x = self.cue(x, cue)
        if mask is not None:
            x = x * mask[:, None, :, None]
        return self.norm(x)

class BranchDecoder(nn.Module):

    def __init__(self, latent_dim: int, output_dim: int, hidden_dim: int, depth: int=3, dropout: float=0.0) -> None:
        super().__init__()
        self.in_proj = nn.Linear(latent_dim, hidden_dim)
        self.blocks = nn.ModuleList([TemporalConvBlock(hidden_dim, hidden_dim, kernel_size=3, dropout=dropout) for _ in range(depth)])
        self.out = nn.Sequential(nn.LayerNorm(hidden_dim), nn.Linear(hidden_dim, output_dim))

    def forward(self, z: torch.Tensor, mask: torch.Tensor | None=None) -> torch.Tensor:
        if z.shape[2] == 0:
            return z.new_zeros(*z.shape[:-1], self.out[-1].out_features)
        h = self.in_proj(z)
        for block in self.blocks:
            h = block(h)
        out = self.out(h)
        if mask is not None:
            out = out * mask[:, None, :, None]
        return out

@dataclass
class VQVAELossWeights:
    recon: float = 1.0
    commit: float = 0.25
    codebook: float = 0.25
    align: float = 0.5
    smooth: float = 0.1
    disentangle: float = 1.0
    contact: float = 5.0
    penetration: float = 10.0

class HierarchicalVQVAE(nn.Module):

    def __init__(self, input_dim: int, latent_dim: int=512, hidden_dim: int=512, text_dim: int=512, num_entities: int=3, num_humans: int=2, num_objects: int | None=None, num_levels: int=6, codebook_size: int=512, conv_depth: int=2, attn_heads: int=8, ema_decay: float=0.99, dropout: float=0.0) -> None:
        super().__init__()
        self.input_dim = input_dim
        self.latent_dim = latent_dim
        self.hidden_dim = hidden_dim
        self.text_dim = text_dim
        self.num_entities = num_entities
        self.num_humans = min(num_humans, num_entities)
        self.num_objects = max(0, num_entities - self.num_humans) if num_objects is None else max(0, num_objects)
        self.num_levels = num_levels
        self.codebook_size = codebook_size
        self.human_input_proj = nn.Linear(input_dim, latent_dim)
        self.object_input_proj = nn.Linear(input_dim, latent_dim)
        self.human_levels = nn.ModuleList([BranchEncoderLevel(latent_dim, text_dim, conv_depth=conv_depth, dropout=dropout) for _ in range(num_levels)])
        self.object_levels = nn.ModuleList([BranchEncoderLevel(latent_dim, text_dim, conv_depth=conv_depth, dropout=dropout) for _ in range(num_levels)])
        self.interaction = nn.ModuleList([FullyConnectedGraphAttentionBlock(latent_dim, heads=attn_heads, dropout=dropout) for _ in range(num_levels)])
        self.human_quantizers = nn.ModuleList([EMAQuantizer(codebook_size, latent_dim, decay=ema_decay) for _ in range(num_levels)])
        self.object_quantizers = nn.ModuleList([EMAQuantizer(codebook_size, latent_dim, decay=ema_decay) for _ in range(num_levels)])
        decoder_depth = max(2, num_levels // 2)
        self.decoder_temporal = nn.ModuleList([TemporalConvBlock(latent_dim, latent_dim, kernel_size=3, dropout=dropout) for _ in range(decoder_depth)])
        self.decoder_interaction = nn.ModuleList([FullyConnectedGraphAttentionBlock(latent_dim, heads=attn_heads, dropout=dropout) for _ in range(decoder_depth)])
        self.human_decoder = BranchDecoder(latent_dim, input_dim, hidden_dim, depth=decoder_depth, dropout=dropout)
        self.object_decoder = BranchDecoder(latent_dim, input_dim, hidden_dim, depth=decoder_depth, dropout=dropout)
        self.human_cue_align = nn.ModuleList([nn.Linear(latent_dim, text_dim) for _ in range(num_levels)])
        self.object_cue_align = nn.ModuleList([nn.Linear(latent_dim, text_dim) for _ in range(num_levels)])

    def default_entity_types(self, batch: int, device: torch.device) -> torch.Tensor:
        types = torch.zeros(batch, self.num_entities, dtype=torch.long, device=device)
        types[:, :self.num_humans] = 1
        if self.num_objects > 0:
            types[:, self.num_humans:self.num_humans + self.num_objects] = 2
        return types

    def _entity_masks(self, entity_mask: torch.Tensor | None, entity_types: torch.Tensor | None, batch: int, device: torch.device) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        if entity_mask is None:
            entity_mask = torch.ones(batch, self.num_entities, device=device)
        if entity_types is None:
            entity_types = self.default_entity_types(batch, device)
        entity_types = entity_types.to(device)
        entity_mask = entity_mask.to(device)
        valid = entity_mask * (entity_types > 0).float()
        human_mask = valid[:, :self.num_humans] * (entity_types[:, :self.num_humans] == 1).float()
        object_mask = valid[:, self.num_humans:self.num_humans + self.num_objects] * (entity_types[:, self.num_humans:self.num_humans + self.num_objects] == 2).float()
        return (entity_mask, entity_types, human_mask, object_mask)

    def _split_motion(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        human = x[:, :, :self.num_humans]
        obj = x[:, :, self.num_humans:self.num_humans + self.num_objects]
        return (human, obj)

    def _combine(self, human: torch.Tensor, obj: torch.Tensor, fill_dim: int | None=None) -> torch.Tensor:
        b, t = human.shape[:2]
        dim = fill_dim or human.shape[-1]
        out = human.new_zeros(b, t, self.num_entities, dim)
        out[:, :, :self.num_humans] = human
        if self.num_objects > 0 and obj.shape[2] > 0:
            out[:, :, self.num_humans:self.num_humans + self.num_objects] = obj
        return out

    def _split_combined(self, combined: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        return (combined[:, :, :self.num_humans], combined[:, :, self.num_humans:self.num_humans + self.num_objects])

    def _expand_entity_cues(self, cue: torch.Tensor, count: int) -> torch.Tensor:
        if cue.ndim == 3:
            return cue[:, :, None, :].expand(cue.shape[0], cue.shape[1], count, cue.shape[-1])
        if cue.ndim == 4:
            if cue.shape[2] == count:
                return cue
            if cue.shape[2] == 1:
                return cue.expand(cue.shape[0], cue.shape[1], count, cue.shape[-1])
        raise ValueError(f'Unsupported cue tensor shape {tuple(cue.shape)} for {count} entities')

    def _cue_streams(self, cues: torch.Tensor, entity_cues: dict[str, torch.Tensor] | None=None) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        if entity_cues is None:
            human = self._expand_entity_cues(cues, self.num_humans)
            obj = self._expand_entity_cues(cues, self.num_objects) if self.num_objects > 0 else cues[:, :, None, :].expand(cues.shape[0], cues.shape[1], 0, cues.shape[-1])
            return (human, obj, cues)
        human_parts = []
        for idx in range(self.num_humans):
            key = 'person_1' if idx == 0 else 'person_2' if idx == 1 else f'person_{idx + 1}'
            human_parts.append(entity_cues.get(key, entity_cues.get('both', cues)))
        human = torch.stack(human_parts, dim=2) if human_parts else cues[:, :, None, :].expand(cues.shape[0], cues.shape[1], 0, cues.shape[-1])
        obj_base = entity_cues.get('object', entity_cues.get('both', cues))
        obj = self._expand_entity_cues(obj_base, self.num_objects) if self.num_objects > 0 else cues[:, :, None, :].expand(cues.shape[0], cues.shape[1], 0, cues.shape[-1])
        both = entity_cues.get('both', cues)
        return (human, obj, both)

    def codebooks(self) -> dict[str, list[torch.Tensor]]:
        object_books = [] if self.num_objects == 0 else [q.codebook() for q in self.object_quantizers]
        return {'human': [q.codebook() for q in self.human_quantizers], 'object': object_books}

    @property
    def quantizers(self) -> nn.ModuleList:
        return self.human_quantizers

    def encode(self, x: torch.Tensor, cues: torch.Tensor, entity_mask: torch.Tensor | None=None, entity_types: torch.Tensor | None=None, entity_cues: dict[str, torch.Tensor] | None=None) -> dict[str, Any]:
        b = x.shape[0]
        entity_mask, entity_types, human_mask, object_mask = self._entity_masks(entity_mask, entity_types, b, x.device)
        human_x, object_x = self._split_motion(x)
        h_h = self.human_input_proj(human_x)
        h_o = self.object_input_proj(object_x) if self.num_objects > 0 else x.new_zeros(b, x.shape[1], 0, self.latent_dim)
        human_cues, object_cues, _ = self._cue_streams(cues, entity_cues)
        human_quantized: list[torch.Tensor] = []
        object_quantized: list[torch.Tensor] = []
        combined_quantized: list[torch.Tensor] = []
        human_raw: list[torch.Tensor] = []
        object_raw: list[torch.Tensor] = []
        combined_raw: list[torch.Tensor] = []
        human_indices: list[torch.Tensor] = []
        object_indices: list[torch.Tensor] = []
        losses_commit: list[torch.Tensor] = []
        losses_codebook: list[torch.Tensor] = []
        perplexities: list[torch.Tensor] = []
        for level in range(self.num_levels):
            cue_h = human_cues[:, min(level, human_cues.shape[1] - 1)]
            cue_o = object_cues[:, min(level, object_cues.shape[1] - 1)] if self.num_objects > 0 else object_cues[:, 0]
            h_h = self.human_levels[level](h_h, cue_h, mask=human_mask)
            h_o = self.object_levels[level](h_o, cue_o, mask=object_mask) if self.num_objects > 0 else h_o
            combined = self._combine(h_h, h_o, fill_dim=self.latent_dim)
            combined = self.interaction[level](combined, entity_mask=entity_mask)
            h_h, h_o = self._split_combined(combined)
            human_raw.append(h_h)
            object_raw.append(h_o)
            combined_raw.append(combined)
            q_h = self.human_quantizers[level](h_h, mask=human_mask)
            human_quantized.append(q_h['quantized'])
            human_indices.append(q_h['indices'])
            losses_commit.append(q_h['commitment_loss'])
            losses_codebook.append(q_h['codebook_loss'])
            perplexities.append(q_h['perplexity'])
            if self.num_objects > 0 and h_o.shape[2] > 0:
                q_o = self.object_quantizers[level](h_o, mask=object_mask)
                qo = q_o['quantized']
                object_quantized.append(qo)
                object_indices.append(q_o['indices'])
                losses_commit.append(q_o['commitment_loss'])
                losses_codebook.append(q_o['codebook_loss'])
                perplexities.append(q_o['perplexity'])
            else:
                qo = h_o
                object_quantized.append(qo)
                object_indices.append(torch.zeros(b, x.shape[1], 0, dtype=torch.long, device=x.device))
            combined_q = self._combine(q_h['quantized'], qo, fill_dim=self.latent_dim)
            combined_quantized.append(combined_q)
            h_h = q_h['quantized']
            h_o = qo if self.num_objects > 0 else h_o
        latent_sum = torch.stack(combined_quantized, dim=0).sum(dim=0)
        return {'latent': latent_sum, 'quantized_levels': combined_quantized, 'raw_levels': combined_raw, 'human_quantized_levels': human_quantized, 'object_quantized_levels': object_quantized, 'human_raw_levels': human_raw, 'object_raw_levels': object_raw, 'indices': {'human': human_indices, 'object': object_indices}, 'commitment_loss': torch.stack(losses_commit).mean() if losses_commit else x.new_tensor(0.0), 'codebook_loss': torch.stack(losses_codebook).mean() if losses_codebook else x.new_tensor(0.0), 'perplexity': torch.stack(perplexities).mean() if perplexities else x.new_tensor(0.0), 'entity_mask': entity_mask, 'entity_types': entity_types}

    def decode_latent(self, latent: torch.Tensor, entity_mask: torch.Tensor | None=None, entity_types: torch.Tensor | None=None) -> torch.Tensor:
        b = latent.shape[0]
        entity_mask, entity_types, human_mask, object_mask = self._entity_masks(entity_mask, entity_types, b, latent.device)
        h = latent
        for temporal, graph in zip(self.decoder_temporal, self.decoder_interaction):
            h = temporal(h)
            h = graph(h, entity_mask=entity_mask)
        human_z, object_z = self._split_motion(h)
        human_out = self.human_decoder(human_z, mask=human_mask)
        object_out = self.object_decoder(object_z, mask=object_mask) if self.num_objects > 0 else latent.new_zeros(b, latent.shape[1], 0, self.input_dim)
        recon = self._combine(human_out, object_out, fill_dim=self.input_dim)
        return recon * entity_mask[:, None, :, None]

    def forward(self, x: torch.Tensor, cues: torch.Tensor, entity_mask: torch.Tensor | None=None, entity_types: torch.Tensor | None=None, entity_cues: dict[str, torch.Tensor] | None=None) -> dict[str, Any]:
        enc = self.encode(x, cues, entity_mask=entity_mask, entity_types=entity_types, entity_cues=entity_cues)
        enc['recon'] = self.decode_latent(enc['latent'], entity_mask=enc['entity_mask'], entity_types=enc['entity_types'])
        return enc

    def _alignment_loss(self, levels: list[torch.Tensor], cues: torch.Tensor, projections: nn.ModuleList, mask: torch.Tensor | None=None) -> torch.Tensor:
        if not levels:
            return cues.new_tensor(0.0)
        losses = []
        for idx, z in enumerate(levels):
            if z.shape[2] == 0:
                continue
            if cues.ndim == 4:
                target = cues[:, min(idx, cues.shape[1] - 1)]
                pooled = z.mean(dim=1)
                pred = F.normalize(projections[idx](pooled), dim=-1)
                target = F.normalize(target, dim=-1)
                loss_entity = 1.0 - (pred * target).sum(dim=-1)
                if mask is not None:
                    loss_entity = loss_entity * mask.to(loss_entity.dtype)
                    losses.append(loss_entity.sum() / mask.sum().clamp_min(1.0))
                else:
                    losses.append(loss_entity.mean())
            else:
                if mask is not None:
                    m = mask[:, None, :, None].to(z.dtype)
                    pooled = (z * m).sum(dim=(1, 2)) / m.sum(dim=(1, 2)).clamp_min(1.0)
                else:
                    pooled = z.mean(dim=(1, 2))
                pred = F.normalize(projections[idx](pooled), dim=-1)
                target = F.normalize(cues[:, min(idx, cues.shape[1] - 1)], dim=-1)
                losses.append(1.0 - (pred * target).sum(dim=-1).mean())
        return torch.stack(losses).mean() if losses else cues.new_tensor(0.0)

    def _physical_vertices(self, x: torch.Tensor, entity_types: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        verts = motion_to_entity_vertices(x)
        human = verts[:, :, :self.num_humans]
        obj = verts[:, :, self.num_humans:self.num_humans + self.num_objects]
        return (human, obj)

    def compute_loss(self, x: torch.Tensor, out: dict[str, Any], cues: torch.Tensor, entity_mask: torch.Tensor | None, frame_mask: torch.Tensor | None, weights: VQVAELossWeights, entity_types: torch.Tensor | None=None, entity_cues: dict[str, torch.Tensor] | None=None, human_vertices: torch.Tensor | None=None, object_vertices: torch.Tensor | None=None, contact_map: torch.Tensor | None=None, signed_distance: torch.Tensor | None=None) -> dict[str, torch.Tensor]:
        recon = out['recon']
        b = x.shape[0]
        entity_mask, entity_types, human_mask, object_mask = self._entity_masks(entity_mask, entity_types, b, x.device)
        human_cues, object_cues, _ = self._cue_streams(cues, entity_cues)
        recon_loss = masked_mse(recon, x, entity_mask=entity_mask, frame_mask=frame_mask)
        commit_loss = out['commitment_loss']
        codebook_loss = out['codebook_loss']
        smooth_loss = velocity_smoothness_loss(recon, entity_mask=entity_mask, frame_mask=frame_mask)
        human_dis = covariance_disentanglement_loss(out['human_quantized_levels']) if out.get('human_quantized_levels') else x.new_tensor(0.0)
        object_dis = covariance_disentanglement_loss(out['object_quantized_levels']) if self.num_objects > 0 and out.get('object_quantized_levels') else x.new_tensor(0.0)
        disent_loss = human_dis + object_dis
        align_h = self._alignment_loss(out.get('human_quantized_levels', []), human_cues, self.human_cue_align, human_mask)
        align_o = self._alignment_loss(out.get('object_quantized_levels', []), object_cues, self.object_cue_align, object_mask) if self.num_objects > 0 else x.new_tensor(0.0)
        align_loss = align_h + align_o
        if self.num_objects > 0 and weights.contact > 0:
            pred_h, pred_o = self._physical_vertices(recon, entity_types)
            if contact_map is None:
                with torch.no_grad():
                    if human_vertices is not None and object_vertices is not None:
                        contact_map = infer_contact_map(human_vertices.to(x.device), object_vertices.to(x.device))
                    else:
                        gt_h, gt_o = self._physical_vertices(x, entity_types)
                        contact_map = infer_contact_map(gt_h, gt_o)
            contact_loss = contact_map_loss(pred_h, pred_o, contact_map)
        else:
            contact_loss = x.new_tensor(0.0)
        if self.num_objects > 0 and weights.penetration > 0:
            pred_h, pred_o = self._physical_vertices(recon, entity_types)
            penetration_loss = mesh_penetration_loss(pred_h, pred_o, signed_distance=signed_distance)
        else:
            penetration_loss = x.new_tensor(0.0)
        total = weights.recon * recon_loss + weights.commit * commit_loss + weights.codebook * codebook_loss + weights.align * align_loss + weights.smooth * smooth_loss + weights.disentangle * disent_loss + weights.contact * contact_loss + weights.penetration * penetration_loss
        return {'loss': total, 'recon': recon_loss, 'commit': commit_loss, 'codebook': codebook_loss, 'align': align_loss, 'smooth': smooth_loss, 'disentangle': disent_loss, 'contact': contact_loss, 'penetration': penetration_loss, 'perplexity': out['perplexity']}
