from __future__ import annotations
import math
from dataclasses import dataclass
import torch
from torch import nn
import torch.nn.functional as F
from collage_motion.models.layers import MotionModelBlock, SinusoidalTimeEmbedding, downsample_time, upsample_time
from collage_motion.training.losses import masked_mse


def cosine_beta_schedule(timesteps: int, s: float=0.008) -> torch.Tensor:
    steps = timesteps + 1
    x = torch.linspace(0, timesteps, steps)
    alphas_cumprod = torch.cos((x / timesteps + s) / (1 + s) * math.pi * 0.5) ** 2
    alphas_cumprod = alphas_cumprod / alphas_cumprod[0]
    betas = 1 - alphas_cumprod[1:] / alphas_cumprod[:-1]
    return betas.clamp(0.0001, 0.9999)


def linear_beta_schedule(timesteps: int) -> torch.Tensor:
    return torch.linspace(0.0001, 0.02, timesteps)


class DiffusionSchedule(nn.Module):

    def __init__(self, steps: int=1000, beta_schedule: str='cosine') -> None:
        super().__init__()
        betas = cosine_beta_schedule(steps) if beta_schedule == 'cosine' else linear_beta_schedule(steps)
        alphas = 1.0 - betas
        alphas_cumprod = torch.cumprod(alphas, dim=0)
        alphas_cumprod_prev = F.pad(alphas_cumprod[:-1], (1, 0), value=1.0)
        self.steps = steps
        self.register_buffer('betas', betas)
        self.register_buffer('alphas', alphas)
        self.register_buffer('alphas_cumprod', alphas_cumprod)
        self.register_buffer('alphas_cumprod_prev', alphas_cumprod_prev)
        self.register_buffer('sqrt_alphas_cumprod', torch.sqrt(alphas_cumprod))
        self.register_buffer('sqrt_one_minus_alphas_cumprod', torch.sqrt(1.0 - alphas_cumprod))
        self.register_buffer('sqrt_recip_alphas_cumprod', torch.sqrt(1.0 / alphas_cumprod))
        self.register_buffer('sqrt_recipm1_alphas_cumprod', torch.sqrt(1.0 / alphas_cumprod - 1))

    def extract(self, values: torch.Tensor, t: torch.Tensor, shape: torch.Size) -> torch.Tensor:
        out = values.gather(0, t.clamp(0, self.steps - 1))
        return out.reshape(t.shape[0], *[1] * (len(shape) - 1))

    def q_sample(self, x0: torch.Tensor, t: torch.Tensor, noise: torch.Tensor) -> torch.Tensor:
        return self.extract(self.sqrt_alphas_cumprod, t, x0.shape) * x0 + self.extract(self.sqrt_one_minus_alphas_cumprod, t, x0.shape) * noise

    def predict_x0_from_eps(self, xt: torch.Tensor, t: torch.Tensor, eps: torch.Tensor) -> torch.Tensor:
        return self.extract(self.sqrt_recip_alphas_cumprod, t, xt.shape) * xt - self.extract(self.sqrt_recipm1_alphas_cumprod, t, xt.shape) * eps


class LatentDenoiserUNet(nn.Module):

    def __init__(self, latent_dim: int=512, hidden_dim: int=512, text_dim: int=512, num_levels: int=6, mm_blocks: int=4, attn_heads: int=8, dropout: float=0.1) -> None:
        super().__init__()
        self.latent_dim = latent_dim
        self.hidden_dim = hidden_dim
        self.text_dim = text_dim
        self.num_levels = num_levels
        self.mm_blocks = mm_blocks
        self.in_proj = nn.Linear(latent_dim, hidden_dim)
        self.time = SinusoidalTimeEmbedding(hidden_dim)
        down_n = max(1, mm_blocks // 2)
        up_n = max(1, mm_blocks - down_n)
        self.down_blocks = nn.ModuleList([MotionModelBlock(hidden_dim, text_dim, num_levels=num_levels, heads=attn_heads, dropout=dropout) for _ in range(down_n)])
        self.up_blocks = nn.ModuleList([MotionModelBlock(hidden_dim, text_dim, num_levels=num_levels, heads=attn_heads, dropout=dropout) for _ in range(up_n)])
        self.bottleneck = nn.Sequential(nn.LayerNorm(hidden_dim), nn.Linear(hidden_dim, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, hidden_dim))
        self.out = nn.Sequential(nn.LayerNorm(hidden_dim), nn.Linear(hidden_dim, latent_dim))
        self.null_cues = nn.Parameter(torch.zeros(1, num_levels, text_dim))
        self.cue_log_lambdas = nn.Parameter(torch.full((num_levels,), math.log(math.exp(1.0) - 1.0)))
        self.cue_log_ks = nn.Parameter(torch.full((num_levels,), math.log(math.exp(4.0) - 1.0)))

    def full_adjacency(self, entity_mask: torch.Tensor | None, entities: int, device: torch.device) -> torch.Tensor | None:
        if entity_mask is None:
            return torch.ones(entities, entities, device=device, dtype=torch.bool)
        valid = entity_mask > 0.5
        return valid[:, :, None] & valid[:, None, :]

    def cue_weights(self, timesteps: torch.Tensor, total_steps: int, levels: int | None=None) -> torch.Tensor:
        levels = levels or self.num_levels
        progress = 1.0 - timesteps.float().clamp(0, total_steps - 1) / max(float(total_steps - 1), 1.0)
        lambdas = F.softplus(self.cue_log_lambdas[:levels]).to(timesteps.device)
        rates = F.softplus(self.cue_log_ks[:levels]).to(timesteps.device)
        weights = []
        for level in range(levels):
            if level < levels // 2:
                w = lambdas[level] * torch.exp(-rates[level] * progress)
            else:
                w = lambdas[level] * (1.0 - torch.exp(-rates[level] * progress))
            weights.append(w)
        return torch.stack(weights, dim=1)

    def modulate_cues(self, cues: torch.Tensor, timesteps: torch.Tensor, total_steps: int) -> torch.Tensor:
        gamma = self.cue_weights(timesteps, total_steps, levels=cues.shape[1]).to(cues.dtype)
        view_shape = (gamma.shape[0], gamma.shape[1]) + (1,) * (cues.ndim - 2)
        return cues * gamma.reshape(view_shape)

    def _null(self, x: torch.Tensor, cues: torch.Tensor | None) -> torch.Tensor:
        if cues is not None:
            return cues
        return self.null_cues.expand(x.shape[0], -1, -1)

    def forward(self, x: torch.Tensor, timesteps: torch.Tensor, cues: torch.Tensor | None, entity_mask: torch.Tensor | None=None, adjacency: torch.Tensor | None=None, total_steps: int=1000) -> torch.Tensor:
        cues = self._null(x, cues)
        cue_weights = self.cue_weights(timesteps, total_steps, levels=cues.shape[1]).to(cues.dtype)
        h = self.in_proj(x)
        temb = self.time(timesteps)
        if adjacency is None:
            adjacency = self.full_adjacency(entity_mask, x.shape[2], x.device)
        skips = []
        for block in self.down_blocks:
            h = block(h, temb, cues, cue_weights=cue_weights, entity_mask=entity_mask, adjacency=adjacency)
            skips.append(h)
            h = downsample_time(h)
        h = h + self.bottleneck(h)
        for block in self.up_blocks:
            skip = skips.pop() if skips else None
            if skip is not None:
                h = upsample_time(h, skip.shape[1]) + skip
            h = block(h, temb, cues, cue_weights=cue_weights, entity_mask=entity_mask, adjacency=adjacency)
        return self.out(h)


@dataclass
class DiffusionConfig:
    steps: int = 1000
    beta_schedule: str = 'cosine'
    objective: str = 'eps'
    cond_drop_prob: float = 0.1


class LatentDiffusion(nn.Module):

    def __init__(self, denoiser: LatentDenoiserUNet, config: DiffusionConfig) -> None:
        super().__init__()
        self.denoiser = denoiser
        self.config = config
        self.schedule = DiffusionSchedule(config.steps, config.beta_schedule)

    def training_loss(self, x0: torch.Tensor, cues: torch.Tensor, entity_mask: torch.Tensor | None=None, frame_mask: torch.Tensor | None=None, adjacency: torch.Tensor | None=None) -> dict[str, torch.Tensor]:
        b = x0.shape[0]
        t = torch.randint(0, self.config.steps, (b,), device=x0.device, dtype=torch.long)
        noise = torch.randn_like(x0)
        xt = self.schedule.q_sample(x0, t, noise)
        cond = cues
        if self.training and self.config.cond_drop_prob > 0:
            keep_shape = (b,) + (1,) * (cues.ndim - 1)
            keep = (torch.rand(b, device=x0.device) > self.config.cond_drop_prob).float().reshape(keep_shape)
            cond = cues * keep
        pred = self.denoiser(xt, t, cond, entity_mask=entity_mask, adjacency=adjacency, total_steps=self.config.steps)
        loss = masked_mse(pred, noise, entity_mask=entity_mask, frame_mask=frame_mask)
        return {'loss': loss, 'eps': loss}

    @torch.no_grad()
    def p_sample_ddpm(self, x: torch.Tensor, t: torch.Tensor, cues: torch.Tensor, entity_mask: torch.Tensor | None, guidance_scale: float=1.0, adjacency: torch.Tensor | None=None) -> torch.Tensor:
        eps = self.guided_eps(x, t, cues, entity_mask, guidance_scale, adjacency=adjacency)
        beta = self.schedule.extract(self.schedule.betas, t, x.shape)
        alpha = self.schedule.extract(self.schedule.alphas, t, x.shape)
        alpha_bar = self.schedule.extract(self.schedule.alphas_cumprod, t, x.shape)
        mean = 1.0 / torch.sqrt(alpha) * (x - beta / torch.sqrt(1.0 - alpha_bar) * eps)
        noise = torch.randn_like(x)
        nonzero = (t > 0).float().reshape(x.shape[0], *[1] * (x.ndim - 1))
        return mean + nonzero * torch.sqrt(beta) * noise

    @torch.no_grad()
    def guided_eps(self, x: torch.Tensor, t: torch.Tensor, cues: torch.Tensor, entity_mask: torch.Tensor | None, guidance_scale: float, adjacency: torch.Tensor | None=None) -> torch.Tensor:
        eps_cond = self.denoiser(x, t, cues, entity_mask=entity_mask, adjacency=adjacency, total_steps=self.config.steps)
        if guidance_scale == 1.0:
            return eps_cond
        eps_uncond = self.denoiser(x, t, None, entity_mask=entity_mask, adjacency=adjacency, total_steps=self.config.steps)
        return eps_uncond + guidance_scale * (eps_cond - eps_uncond)

    def _apply_condition(self, x: torch.Tensor, conditioning_latent: torch.Tensor | None, conditioning_mask: torch.Tensor | None) -> torch.Tensor:
        if conditioning_latent is None or conditioning_mask is None:
            return x
        mask = conditioning_mask.to(device=x.device, dtype=x.dtype)
        while mask.ndim < x.ndim:
            mask = mask.unsqueeze(-1)
        return x * (1.0 - mask) + conditioning_latent.to(x.device, x.dtype) * mask

    @torch.no_grad()
    def sample(self, shape: tuple[int, int, int, int], cues: torch.Tensor, entity_mask: torch.Tensor | None=None, sample_steps: int=55, sampler: str='ddim', guidance_scale: float=1.0, adjacency: torch.Tensor | None=None, conditioning_latent: torch.Tensor | None=None, conditioning_mask: torch.Tensor | None=None) -> torch.Tensor:
        device = cues.device
        x = torch.randn(shape, device=device)
        if entity_mask is not None:
            x = x * entity_mask[:, None, :, None]
        x = self._apply_condition(x, conditioning_latent, conditioning_mask)
        if sampler == 'ddpm':
            times = torch.linspace(self.config.steps - 1, 0, sample_steps, device=device).long()
            for ti in times:
                t = torch.full((shape[0],), int(ti.item()), device=device, dtype=torch.long)
                x = self.p_sample_ddpm(x, t, cues, entity_mask, guidance_scale, adjacency=adjacency)
                if entity_mask is not None:
                    x = x * entity_mask[:, None, :, None]
                x = self._apply_condition(x, conditioning_latent, conditioning_mask)
            return x
        times = torch.linspace(self.config.steps - 1, 0, sample_steps + 1, device=device).long()
        for i in range(sample_steps):
            t = torch.full((shape[0],), int(times[i].item()), device=device, dtype=torch.long)
            t_next = torch.full((shape[0],), int(times[i + 1].item()), device=device, dtype=torch.long)
            eps = self.guided_eps(x, t, cues, entity_mask, guidance_scale, adjacency=adjacency)
            x0 = self.schedule.predict_x0_from_eps(x, t, eps)
            alpha_next = self.schedule.extract(self.schedule.alphas_cumprod, t_next, x.shape)
            if int(times[i + 1].item()) <= 0:
                x = x0
            else:
                x = torch.sqrt(alpha_next) * x0 + torch.sqrt(1.0 - alpha_next) * eps
            if entity_mask is not None:
                x = x * entity_mask[:, None, :, None]
            x = self._apply_condition(x, conditioning_latent, conditioning_mask)
        return x
