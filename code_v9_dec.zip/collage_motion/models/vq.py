from __future__ import annotations
import torch
from torch import nn
import torch.nn.functional as F

class EMAQuantizer(nn.Module):

    def __init__(self, num_codes: int, dim: int, decay: float=0.99, eps: float=1e-05) -> None:
        super().__init__()
        self.num_codes = num_codes
        self.dim = dim
        self.decay = decay
        self.eps = eps
        embed = torch.randn(num_codes, dim) / dim ** 0.5
        self.register_buffer('embedding', embed)
        self.register_buffer('cluster_size', torch.zeros(num_codes))
        self.register_buffer('embed_avg', embed.clone())

    def forward(self, z: torch.Tensor, mask: torch.Tensor | None=None) -> dict[str, torch.Tensor]:
        b, t, e, d = z.shape
        flat = z.reshape(-1, d)
        if mask is not None:
            token_mask = mask[:, None, :].expand(b, t, e).reshape(-1) > 0.5
        else:
            token_mask = torch.ones(flat.shape[0], dtype=torch.bool, device=z.device)
        valid = flat[token_mask]
        if valid.numel() == 0:
            valid = flat
            token_mask = torch.ones(flat.shape[0], dtype=torch.bool, device=z.device)
        embedding = self.embedding.detach().clone()
        dist = valid.pow(2).sum(dim=1, keepdim=True) - 2 * valid @ embedding.t() + embedding.pow(2).sum(dim=1).unsqueeze(0)
        indices_valid = torch.argmin(dist, dim=1)
        indices = torch.zeros(flat.shape[0], dtype=torch.long, device=z.device)
        indices[token_mask] = indices_valid
        quantized_flat = F.embedding(indices, embedding)
        quantized = quantized_flat.reshape(b, t, e, d)
        if self.training:
            with torch.no_grad():
                valid_detached = valid.detach()
                one_hot = F.one_hot(indices_valid, self.num_codes).type_as(valid_detached)
                cluster_size = one_hot.sum(dim=0)
                embed_sum = one_hot.t() @ valid_detached
                self.cluster_size.mul_(self.decay).add_(cluster_size, alpha=1.0 - self.decay)
                self.embed_avg.mul_(self.decay).add_(embed_sum, alpha=1.0 - self.decay)
                n = self.cluster_size.sum()
                cluster_size_norm = (self.cluster_size + self.eps) / (n + self.num_codes * self.eps) * n
                embed_normalized = self.embed_avg / cluster_size_norm.unsqueeze(1).clamp_min(self.eps)
                self.embedding.copy_(embed_normalized)
        commitment = F.mse_loss(z, quantized.detach())
        codebook = F.mse_loss(quantized, z.detach())
        quantized_st = z + (quantized - z).detach()
        avg_probs = torch.bincount(indices_valid, minlength=self.num_codes).float()
        avg_probs = avg_probs / avg_probs.sum().clamp_min(1.0)
        perplexity = torch.exp(-(avg_probs * torch.log(avg_probs + 1e-10)).sum())
        return {'quantized': quantized_st, 'raw_quantized': quantized, 'indices': indices.reshape(b, t, e), 'commitment_loss': commitment, 'codebook_loss': codebook, 'perplexity': perplexity}

    def codebook(self) -> torch.Tensor:
        return self.embedding
