from __future__ import annotations
import hashlib
import math
import re
from dataclasses import dataclass
from typing import Sequence
import numpy as np
import torch
_TOKEN_RE = re.compile("[A-Za-z0-9_']+|[^\\sA-Za-z0-9_']")

def tokenize(text: str) -> list[str]:
    return _TOKEN_RE.findall(text.lower())

@dataclass
class HashTextEncoder:
    dim: int = 512
    ngram_max: int = 3
    char_ngrams: bool = True

    def _bucket(self, token: str) -> tuple[int, float]:
        digest = hashlib.blake2b(token.encode('utf-8'), digest_size=8).digest()
        value = int.from_bytes(digest, 'little', signed=False)
        idx = value % self.dim
        sign = 1.0 if value >> 63 & 1 == 0 else -1.0
        return (idx, sign)

    def encode_one_np(self, text: str) -> np.ndarray:
        tokens = tokenize(text)
        vec = np.zeros(self.dim, dtype=np.float32)
        for n in range(1, self.ngram_max + 1):
            for i in range(max(0, len(tokens) - n + 1)):
                idx, sign = self._bucket(f"w{n}:{' '.join(tokens[i:i + n])}")
                vec[idx] += sign / math.sqrt(n)
        if self.char_ngrams:
            compact = re.sub('\\s+', ' ', text.lower()).strip()
            for n in (3, 4, 5):
                for i in range(max(0, len(compact) - n + 1)):
                    idx, sign = self._bucket(f'c{n}:{compact[i:i + n]}')
                    vec[idx] += 0.25 * sign / math.sqrt(n)
        norm = float(np.linalg.norm(vec))
        if norm > 1e-08:
            vec /= norm
        return vec

    def encode(self, texts: Sequence[str], device: torch.device | str | None=None) -> torch.Tensor:
        arr = np.stack([self.encode_one_np(t) for t in texts], axis=0)
        tensor = torch.from_numpy(arr)
        return tensor.to(device) if device is not None else tensor

class CLIPTextEncoder:

    def __init__(self, model_name: str='openai/clip-vit-base-patch32', dim: int=512, device: str | torch.device | None=None) -> None:
        from transformers import CLIPModel, CLIPTokenizer
        self.model_name = model_name
        self.dim = dim
        self.device = torch.device(device) if device is not None else torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.tokenizer = CLIPTokenizer.from_pretrained(model_name)
        self.model = CLIPModel.from_pretrained(model_name).to(self.device)
        self.model.eval()
        self.proj: torch.Tensor | None = None

    def _projection(self, in_dim: int, device: torch.device) -> torch.Tensor:
        if in_dim == self.dim:
            return torch.eye(in_dim, device=device)
        if self.proj is None or self.proj.shape != (in_dim, self.dim):
            gen = torch.Generator(device='cpu')
            gen.manual_seed(1234)
            proj = torch.randn(in_dim, self.dim, generator=gen) / math.sqrt(float(in_dim))
            self.proj = proj
        return self.proj.to(device)

    @torch.inference_mode()
    def encode(self, texts: Sequence[str], device: torch.device | str | None=None) -> torch.Tensor:
        if len(texts) == 0:
            out = torch.empty(0, self.dim, device=self.device)
            return out.to(device) if device is not None else out
        tokens = self.tokenizer(list(texts), padding=True, truncation=True, return_tensors='pt').to(self.device)
        pooled = self.model.get_text_features(**tokens)
        pooled = pooled @ self._projection(pooled.shape[-1], pooled.device)
        pooled = torch.nn.functional.normalize(pooled.float(), dim=-1)
        return pooled.to(device) if device is not None else pooled

class SentenceTransformerTextEncoder:

    def __init__(self, model_name: str='all-MiniLM-L6-v2', dim: int=512) -> None:
        from sentence_transformers import SentenceTransformer
        self.model = SentenceTransformer(model_name)
        self.dim = dim
        self.proj: np.ndarray | None = None

    def encode(self, texts: Sequence[str], device: torch.device | str | None=None) -> torch.Tensor:
        emb = self.model.encode(list(texts), convert_to_numpy=True, normalize_embeddings=True).astype(np.float32)
        if emb.shape[1] != self.dim:
            if self.proj is None:
                rng = np.random.default_rng(1234)
                self.proj = rng.normal(0, 1 / math.sqrt(emb.shape[1]), size=(emb.shape[1], self.dim)).astype(np.float32)
            emb = emb @ self.proj
            emb /= np.maximum(np.linalg.norm(emb, axis=-1, keepdims=True), 1e-08)
        tensor = torch.from_numpy(emb)
        return tensor.to(device) if device is not None else tensor

def build_text_encoder(kind: str='clip', dim: int=512, model_name: str | None=None, device: str | torch.device | None=None):
    key = (kind or 'clip').lower()
    if key == 'hash':
        return HashTextEncoder(dim=dim)
    if key in {'clip', 'clip-vit-b-32', 'clip_vit_b_32'}:
        return CLIPTextEncoder(model_name or 'openai/clip-vit-base-patch32', dim=dim, device=device)
    if key in {'sentence-transformer', 'sentence_transformer', 'sbert'}:
        return SentenceTransformerTextEncoder(model_name or 'all-MiniLM-L6-v2', dim=dim)
    raise ValueError(f'Unknown text encoder kind: {kind}')
