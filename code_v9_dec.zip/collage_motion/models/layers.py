from __future__ import annotations
import math
import torch
from torch import nn
import torch.nn.functional as F

class SinusoidalTimeEmbedding(nn.Module):

    def __init__(self, dim: int) -> None:
        super().__init__()
        self.dim = dim
        self.mlp = nn.Sequential(nn.Linear(dim, dim * 4), nn.SiLU(), nn.Linear(dim * 4, dim))

    def forward(self, timesteps: torch.Tensor) -> torch.Tensor:
        half = self.dim // 2
        device = timesteps.device
        emb = math.log(10000) / max(half - 1, 1)
        freqs = torch.exp(torch.arange(half, device=device) * -emb)
        args = timesteps.float()[:, None] * freqs[None]
        out = torch.cat([torch.sin(args), torch.cos(args)], dim=-1)
        if out.shape[-1] < self.dim:
            out = F.pad(out, (0, self.dim - out.shape[-1]))
        return self.mlp(out)

class TemporalConvBlock(nn.Module):

    def __init__(self, dim: int, hidden_dim: int | None=None, kernel_size: int=3, dropout: float=0.0) -> None:
        super().__init__()
        hidden_dim = hidden_dim or dim
        self.kernel_size = kernel_size
        self.norm = nn.LayerNorm(dim)
        self.fc1 = nn.Linear(dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, t, e, d = x.shape
        h = self.norm(x)
        pad = self.kernel_size // 2
        if pad > 0 and t > 1:
            values = [h]
            for offset in range(1, pad + 1):
                left = torch.cat([h[:, :1], h[:, :-1]], dim=1) if offset == 1 else torch.cat([h[:, :offset], h[:, :-offset]], dim=1)
                right = torch.cat([h[:, offset:], h[:, -offset:]], dim=1)
                values.extend([left, right])
            h = torch.stack(values, dim=0).mean(dim=0)
        h = self.fc2(self.dropout(F.silu(self.fc1(h))))
        return x + h

class MultiKernelTemporalBlock(nn.Module):

    def __init__(self, dim: int, kernels: tuple[int, ...]=(3, 5, 7), dropout: float=0.0) -> None:
        super().__init__()
        self.branches = nn.ModuleList([TemporalConvBlock(dim, dim, k, dropout=dropout) for k in kernels])
        self.norm = nn.LayerNorm(dim * len(kernels))
        self.mix = nn.Linear(dim * len(kernels), dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = torch.cat([branch(x) for branch in self.branches], dim=-1)
        return x + self.mix(self.norm(h))

class FullyConnectedGraphAttentionBlock(nn.Module):

    def __init__(self, dim: int, heads: int=8, dropout: float=0.0) -> None:
        super().__init__()
        if dim % heads != 0:
            raise ValueError(f'dim={dim} must be divisible by heads={heads}')
        self.dim = dim
        self.heads = heads
        self.head_dim = dim // heads
        self.scale = self.head_dim ** -0.5
        self.norm = nn.LayerNorm(dim)
        self.qkv = nn.Linear(dim, dim * 3)
        self.out_proj = nn.Linear(dim, dim)
        self.dropout = nn.Dropout(dropout)
        self.ff = nn.Sequential(nn.LayerNorm(dim), nn.Linear(dim, dim * 4), nn.GELU(), nn.Dropout(dropout), nn.Linear(dim * 4, dim))

    def forward(self, x: torch.Tensor, entity_mask: torch.Tensor | None=None, adjacency: torch.Tensor | None=None) -> torch.Tensor:
        b, t, e, d = x.shape
        h = self.norm(x)
        qkv = self.qkv(h).reshape(b, t, e, 3, self.heads, self.head_dim).permute(3, 0, 1, 4, 2, 5)
        q, k, v = qkv[0], qkv[1], qkv[2]
        scores = torch.matmul(q, k.transpose(-2, -1)) * self.scale
        if adjacency is not None:
            if adjacency.ndim == 2:
                adj = adjacency.to(device=x.device, dtype=torch.bool).reshape(1, 1, 1, e, e)
            else:
                adj = adjacency.to(device=x.device, dtype=torch.bool).reshape(b, 1, 1, e, e)
            scores = scores.masked_fill(~adj, torch.finfo(scores.dtype).min)
        if entity_mask is not None:
            valid = (entity_mask > 0.5).to(x.device).reshape(b, 1, 1, 1, e)
            scores = scores.masked_fill(~valid, torch.finfo(scores.dtype).min)
        attn = torch.softmax(scores, dim=-1)
        attn = self.dropout(attn)
        out = torch.matmul(attn, v).transpose(2, 3).reshape(b, t, e, d)
        x = x + self.out_proj(out)
        x = x + self.ff(x)
        if entity_mask is not None:
            x = x * entity_mask[:, None, :, None]
        return x
EntityAttentionBlock = FullyConnectedGraphAttentionBlock

class CueConcatConditioner(nn.Module):

    def __init__(self, dim: int, cue_dim: int, dropout: float=0.0) -> None:
        super().__init__()
        self.cue_proj = nn.Linear(cue_dim, cue_dim)
        self.fuse = nn.Sequential(nn.LayerNorm(dim + cue_dim), nn.Linear(dim + cue_dim, dim), nn.GELU(), nn.Dropout(dropout), nn.Linear(dim, dim))

    def forward(self, x: torch.Tensor, cue: torch.Tensor) -> torch.Tensor:
        b, t, e, _ = x.shape
        if cue.ndim == 2:
            c = self.cue_proj(cue)[:, None, None, :].expand(b, t, e, -1)
        elif cue.ndim == 3:
            if cue.shape[1] == e:
                c = self.cue_proj(cue)[:, None, :, :].expand(b, t, e, -1)
            elif cue.shape[1] == 1:
                c = self.cue_proj(cue[:, 0])[:, None, None, :].expand(b, t, e, -1)
            else:
                c = self.cue_proj(cue.mean(dim=1))[:, None, None, :].expand(b, t, e, -1)
        else:
            raise ValueError(f'Unsupported cue shape for CueConcatConditioner: {tuple(cue.shape)}')
        return x + self.fuse(torch.cat([x, c], dim=-1))

class CueCrossAttentionBlock(nn.Module):

    def __init__(self, dim: int, cue_dim: int, heads: int=8, dropout: float=0.0) -> None:
        super().__init__()
        if dim % heads != 0:
            raise ValueError(f'dim={dim} must be divisible by heads={heads}')
        self.dim = dim
        self.heads = heads
        self.head_dim = dim // heads
        self.scale = self.head_dim ** -0.5
        self.q_norm = nn.LayerNorm(dim)
        self.q_proj = nn.Linear(dim, dim)
        self.k_proj = nn.Linear(cue_dim, dim)
        self.v_proj = nn.Linear(cue_dim, dim)
        self.out_proj = nn.Linear(dim, dim)
        self.dropout = nn.Dropout(dropout)
        self.ff = nn.Sequential(nn.LayerNorm(dim), nn.Linear(dim, dim * 4), nn.GELU(), nn.Dropout(dropout), nn.Linear(dim * 4, dim))

    def _split(self, x: torch.Tensor) -> torch.Tensor:
        return x.reshape(*x.shape[:-1], self.heads, self.head_dim).transpose(-3, -2)

    def forward(self, x: torch.Tensor, cues: torch.Tensor) -> torch.Tensor:
        b, t, e, d = x.shape
        q = self.q_proj(self.q_norm(x)).reshape(b, t, e, self.heads, self.head_dim).permute(0, 1, 3, 2, 4)
        if cues.ndim == 3 and cues.shape[1] == e:
            k = self.k_proj(cues).reshape(b, e, self.heads, self.head_dim).permute(0, 2, 1, 3)
            v = self.v_proj(cues).reshape(b, e, self.heads, self.head_dim).permute(0, 2, 1, 3)
            out = v[:, None].expand(b, t, self.heads, e, self.head_dim).permute(0, 1, 3, 2, 4).reshape(b, t, e, d)
            h = self.out_proj(out)
            return x + h + self.ff(x + h)
        if cues.ndim == 2:
            cues = cues[:, None, :]
        k = self.k_proj(cues).reshape(b, cues.shape[1], self.heads, self.head_dim).permute(0, 2, 1, 3)
        v = self.v_proj(cues).reshape(b, cues.shape[1], self.heads, self.head_dim).permute(0, 2, 1, 3)
        qf = q.permute(0, 2, 1, 3, 4).reshape(b, self.heads, t * e, self.head_dim)
        scores = torch.matmul(qf, k.transpose(-2, -1)) * self.scale
        attn = self.dropout(torch.softmax(scores, dim=-1))
        out = torch.matmul(attn, v).transpose(1, 2).reshape(b, t, e, d)
        h = self.out_proj(out)
        return x + h + self.ff(x + h)

class HierarchicalCueCrossAttention(nn.Module):

    def __init__(self, dim: int, cue_dim: int, num_levels: int=6, heads: int=8, dropout: float=0.0) -> None:
        super().__init__()
        self.num_levels = num_levels
        self.cross = nn.ModuleList([CueCrossAttentionBlock(dim, cue_dim, heads=heads, dropout=dropout) for _ in range(num_levels)])
        self.fuse = nn.Sequential(nn.LayerNorm(dim * (num_levels + 1)), nn.Linear(dim * (num_levels + 1), dim))

    def forward(self, x: torch.Tensor, cues: torch.Tensor, cue_weights: torch.Tensor | None=None) -> torch.Tensor:
        outs = [x]
        b = x.shape[0]
        for level, block in enumerate(self.cross):
            if cues.ndim == 4:
                cue = cues[:, min(level, cues.shape[1] - 1)]
            else:
                cue = cues[:, min(level, cues.shape[1] - 1)]
            h = block(x, cue)
            if cue_weights is not None:
                w = cue_weights[:, min(level, cue_weights.shape[1] - 1)].reshape(b, 1, 1, 1).to(h.dtype)
                h = x + (h - x) * w
            outs.append(h)
        return self.fuse(torch.cat(outs, dim=-1))

class MotionModelBlock(nn.Module):

    def __init__(self, dim: int, cue_dim: int, num_levels: int=6, heads: int=8, dropout: float=0.0) -> None:
        super().__init__()
        self.time_proj = nn.Linear(dim, dim)
        self.temporal_1 = MultiKernelTemporalBlock(dim, kernels=(3, 5, 7), dropout=dropout)
        self.gat_1 = FullyConnectedGraphAttentionBlock(dim, heads=heads, dropout=dropout)
        self.cue = HierarchicalCueCrossAttention(dim, cue_dim, num_levels=num_levels, heads=heads, dropout=dropout)
        self.temporal_2 = MultiKernelTemporalBlock(dim, kernels=(3, 5, 7), dropout=dropout)
        self.gat_2 = FullyConnectedGraphAttentionBlock(dim, heads=heads, dropout=dropout)

    def forward(self, x: torch.Tensor, time_emb: torch.Tensor, cues: torch.Tensor, cue_weights: torch.Tensor | None=None, entity_mask: torch.Tensor | None=None, adjacency: torch.Tensor | None=None) -> torch.Tensor:
        x = x + self.time_proj(time_emb)[:, None, None, :]
        x = self.temporal_1(x)
        x = self.gat_1(x, entity_mask=entity_mask, adjacency=adjacency)
        x = self.cue(x, cues, cue_weights=cue_weights)
        x = self.temporal_2(x)
        x = self.gat_2(x, entity_mask=entity_mask, adjacency=adjacency)
        if entity_mask is not None:
            x = x * entity_mask[:, None, :, None]
        return x

def downsample_time(x: torch.Tensor) -> torch.Tensor:
    b, t, e, d = x.shape
    if t <= 1:
        return x
    h = x.permute(0, 2, 3, 1).reshape(b * e, d, t)
    h = F.avg_pool1d(h, kernel_size=2, stride=2, ceil_mode=True)
    return h.reshape(b, e, d, h.shape[-1]).permute(0, 3, 1, 2)

def upsample_time(x: torch.Tensor, target_t: int) -> torch.Tensor:
    b, t, e, d = x.shape
    if t == target_t:
        return x
    h = x.permute(0, 2, 3, 1).reshape(b * e, d, t)
    h = F.interpolate(h, size=target_t, mode='linear', align_corners=False)
    return h.reshape(b, e, d, target_t).permute(0, 3, 1, 2)
