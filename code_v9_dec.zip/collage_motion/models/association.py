from __future__ import annotations
from typing import Any
import torch
from torch import nn
import torch.nn.functional as F
from collage_motion.training.losses import symmetric_contrastive_loss

class CodeCueAssociation(nn.Module):

    def __init__(self, num_levels: int=6, latent_dim: int=512, text_dim: int=512, projection_dim: int=512, top_k: int=8, temperature: float=0.07) -> None:
        super().__init__()
        self.num_levels = num_levels
        self.latent_dim = latent_dim
        self.text_dim = text_dim
        self.projection_dim = projection_dim
        self.top_k = top_k
        self.temperature = temperature
        self.human_code_proj = nn.ModuleList([nn.Sequential(nn.LayerNorm(latent_dim), nn.Linear(latent_dim, projection_dim)) for _ in range(num_levels)])
        self.object_code_proj = nn.ModuleList([nn.Sequential(nn.LayerNorm(latent_dim), nn.Linear(latent_dim, projection_dim)) for _ in range(num_levels)])
        self.cue_proj = nn.ModuleList([nn.Sequential(nn.LayerNorm(text_dim), nn.Linear(text_dim, projection_dim)) for _ in range(num_levels)])
        self.aug_proj = nn.ModuleList([nn.Linear(text_dim + projection_dim * top_k, text_dim) for _ in range(num_levels)])

    def _normalize_codebooks(self, codebooks: Any) -> dict[str, list[torch.Tensor]]:
        if isinstance(codebooks, dict):
            return {'human': list(codebooks.get('human', [])), 'object': list(codebooks.get('object', []))}
        return {'human': list(codebooks), 'object': []}

    def _mode_targets(self, idx: torch.Tensor) -> torch.Tensor:
        if idx.ndim == 2:
            return idx.mode(dim=1).values[:, None]
        if idx.ndim == 3:
            return idx.mode(dim=1).values
        raise ValueError(f'Unsupported index tensor shape: {tuple(idx.shape)}')

    def code_embeddings_from_indices(self, codebooks: Any, indices: Any, entity_mask: torch.Tensor | None=None) -> list[torch.Tensor]:
        books = self._normalize_codebooks(codebooks)
        if isinstance(indices, dict):
            human_indices = indices.get('human', [])
            object_indices = indices.get('object', [])
        else:
            human_indices = indices
            object_indices = []
        pooled = []
        for level in range(self.num_levels):
            vecs = []
            if level < len(human_indices) and level < len(books['human']):
                emb_h = F.embedding(human_indices[level], books['human'][level])
                if entity_mask is not None:
                    mh = entity_mask[:, None, :emb_h.shape[2], None].to(emb_h.dtype)
                    emb_h = emb_h * mh
                    vecs.append(emb_h.sum(dim=(1, 2)) / mh.sum(dim=(1, 2)).clamp_min(1.0))
                else:
                    vecs.append(emb_h.mean(dim=(1, 2)))
            if level < len(object_indices) and level < len(books['object']) and object_indices[level].shape[2] > 0:
                emb_o = F.embedding(object_indices[level], books['object'][level])
                vecs.append(emb_o.mean(dim=(1, 2)))
            if vecs:
                pooled.append(torch.stack(vecs, dim=0).mean(dim=0))
            else:
                device_ref = books['human'][0] if books['human'] else torch.empty(1, self.latent_dim)
                pooled.append(device_ref.new_zeros(1, self.latent_dim))
        return pooled

    def contrastive_loss(self, code_vectors: list[torch.Tensor], cues: torch.Tensor) -> dict[str, torch.Tensor]:
        losses = []
        for level in range(self.num_levels):
            code = self.human_code_proj[level](code_vectors[level])
            cue = self.cue_proj[level](cues[:, min(level, cues.shape[1] - 1)])
            losses.append(symmetric_contrastive_loss(code, cue, self.temperature))
        loss = torch.stack(losses).mean()
        return {'loss': loss, 'assoc': loss}

    def contrastive_loss_from_indices(self, codebooks: Any, indices: Any, cues: torch.Tensor, entity_cues: dict[str, torch.Tensor] | None=None, entity_mask: torch.Tensor | None=None) -> dict[str, torch.Tensor]:
        books = self._normalize_codebooks(codebooks)
        human_indices = indices.get('human', []) if isinstance(indices, dict) else indices
        object_indices = indices.get('object', []) if isinstance(indices, dict) else []
        losses = []
        human_losses = []
        object_losses = []
        for level in range(self.num_levels):
            if level < len(human_indices) and level < len(books['human']):
                targets = self._mode_targets(human_indices[level])
                valid = None if entity_mask is None else entity_mask[:, :targets.shape[1]] > 0.5
                if entity_cues is not None:
                    parts = []
                    for hidx in range(targets.shape[1]):
                        key = 'person_1' if hidx == 0 else 'person_2' if hidx == 1 else 'both'
                        parts.append(entity_cues.get(key, entity_cues.get('both', cues))[:, min(level, cues.shape[1] - 1)])
                    cue_level = torch.stack(parts, dim=1)
                else:
                    cue_level = cues[:, min(level, cues.shape[1] - 1)][:, None, :].expand(targets.shape[0], targets.shape[1], cues.shape[-1])
                code_p = F.normalize(self.human_code_proj[level](books['human'][level]), dim=-1)
                cue_p = F.normalize(self.cue_proj[level](cue_level.reshape(-1, cue_level.shape[-1])), dim=-1)
                logits = cue_p @ code_p.t() / self.temperature
                flat_targets = targets.reshape(-1).long().clamp(0, books['human'][level].shape[0] - 1)
                if valid is not None:
                    valid_flat = valid.reshape(-1).to(logits.device)
                    if valid_flat.sum() > 0:
                        hloss = F.cross_entropy(logits[valid_flat], flat_targets[valid_flat])
                    else:
                        hloss = logits.new_tensor(0.0)
                else:
                    hloss = F.cross_entropy(logits, flat_targets)
                losses.append(hloss)
                human_losses.append(hloss)
            if level < len(object_indices) and level < len(books['object']) and object_indices[level].shape[2] > 0:
                targets = self._mode_targets(object_indices[level])
                valid = None if entity_mask is None else entity_mask[:, -targets.shape[1]:] > 0.5
                cue_source = entity_cues.get('object', cues) if entity_cues is not None else cues
                cue_level = cue_source[:, min(level, cue_source.shape[1] - 1)][:, None, :].expand(targets.shape[0], targets.shape[1], cues.shape[-1])
                code_p = F.normalize(self.object_code_proj[level](books['object'][level]), dim=-1)
                cue_p = F.normalize(self.cue_proj[level](cue_level.reshape(-1, cue_level.shape[-1])), dim=-1)
                logits = cue_p @ code_p.t() / self.temperature
                flat_targets = targets.reshape(-1).long().clamp(0, books['object'][level].shape[0] - 1)
                if valid is not None:
                    valid_flat = valid.reshape(-1).to(logits.device)
                    if valid_flat.sum() > 0:
                        oloss = F.cross_entropy(logits[valid_flat], flat_targets[valid_flat])
                    else:
                        oloss = logits.new_tensor(0.0)
                else:
                    oloss = F.cross_entropy(logits, flat_targets)
                losses.append(oloss)
                object_losses.append(oloss)
        if not losses:
            ref = cues.new_tensor(0.0)
            return {'loss': ref, 'assoc': ref, 'human_assoc': ref, 'object_assoc': ref}
        loss = torch.stack(losses).mean()
        human = torch.stack(human_losses).mean() if human_losses else loss.new_tensor(0.0)
        obj = torch.stack(object_losses).mean() if object_losses else loss.new_tensor(0.0)
        return {'loss': loss, 'assoc': loss, 'human_assoc': human, 'object_assoc': obj}

    def _project_codebook(self, level: int, codebooks: dict[str, list[torch.Tensor]]) -> torch.Tensor:
        parts = []
        if level < len(codebooks['human']):
            parts.append(self.human_code_proj[level](codebooks['human'][level]))
        if level < len(codebooks['object']):
            parts.append(self.object_code_proj[level](codebooks['object'][level]))
        if not parts:
            raise ValueError('No codebooks supplied for association')
        return torch.cat(parts, dim=0)

    def augment_cues(self, cues: torch.Tensor, codebooks: Any) -> torch.Tensor:
        books = self._normalize_codebooks(codebooks)
        outs = []
        for level in range(self.num_levels):
            cue = cues[:, min(level, cues.shape[1] - 1)]
            orig_shape = cue.shape
            cue_flat = cue.reshape(-1, orig_shape[-1])
            cue_p = F.normalize(self.cue_proj[level](cue_flat), dim=-1)
            code_p = F.normalize(self._project_codebook(level, books), dim=-1)
            sim = cue_p @ code_p.t()
            top = sim.topk(k=min(self.top_k, code_p.shape[0]), dim=-1).indices
            selected = F.embedding(top, code_p)
            if selected.shape[1] < self.top_k:
                pad = selected.new_zeros(selected.shape[0], self.top_k - selected.shape[1], selected.shape[2])
                selected = torch.cat([selected, pad], dim=1)
            flat = selected.reshape(selected.shape[0], -1)
            aug = self.aug_proj[level](torch.cat([cue_flat, flat], dim=-1))
            outs.append(aug.reshape(*orig_shape))
        return torch.stack(outs, dim=1)
