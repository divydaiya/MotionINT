from __future__ import annotations
import json
import re
from typing import Any

PAPER_LEVEL_NAMES = [
    'Overall Objective',
    'Initial Positioning and Approach',
    'Contact Points and Gripping Mechanics',
    'Upper Body Posture and Coordination',
    'Lower Body Movements and Step Synchronization',
    'Fine-Grained Adjustments and Limb Coordination',
]
AGENT_KEYS = ['person_1', 'person_2', 'object', 'both']
SYSTEM_PROMPT = '\n'.join([
    'You are a motion-planning annotator for COLLAGE, a collaborative human-object-human motion generation model.',
    'Generate hierarchical planning cues exactly in the COLLAGE Fig. 2 style: high-level goal first, then positioning, contact/grip mechanics, upper-body posture, lower-body synchronization, and fine-grained limb coordination.',
    'Preserve separate Person 1 and Person 2 roles. Do not merge, average, or swap them.',
    'Return only valid JSON. Do not include markdown fences, prose, or explanations outside JSON.',
])
FIGURE_PROMPT_HEADER = 'Hierarchical Planning Cues from LLM for Collaborative Task'
FIGURE2_CHAIR_EXAMPLE = [
    {
        'level': 1,
        'name': PAPER_LEVEL_NAMES[0],
        'person_1': 'Coordinate with Person 2 to carry a chair from the left side of the room to the right.',
        'person_2': 'Coordinate with Person 1 to carry the same chair from the left side of the room to the right.',
        'object': 'The chair is the shared object being transported across the room.',
        'both': 'Persons 1 and 2 coordinate to carry a chair from the left side of the room to the right.',
    },
    {
        'level': 2,
        'name': PAPER_LEVEL_NAMES[1],
        'person_1': 'Move to the left side of the chair and face the chair directly.',
        'person_2': 'Approach from the right side of the chair and face the chair directly.',
        'object': 'The chair remains between the two agents while they establish initial contact.',
        'both': 'Both face the chair directly, establishing initial contact from complementary sides.',
    },
    {
        'level': 3,
        'name': PAPER_LEVEL_NAMES[2],
        'person_1': 'Grasp the back of the chair with the left hand.',
        'person_2': 'Grip the seat of the chair firmly with the right hand.',
        'object': 'The chair is securely held by both individuals at stable contact points.',
        'both': 'Both establish simultaneous, stable grips before lifting or carrying.',
    },
    {
        'level': 4,
        'name': PAPER_LEVEL_NAMES[3],
        'person_1': 'Maintain level shoulders to evenly distribute the weight.',
        'person_2': 'Keep elbows slightly bent to maintain control.',
        'object': 'The chair remains level under the coordinated upper-body support.',
        'both': 'Both maintain upright posture for proper balance.',
    },
    {
        'level': 5,
        'name': PAPER_LEVEL_NAMES[4],
        'person_1': 'Take careful synchronized steps forward.',
        'person_2': 'Synchronize steps with Person 1 to ensure balance.',
        'object': 'The chair moves smoothly with each synchronized step.',
        'both': 'Both match weight shifts forward with each step for smooth motion.',
    },
    {
        'level': 6,
        'name': PAPER_LEVEL_NAMES[5],
        'person_1': 'Extend the left arm to guide the chair direction.',
        'person_2': "Adjust the right arm to adapt to the chair's angle as needed.",
        'object': 'The chair angle is adjusted smoothly to avoid obstacles and maintain the path.',
        'both': 'Both make minor adjustments to avoid obstacles and maintain a smooth path.',
    },
]


def build_prompt(caption: str, motion_id: str | int | None = None, levels: int = 6) -> list[dict[str, str]]:
    level_names = PAPER_LEVEL_NAMES[:levels]
    while len(level_names) < levels:
        level_names.append(f'Additional Motion Detail {len(level_names) + 1}')
    level_lines = '\n'.join([f'Level {i + 1}: {name}' for i, name in enumerate(level_names)])
    example_lines = '\n'.join([
        f"Level {item['level']}: {item['name']}\nPerson1: {item['person_1']}\nPerson2: {item['person_2']}\nObject: {item['object']}\nBoth: {item['both']}"
        for item in FIGURE2_CHAIR_EXAMPLE[:levels]
    ])
    id_text = '' if motion_id is None else f'Motion id: {motion_id}\n'
    json_shape = {
        'motion_id': None if motion_id is None else str(motion_id),
        'caption': caption,
        'task_summary': 'one sentence',
        'entities': {'person_1': 'role and starting side', 'person_2': 'role and starting side', 'object': 'object name or none'},
        'hierarchical_cues': [
            {'level': i + 1, 'name': name, 'person_1': 'specific cue for person 1', 'person_2': 'specific cue for person 2', 'object': 'specific object cue or none', 'both': 'joint coordination cue'}
            for i, name in enumerate(level_names)
        ],
    }
    user_prompt = f'''
{FIGURE_PROMPT_HEADER}

This structure guides two agents working together. Instructions must span multiple levels, from high-level goals to fine-grained control.

Paper Fig. 2 example for carrying a chair:
{example_lines}

{id_text}Caption: {caption}

Task:
Decompose the collaborative task into exactly {levels} hierarchical planning cues using these levels:
{level_lines}

For every level, write separate cues for:
- person_1: the first human or humanoid agent
- person_2: the second human or humanoid agent
- object: the shared object if present, otherwise "none"
- both: joint coordination between the two agents and object

Required physical details:
- relative initial positions and approach direction
- contact points, gripping mechanics, or partner-contact mechanics
- upper-body posture and coordination
- lower-body movement, foot placement, and step synchronization
- fine-grained limb coordination, velocity continuity, stabilization, obstacle avoidance, and release

Rules:
- Use only details implied by the caption or physically necessary for the task.
- Preserve Person 1 and Person 2 as distinct actors.
- Mention left/right only when inferable; otherwise use complementary but neutral sides.
- Avoid camera, rendering, style, and emotion-only language.
- Return only valid JSON with exactly this shape and exactly {levels} cue records:
{json.dumps(json_shape, indent=2, ensure_ascii=False)}
'''.strip()
    return [{'role': 'system', 'content': SYSTEM_PROMPT}, {'role': 'user', 'content': user_prompt}]


def _strip_code_fences(text: str) -> str:
    text = text.strip()
    if text.startswith('```'):
        text = re.sub(r'^```(?:json)?\s*', '', text, flags=re.IGNORECASE)
        text = re.sub(r'\s*```$', '', text)
    return text.strip()


def _extract_first_json_object(text: str) -> str:
    text = _strip_code_fences(text)
    start = text.find('{')
    if start < 0:
        raise ValueError('LLM response did not contain a JSON object')
    depth = 0
    in_string = False
    escape = False
    for idx in range(start, len(text)):
        ch = text[idx]
        if in_string:
            if escape:
                escape = False
            elif ch == '\\':
                escape = True
            elif ch == '"':
                in_string = False
            continue
        if ch == '"':
            in_string = True
        elif ch == '{':
            depth += 1
        elif ch == '}':
            depth -= 1
            if depth == 0:
                return text[start:idx + 1]
    raise ValueError('LLM response contained an unterminated JSON object')


def parse_plan_json(text: str) -> dict[str, Any]:
    raw = _strip_code_fences(text)
    try:
        obj = json.loads(raw)
    except json.JSONDecodeError:
        obj = json.loads(_extract_first_json_object(raw))
    if not isinstance(obj, dict):
        raise ValueError('LLM plan must be a JSON object')
    return obj


def _coerce_text(value: Any) -> str:
    if value is None:
        return ''
    if isinstance(value, str):
        return ' '.join(value.split())
    if isinstance(value, dict):
        parts = []
        for k, v in value.items():
            text = _coerce_text(v)
            if text:
                parts.append(f'{k}: {text}')
        return ' '.join(parts)
    if isinstance(value, list):
        return '; '.join((_coerce_text(v) for v in value if _coerce_text(v)))
    return ' '.join(str(value).split())


def _caption_mentions_chair_carry(caption: str) -> bool:
    text = caption.lower()
    return 'chair' in text and any(word in text for word in ('carry', 'carries', 'carrying', 'pick', 'picks', 'lift', 'moves', 'move'))


def _heuristic_level_record(caption: str, level: int, name: str) -> dict[str, Any]:
    if _caption_mentions_chair_carry(caption) and level <= len(FIGURE2_CHAIR_EXAMPLE):
        return dict(FIGURE2_CHAIR_EXAMPLE[level - 1])
    base = caption.strip() or 'collaborative interaction'
    if level == 1:
        return {'level': level, 'name': name, 'person_1': f'Work with Person 2 to complete: {base}.', 'person_2': f'Coordinate with Person 1 to complete: {base}.', 'object': 'shared object if the caption includes one, otherwise none', 'both': f'Maintain a shared objective: {base}.'}
    if level == 2:
        return {'level': level, 'name': name, 'person_1': 'Approach from one stable side with torso oriented toward the partner or object.', 'person_2': 'Approach from the complementary side while preserving safe spacing.', 'object': 'Remain between or near the agents if an object is involved.', 'both': 'Establish complementary spacing and timing before contact or partner interaction.'}
    if level == 3:
        return {'level': level, 'name': name, 'person_1': 'Place hands or contact joints at stable support points.', 'person_2': 'Use complementary contact points without crossing limbs.', 'object': 'Use stable grasp or contact regions and avoid sudden penetration.', 'both': 'Create simultaneous contact and maintain force-consistent separation.'}
    if level == 4:
        return {'level': level, 'name': name, 'person_1': 'Keep shoulders, elbows, and torso aligned with the interaction direction.', 'person_2': "Match upper-body timing and compensate for Person 1's motion.", 'object': 'Follow the upper-body support direction if present.', 'both': 'Coordinate arms and torso so the interaction remains balanced.'}
    if level == 5:
        return {'level': level, 'name': name, 'person_1': 'Step with stable foot placement and smooth root velocity.', 'person_2': 'Synchronize stepping cadence and avoid foot sliding.', 'object': 'Translate or rotate consistently with the shared movement if present.', 'both': 'Synchronize lower-body motion, balance, and relative distance.'}
    return {'level': level, 'name': name, 'person_1': 'Make small hand, wrist, elbow, torso, and foot adjustments for smooth motion.', 'person_2': 'Make complementary fine adjustments and stabilize the ending pose.', 'object': 'Maintain surface contact without jitter or penetration if present.', 'both': 'Finish with smooth velocity continuity, stable contact, obstacle avoidance, and coordinated release.'}


def normalize_hierarchical_cues(raw_plan: dict[str, Any], caption: str, levels: int = 6) -> list[dict[str, Any]]:
    raw = raw_plan.get('hierarchical_cues') or raw_plan.get('plan') or raw_plan.get('cues') or []
    out: list[dict[str, Any]] = []
    if isinstance(raw, dict):
        raw = list(raw.values())
    if isinstance(raw, list):
        for i, item in enumerate(raw[:levels]):
            name = PAPER_LEVEL_NAMES[i] if i < len(PAPER_LEVEL_NAMES) else f'Additional Motion Detail {i + 1}'
            if isinstance(item, dict):
                rec = {
                    'level': int(item.get('level', i + 1)),
                    'name': _coerce_text(item.get('name') or name) or name,
                    'person_1': _coerce_text(item.get('person_1') or item.get('Person 1') or item.get('person1') or item.get('agent_1') or item.get('human_1') or item.get('cue')),
                    'person_2': _coerce_text(item.get('person_2') or item.get('Person 2') or item.get('person2') or item.get('agent_2') or item.get('human_2') or item.get('cue')),
                    'object': _coerce_text(item.get('object') or item.get('Object') or item.get('shared_object') or 'none'),
                    'both': _coerce_text(item.get('both') or item.get('Both') or item.get('joint') or item.get('coordination') or item.get('cue')),
                }
            else:
                text = _coerce_text(item)
                rec = {'level': i + 1, 'name': name, 'person_1': text, 'person_2': text, 'object': 'none', 'both': text}
            out.append(rec)
    while len(out) < levels:
        out.append(_heuristic_level_record(caption, len(out) + 1, PAPER_LEVEL_NAMES[len(out)] if len(out) < len(PAPER_LEVEL_NAMES) else f'Additional Motion Detail {len(out) + 1}'))
    return out[:levels]


def cue_record_to_text(record: dict[str, Any]) -> str:
    name = _coerce_text(record.get('name'))
    p1 = _coerce_text(record.get('person_1'))
    p2 = _coerce_text(record.get('person_2'))
    obj = _coerce_text(record.get('object'))
    both = _coerce_text(record.get('both'))
    parts = [f'{name}.'] if name else []
    if p1:
        parts.append(f'Person 1: {p1}')
    if p2:
        parts.append(f'Person 2: {p2}')
    if obj and obj.lower() != 'none':
        parts.append(f'Object: {obj}')
    if both:
        parts.append(f'Both: {both}')
    return ' '.join(parts)


def extract_cues(record: dict[str, Any], levels: int = 6) -> list[str]:
    cues = normalize_hierarchical_cues(record.get('llm_plan', record), caption=str(record.get('caption') or record.get('description') or 'collaborative interaction'), levels=levels)
    return [cue_record_to_text(c) for c in cues]


def extract_entity_cues(record: dict[str, Any], levels: int = 6) -> dict[str, list[str]]:
    caption = str(record.get('caption') or record.get('description') or 'collaborative interaction')
    cues = normalize_hierarchical_cues(record.get('llm_plan', record), caption=caption, levels=levels)
    entity_cues = {key: [] for key in AGENT_KEYS}
    for cue in cues:
        for key in AGENT_KEYS:
            value = _coerce_text(cue.get(key))
            if not value and key == 'object':
                value = 'none'
            if not value:
                value = cue_record_to_text(cue)
            entity_cues[key].append(f"{cue.get('name', '')}. {value}".strip())
    return entity_cues


def normalize_plan_record(raw_plan: dict[str, Any], caption: str, motion_id: str | int | None = None, levels: int = 6, model_id: str | None = None, prompt_version: str = 'collage-figure2-paper-v3') -> dict[str, Any]:
    cue_records = normalize_hierarchical_cues(raw_plan, caption=caption, levels=levels)
    cues = [cue_record_to_text(c) for c in cue_records]
    return {
        'motion_number': None if motion_id is None else str(motion_id),
        'motion_id': None if motion_id is None else str(motion_id),
        'caption': caption,
        'description': caption,
        'plan': cues,
        'cues': cues,
        'hierarchical_cues': cue_records,
        'entity_cues': {key: [f"{c.get('name', '')}. {_coerce_text(c.get(key))}".strip() for c in cue_records] for key in AGENT_KEYS},
        'llm_plan': raw_plan,
        'levels': levels,
        'level_names': PAPER_LEVEL_NAMES[:levels],
        'model_id': model_id,
        'prompt_version': prompt_version,
    }
