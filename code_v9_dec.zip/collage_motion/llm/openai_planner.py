from __future__ import annotations
from dataclasses import dataclass
import os
from typing import Any
from .plan_schema import build_prompt, normalize_plan_record, parse_plan_json

@dataclass
class OpenAIPlannerConfig:
    model: str = 'gpt-4'
    api_key_env: str = 'OPENAI_API_KEY'
    base_url_env: str = 'OPENAI_BASE_URL'
    base_url: str | None = None
    temperature: float = 0.0
    max_tokens: int = 900
    levels: int = 6
    timeout: float = 60.0

class OpenAIPlanner:

    def __init__(self, config: OpenAIPlannerConfig | None=None) -> None:
        self.config = config or OpenAIPlannerConfig()
        try:
            from openai import OpenAI
        except ImportError as exc:
            raise ImportError('Install OpenAI API support with: pip install openai') from exc
        api_key = os.getenv(self.config.api_key_env)
        if not api_key:
            raise RuntimeError(f'Missing API key. Set {self.config.api_key_env}=your_api_key')
        base_url = self.config.base_url or os.getenv(self.config.base_url_env) or None
        kwargs: dict[str, Any] = {'api_key': api_key, 'timeout': self.config.timeout}
        if base_url:
            kwargs['base_url'] = base_url
        self.client = OpenAI(**kwargs)

    def generate_raw(self, caption: str, motion_id: str | int | None=None) -> str:
        messages = build_prompt(caption, motion_id=motion_id, levels=self.config.levels)
        response = self.client.chat.completions.create(model=self.config.model, messages=messages, temperature=self.config.temperature, max_tokens=self.config.max_tokens, response_format={'type': 'json_object'})
        return response.choices[0].message.content or '{}'

    def plan(self, caption: str, motion_id: str | int | None=None, retry: int=1) -> dict[str, Any]:
        last_error: Exception | None = None
        for attempt in range(retry + 1):
            try:
                raw_plan = parse_plan_json(self.generate_raw(caption, motion_id=motion_id))
                return normalize_plan_record(raw_plan, caption=caption, motion_id=motion_id, levels=self.config.levels, model_id=self.config.model)
            except Exception as exc:
                last_error = exc
                if attempt >= retry:
                    break
        raise RuntimeError(f'Could not obtain a valid JSON plan for {caption!r}: {last_error}')
