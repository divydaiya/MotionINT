from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import torch
from .plan_schema import build_prompt, normalize_plan_record, parse_plan_json

@dataclass
class LLMPlannerConfig:
    model_path: str
    model_id: str | None = None
    levels: int = 6
    max_new_tokens: int = 768
    temperature: float = 0.0
    top_p: float = 0.95
    repetition_penalty: float = 1.05
    torch_dtype: str = 'auto'
    device_map: str | None = 'auto'
    trust_remote_code: bool = False
    load_in_4bit: bool = False
    load_in_8bit: bool = False

def _resolve_dtype(name: str) -> Any:
    if name in {'auto', 'none', 'None', ''}:
        return 'auto'
    name = name.lower()
    if name in {'bf16', 'bfloat16'}:
        return torch.bfloat16
    if name in {'fp16', 'float16', 'half'}:
        return torch.float16
    if name in {'fp32', 'float32', 'full'}:
        return torch.float32
    raise ValueError(f'Unknown torch dtype: {name}')

class LocalLLMPlanner:

    def __init__(self, config: LLMPlannerConfig) -> None:
        self.config = config
        try:
            from transformers import AutoModelForCausalLM, AutoTokenizer
        except ImportError as exc:
            raise ImportError('Install LLM dependencies with: pip install transformers huggingface_hub accelerate sentencepiece') from exc
        self.tokenizer = AutoTokenizer.from_pretrained(config.model_path, trust_remote_code=config.trust_remote_code)
        quantization_config = None
        if config.load_in_4bit or config.load_in_8bit:
            try:
                from transformers import BitsAndBytesConfig
            except ImportError as exc:
                raise ImportError('4-bit/8-bit loading requires bitsandbytes and a recent transformers version') from exc
            quantization_config = BitsAndBytesConfig(load_in_4bit=config.load_in_4bit, load_in_8bit=config.load_in_8bit)
        kwargs: dict[str, Any] = {'trust_remote_code': config.trust_remote_code, 'torch_dtype': _resolve_dtype(config.torch_dtype)}
        if config.device_map:
            kwargs['device_map'] = config.device_map
        if quantization_config is not None:
            kwargs['quantization_config'] = quantization_config
        self.model = AutoModelForCausalLM.from_pretrained(config.model_path, **kwargs)
        self.model.eval()
        if not getattr(self.tokenizer, 'pad_token_id', None):
            self.tokenizer.pad_token = self.tokenizer.eos_token

    @property
    def device(self) -> torch.device:
        if hasattr(self.model, 'device'):
            return self.model.device
        return next(self.model.parameters()).device

    def _format_messages(self, messages: list[dict[str, str]]) -> torch.Tensor:
        if hasattr(self.tokenizer, 'apply_chat_template'):
            try:
                encoded = self.tokenizer.apply_chat_template(messages, add_generation_prompt=True, return_tensors='pt')
                return encoded.to(self.device)
            except Exception:
                pass
        prompt = '\n\n'.join([f"{m['role'].upper()}: {m['content']}" for m in messages]) + '\n\nASSISTANT:'
        return self.tokenizer(prompt, return_tensors='pt').input_ids.to(self.device)

    @torch.inference_mode()
    def generate_raw(self, caption: str, motion_id: str | int | None=None) -> str:
        messages = build_prompt(caption, motion_id=motion_id, levels=self.config.levels)
        input_ids = self._format_messages(messages)
        do_sample = self.config.temperature > 0
        generated = self.model.generate(input_ids=input_ids, max_new_tokens=self.config.max_new_tokens, do_sample=do_sample, temperature=max(self.config.temperature, 1e-05) if do_sample else None, top_p=self.config.top_p if do_sample else None, repetition_penalty=self.config.repetition_penalty, pad_token_id=self.tokenizer.pad_token_id, eos_token_id=self.tokenizer.eos_token_id)
        new_tokens = generated[0, input_ids.shape[-1]:]
        return self.tokenizer.decode(new_tokens, skip_special_tokens=True).strip()

    @torch.inference_mode()
    def plan(self, caption: str, motion_id: str | int | None=None, retry: int=1) -> dict[str, Any]:
        last_error: Exception | None = None
        for attempt in range(retry + 1):
            raw_text = self.generate_raw(caption, motion_id=motion_id)
            try:
                raw_plan = parse_plan_json(raw_text)
                return normalize_plan_record(raw_plan, caption=caption, motion_id=motion_id, levels=self.config.levels, model_id=self.config.model_id or Path(self.config.model_path).name)
            except Exception as exc:
                last_error = exc
                if attempt >= retry:
                    break
        raise RuntimeError(f'Could not parse LLM JSON for caption {caption!r}: {last_error}')
