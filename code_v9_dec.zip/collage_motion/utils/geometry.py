from __future__ import annotations
import torch


def motion_to_entity_vertices(motion: torch.Tensor, max_points: int | None = 64) -> torch.Tensor:
    usable = (motion.shape[-1] // 3) * 3
    if usable < 3:
        return motion.new_zeros(*motion.shape[:-1], 1, 3)
    if max_points is not None:
        usable = min(usable, max_points * 3)
    return motion[..., :usable].reshape(*motion.shape[:-1], usable // 3, 3)


def point_mesh_min_distance(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    if a.shape[2] == 0 or b.shape[2] == 0:
        return a.new_zeros(a.shape[0], a.shape[1], a.shape[2], b.shape[2])
    diff = a[:, :, :, None, :, None, :] - b[:, :, None, :, None, :, :]
    dist = torch.linalg.norm(diff, dim=-1)
    return dist.amin(dim=(-1, -2))


def infer_contact_map(human_vertices: torch.Tensor, object_vertices: torch.Tensor, threshold: float = 0.04) -> torch.Tensor:
    dist = point_mesh_min_distance(human_vertices, object_vertices)
    return (dist <= threshold).to(human_vertices.dtype)


def contact_map_loss(human_vertices: torch.Tensor, object_vertices: torch.Tensor, contact_map: torch.Tensor, threshold: float = 0.04) -> torch.Tensor:
    if human_vertices.numel() == 0 or object_vertices.numel() == 0 or human_vertices.shape[2] == 0 or object_vertices.shape[2] == 0:
        return human_vertices.new_tensor(0.0)
    dist = point_mesh_min_distance(human_vertices, object_vertices)
    cm = contact_map.to(device=dist.device, dtype=dist.dtype)
    while cm.ndim < dist.ndim:
        cm = cm.unsqueeze(-1)
    cm = cm.expand_as(dist)
    attractive = torch.relu(dist - threshold).pow(2) * cm
    inactive = torch.relu(threshold * 0.5 - dist).pow(2) * (1.0 - cm)
    return (attractive.sum() / cm.sum().clamp_min(1.0)) + (inactive.sum() / (1.0 - cm).sum().clamp_min(1.0))


def mesh_penetration_loss(human_vertices: torch.Tensor, object_vertices: torch.Tensor, signed_distance: torch.Tensor | None = None, margin: float = 0.0) -> torch.Tensor:
    if signed_distance is not None:
        return torch.relu(margin - signed_distance).pow(2).mean()
    if human_vertices.numel() == 0 or object_vertices.numel() == 0 or human_vertices.shape[2] == 0 or object_vertices.shape[2] == 0:
        return human_vertices.new_tensor(0.0)
    obj_center = object_vertices.mean(dim=-2, keepdim=True)
    obj_radius = torch.linalg.norm(object_vertices - obj_center, dim=-1).amax(dim=-1)
    human_to_center = torch.linalg.norm(human_vertices[:, :, :, None, :, :] - obj_center[:, :, None, :, :, :], dim=-1)
    inside_proxy = torch.relu(obj_radius[:, :, None, :, None] + margin - human_to_center)
    return inside_proxy.pow(2).mean()
