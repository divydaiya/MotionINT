from __future__ import annotations
import json
import os
from pathlib import Path
from typing import Any, Iterable, Iterator
import numpy as np

def ensure_dir(path: str | Path) -> Path:
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path

def read_jsonl(path: str | Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    path = Path(path)
    if not path.exists():
        return rows
    with path.open('r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows

def write_jsonl(rows: Iterable[dict[str, Any]], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8') as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + '\n')

def append_jsonl(row: dict[str, Any], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8') as f:
        f.write(json.dumps(row, ensure_ascii=False) + '\n')

def atomic_np_savez(path: str | Path, **arrays: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    np.savez_compressed(tmp, **arrays)
    final_tmp = tmp if tmp.exists() else Path(str(tmp) + '.npz')
    os.replace(final_tmp, path)

def iter_files(root: str | Path, suffixes: tuple[str, ...]) -> Iterator[Path]:
    root = Path(root)
    if not root.exists():
        return
    suffixes = tuple((s.lower() for s in suffixes))
    for path in root.rglob('*'):
        if path.is_file() and path.name.lower().endswith(suffixes):
            yield path

def safe_load_numpy(path: str | Path) -> Any:
    return np.load(Path(path), allow_pickle=True)

def stringify_npz_value(value: Any) -> str:
    if isinstance(value, bytes):
        return value.decode('utf-8', errors='replace')
    if isinstance(value, np.ndarray):
        if value.shape == ():
            return stringify_npz_value(value.item())
        return ' '.join((str(x) for x in value.reshape(-1).tolist()))
    return str(value)

def relative_id(path: str | Path, root: str | Path) -> str:
    path = Path(path)
    root = Path(root)
    try:
        rel = path.relative_to(root)
    except ValueError:
        rel = path
    if rel.suffix:
        rel = rel.with_suffix('')
    return rel.as_posix()
