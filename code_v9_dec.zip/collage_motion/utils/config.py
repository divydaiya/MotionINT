from __future__ import annotations
import copy
from pathlib import Path
from typing import Any, Mapping
import yaml

class ConfigDict(dict):

    def __getattr__(self, key: str) -> Any:
        try:
            value = self[key]
        except KeyError as exc:
            raise AttributeError(key) from exc
        return value

    def __setattr__(self, key: str, value: Any) -> None:
        self[key] = value

def to_config_dict(value: Any) -> Any:
    if isinstance(value, Mapping):
        return ConfigDict({k: to_config_dict(v) for k, v in value.items()})
    if isinstance(value, list):
        return [to_config_dict(v) for v in value]
    return value

def load_config(path: str | Path) -> ConfigDict:
    path = Path(path)
    with path.open('r', encoding='utf-8') as f:
        data = yaml.safe_load(f) or {}
    return to_config_dict(data)

def save_config(config: Mapping[str, Any], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8') as f:
        yaml.safe_dump(to_plain_dict(config), f, sort_keys=False)

def to_plain_dict(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {k: to_plain_dict(v) for k, v in value.items()}
    if isinstance(value, list):
        return [to_plain_dict(v) for v in value]
    return value

def deep_update(base: Mapping[str, Any], updates: Mapping[str, Any]) -> ConfigDict:
    result = copy.deepcopy(to_plain_dict(base))
    for key, value in updates.items():
        if isinstance(value, Mapping) and isinstance(result.get(key), Mapping):
            result[key] = deep_update(result[key], value)
        else:
            result[key] = value
    return to_config_dict(result)

def apply_cli_overrides(config: Mapping[str, Any], overrides: Mapping[str, Any]) -> ConfigDict:
    result = copy.deepcopy(to_plain_dict(config))
    for key, value in overrides.items():
        if value is None:
            continue
        parts = key.split('.')
        cursor = result
        for part in parts[:-1]:
            cursor = cursor.setdefault(part, {})
        cursor[parts[-1]] = value
    return to_config_dict(result)
