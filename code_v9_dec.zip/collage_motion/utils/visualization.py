from __future__ import annotations
from pathlib import Path
import imageio.v2 as imageio
import matplotlib.pyplot as plt
import numpy as np

def extract_xyz_points(motion: np.ndarray, max_points: int=22) -> np.ndarray:
    motion = np.asarray(motion)
    usable = min(motion.shape[-1] // 3 * 3, max_points * 3)
    if usable < 3:
        return np.zeros((motion.shape[0], motion.shape[1], 1, 3), dtype=np.float32)
    return motion[..., :usable].reshape(motion.shape[0], motion.shape[1], usable // 3, 3)

def render_motion(motion: np.ndarray, out_path: str | Path, entity_mask: np.ndarray | None=None, fps: int=15, every: int=1) -> None:
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    pts = extract_xyz_points(motion)
    valid = np.ones(pts.shape[1], dtype=bool) if entity_mask is None else np.asarray(entity_mask) > 0.5
    flat = pts[:, valid].reshape(-1, 3)
    mins = flat.min(axis=0) if flat.size else np.array([-1, -1, -1])
    maxs = flat.max(axis=0) if flat.size else np.array([1, 1, 1])
    center = (mins + maxs) / 2.0
    radius = max(float(np.max(maxs - mins)) * 0.6, 1.0)
    frames = []
    for t in range(0, pts.shape[0], every):
        fig = plt.figure(figsize=(5, 5))
        ax = fig.add_subplot(111, projection='3d')
        for e in range(pts.shape[1]):
            if not valid[e]:
                continue
            p = pts[t, e]
            ax.scatter(p[:, 0], p[:, 2], p[:, 1], s=10)
            root = p[0]
            ax.text(root[0], root[2], root[1], f'E{e}')
        ax.set_xlim(center[0] - radius, center[0] + radius)
        ax.set_ylim(center[2] - radius, center[2] + radius)
        ax.set_zlim(center[1] - radius, center[1] + radius)
        ax.set_xlabel('x')
        ax.set_ylabel('z')
        ax.set_zlabel('y')
        ax.view_init(elev=20, azim=-70)
        fig.canvas.draw()
        rgba = np.asarray(fig.canvas.buffer_rgba())
        frames.append(rgba[:, :, :3].copy())
        plt.close(fig)
    if out_path.suffix.lower() in {'.gif'}:
        imageio.mimsave(out_path, frames, fps=fps)
    else:
        imageio.imwrite(out_path, frames[0])
