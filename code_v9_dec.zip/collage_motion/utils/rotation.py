from __future__ import annotations
import numpy as np

def normalize_quaternion(q: np.ndarray, eps: float=1e-08) -> np.ndarray:
    return q / np.maximum(np.linalg.norm(q, axis=-1, keepdims=True), eps)

def quat_to_matrix(q: np.ndarray) -> np.ndarray:
    q = np.asarray(q, dtype=np.float64)
    q = normalize_quaternion(q)
    x, y, z, w = np.moveaxis(q, -1, 0)
    xx, yy, zz = (x * x, y * y, z * z)
    xy, xz, yz = (x * y, x * z, y * z)
    wx, wy, wz = (w * x, w * y, w * z)
    m = np.stack([1 - 2 * (yy + zz), 2 * (xy - wz), 2 * (xz + wy), 2 * (xy + wz), 1 - 2 * (xx + zz), 2 * (yz - wx), 2 * (xz - wy), 2 * (yz + wx), 1 - 2 * (xx + yy)], axis=-1)
    return m.reshape(q.shape[:-1] + (3, 3)).astype(np.float32)

def matrix_to_6d(mat: np.ndarray) -> np.ndarray:
    mat = np.asarray(mat, dtype=np.float32)
    return mat[..., :2].reshape(*mat.shape[:-2], 6)

def axis_angle_to_matrix(vec: np.ndarray, eps: float=1e-08) -> np.ndarray:
    vec = np.asarray(vec, dtype=np.float64)
    angle = np.linalg.norm(vec, axis=-1, keepdims=True)
    axis = vec / np.maximum(angle, eps)
    x, y, z = np.moveaxis(axis, -1, 0)
    c = np.cos(angle[..., 0])
    s = np.sin(angle[..., 0])
    one = 1.0 - c
    m = np.stack([c + x * x * one, x * y * one - z * s, x * z * one + y * s, y * x * one + z * s, c + y * y * one, y * z * one - x * s, z * x * one - y * s, z * y * one + x * s, c + z * z * one], axis=-1)
    return m.reshape(vec.shape[:-1] + (3, 3)).astype(np.float32)

def transform_to_features(transform: np.ndarray) -> np.ndarray:
    arr = np.asarray(transform)
    if arr.ndim >= 3 and arr.shape[-2:] == (4, 4):
        trans = arr[..., :3, 3]
        rot6 = matrix_to_6d(arr[..., :3, :3])
        return np.concatenate([trans, rot6], axis=-1).astype(np.float32)
    if arr.shape[-1] == 7:
        trans = arr[..., :3]
        rot6 = matrix_to_6d(quat_to_matrix(arr[..., 3:7]))
        return np.concatenate([trans, rot6], axis=-1).astype(np.float32)
    if arr.shape[-1] == 6:
        rot6 = matrix_to_6d(axis_angle_to_matrix(arr[..., :3]))
        return np.concatenate([arr[..., 3:6], rot6], axis=-1).astype(np.float32)
    return arr.reshape(arr.shape[0], -1).astype(np.float32)
