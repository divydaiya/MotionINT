from __future__ import annotations
import numpy as np
from scipy import linalg

def motion_l2(a: np.ndarray, b: np.ndarray, mask: np.ndarray | None=None) -> float:
    diff = np.asarray(a) - np.asarray(b)
    if mask is not None:
        diff = diff * mask.reshape(1, -1, 1)
    return float(np.sqrt(np.mean(diff * diff)))

def velocity_l2(a: np.ndarray, b: np.ndarray, mask: np.ndarray | None=None) -> float:
    return motion_l2(np.diff(a, axis=0), np.diff(b, axis=0), mask)

def diversity(samples: np.ndarray) -> float:
    samples = np.asarray(samples)
    if len(samples) < 2:
        return 0.0
    flat = samples.reshape(samples.shape[0], -1)
    total = 0.0
    count = 0
    for i in range(len(flat)):
        for j in range(i + 1, len(flat)):
            total += float(np.linalg.norm(flat[i] - flat[j]) / np.sqrt(flat.shape[1]))
            count += 1
    return total / max(count, 1)

def _motion_feature(motion: np.ndarray) -> np.ndarray:
    m = np.asarray(motion, dtype=np.float64)
    vel = np.diff(m, axis=0) if m.shape[0] > 1 else np.zeros_like(m)
    feats = [m.mean(axis=(0, 1)), m.std(axis=(0, 1)), vel.mean(axis=(0, 1)), vel.std(axis=(0, 1))]
    return np.concatenate(feats, axis=0).astype(np.float64)

def motion_embeddings(motions: list[np.ndarray] | np.ndarray) -> np.ndarray:
    return np.stack([_motion_feature(m) for m in motions], axis=0)

def activation_statistics(emb: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    emb = np.asarray(emb, dtype=np.float64)
    mu = emb.mean(axis=0)
    sigma = np.cov(emb, rowvar=False) if emb.shape[0] > 1 else np.eye(emb.shape[1]) * 1e-06
    return (mu, sigma)

def frechet_distance(real_emb: np.ndarray, gen_emb: np.ndarray) -> float:
    mu1, sigma1 = activation_statistics(real_emb)
    mu2, sigma2 = activation_statistics(gen_emb)
    diff = mu1 - mu2
    covmean = linalg.sqrtm(sigma1 @ sigma2)
    if not np.isfinite(covmean).all():
        eps = np.eye(sigma1.shape[0]) * 1e-06
        covmean = linalg.sqrtm((sigma1 + eps) @ (sigma2 + eps))
    if np.iscomplexobj(covmean):
        covmean = covmean.real
    return float(diff @ diff + np.trace(sigma1 + sigma2 - 2.0 * covmean))

def _normalize(x: np.ndarray) -> np.ndarray:
    return x / np.maximum(np.linalg.norm(x, axis=-1, keepdims=True), 1e-08)

def r_precision(motion_emb: np.ndarray, text_emb: np.ndarray, top_k: tuple[int, ...]=(1, 2, 3)) -> dict[str, float]:
    motion_emb = _normalize(np.asarray(motion_emb, dtype=np.float64))
    text_emb = _normalize(np.asarray(text_emb, dtype=np.float64))
    sim = motion_emb @ text_emb.T
    ranks = np.argsort(-sim, axis=1)
    labels = np.arange(sim.shape[0])
    out = {}
    for k in top_k:
        out[f'R_precision_top_{k}'] = float(np.mean([labels[i] in ranks[i, :k] for i in range(len(labels))]))
    return out

def multimodal_distance(motion_emb: np.ndarray, text_emb: np.ndarray) -> float:
    motion_emb = _normalize(np.asarray(motion_emb, dtype=np.float64))
    text_emb = _normalize(np.asarray(text_emb, dtype=np.float64))
    n = min(len(motion_emb), len(text_emb))
    return float(np.linalg.norm(motion_emb[:n] - text_emb[:n], axis=-1).mean())

def multimodality(grouped_samples: dict[str, list[np.ndarray]]) -> float:
    vals = []
    for samples in grouped_samples.values():
        if len(samples) < 2:
            continue
        vals.append(diversity(np.stack(samples, axis=0)))
    return float(np.mean(vals)) if vals else 0.0

def contact_summary(motion: np.ndarray, entity_mask: np.ndarray | None=None, threshold: float=0.12) -> dict[str, float]:
    x = np.asarray(motion)
    usable = min(x.shape[-1] // 3 * 3, 22 * 3)
    if usable < 3 or x.shape[1] < 2:
        return {'contact_rate': 0.0, 'min_distance': 0.0}
    pts = x[..., :usable].reshape(x.shape[0], x.shape[1], usable // 3, 3)
    mins = []
    for i in range(x.shape[1]):
        if entity_mask is not None and entity_mask[i] < 0.5:
            continue
        for j in range(i + 1, x.shape[1]):
            if entity_mask is not None and entity_mask[j] < 0.5:
                continue
            d = np.linalg.norm(pts[:, i, :, None, :] - pts[:, j, None, :, :], axis=-1).min(axis=(1, 2))
            mins.append(d)
    if not mins:
        return {'contact_rate': 0.0, 'min_distance': 0.0}
    dists = np.concatenate(mins)
    return {'contact_rate': float((dists < threshold).mean()), 'min_distance': float(dists.min())}

def rr_je(pred: np.ndarray, ref: np.ndarray, mask: np.ndarray | None=None) -> float:
    return motion_l2(pred, ref, mask) * 1000.0

def rr_ve(pred: np.ndarray, ref: np.ndarray, mask: np.ndarray | None=None) -> float:
    return velocity_l2(pred, ref, mask) * 1000.0

def contact_accuracy(pred: np.ndarray, ref: np.ndarray, mask: np.ndarray | None=None, threshold: float=0.12) -> float:
    return 100.0 * (1.0 - abs(contact_summary(pred, mask, threshold)['contact_rate'] - contact_summary(ref, mask, threshold)['contact_rate']))

def confidence_interval(values: list[float] | np.ndarray, confidence: float=0.95) -> tuple[float, float]:
    values = np.asarray(values, dtype=np.float64)
    if values.size == 0:
        return (float('nan'), float('nan'))
    mean = float(values.mean())
    if values.size < 2:
        return (mean, 0.0)
    ci = float(1.96 * values.std(ddof=1) / np.sqrt(values.size))
    return (mean, ci)
