from __future__ import annotations
import json
import math
import time
from pathlib import Path
from typing import Any, Iterable
import torch
from torch import nn
from collage_motion.utils.io import ensure_dir
try:
    from torch.utils.tensorboard import SummaryWriter as _TorchSummaryWriter
except Exception:
    _TorchSummaryWriter = None

class NullSummaryWriter:

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        pass

    def add_scalar(self, *args: Any, **kwargs: Any) -> None:
        pass

    def add_text(self, *args: Any, **kwargs: Any) -> None:
        pass

    def flush(self) -> None:
        pass

    def close(self) -> None:
        pass
SummaryWriter = _TorchSummaryWriter or NullSummaryWriter

class AverageMeter:

    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self.total = 0.0
        self.count = 0

    def update(self, value: float, n: int=1) -> None:
        self.total += float(value) * n
        self.count += n

    @property
    def avg(self) -> float:
        return self.total / max(self.count, 1)

def count_parameters(model: nn.Module) -> int:
    return sum((p.numel() for p in model.parameters() if p.requires_grad))

def save_checkpoint(path: str | Path, model: nn.Module, optimizer: torch.optim.Optimizer | None=None, step: int=0, config: dict[str, Any] | None=None, extra: dict[str, Any] | None=None) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    state = {'model': model.state_dict(), 'step': step, 'config': config or {}, 'extra': extra or {}}
    if optimizer is not None:
        state['optimizer'] = optimizer.state_dict()
    torch.save(state, path)

def load_checkpoint(path: str | Path, model: nn.Module, optimizer: torch.optim.Optimizer | None=None, map_location: str | torch.device='cpu') -> dict[str, Any]:
    ckpt = torch.load(path, map_location=map_location)
    state = ckpt['model'] if isinstance(ckpt, dict) and 'model' in ckpt else ckpt
    model.load_state_dict(state, strict=False)
    if optimizer is not None and isinstance(ckpt, dict) and ('optimizer' in ckpt):
        optimizer.load_state_dict(ckpt['optimizer'])
    return ckpt if isinstance(ckpt, dict) else {'model': state}

def make_optimizer(model: nn.Module, lr: float, weight_decay: float=1e-05, kind: str='adamw') -> torch.optim.Optimizer:
    params = [p for p in model.parameters() if p.requires_grad]
    if kind.lower() == 'adam':
        return torch.optim.Adam(params, lr=lr, betas=(0.9, 0.99), weight_decay=weight_decay)
    return torch.optim.AdamW(params, lr=lr, betas=(0.9, 0.99), weight_decay=weight_decay)

def cosine_lr(optimizer: torch.optim.Optimizer, step: int, max_steps: int, base_lr: float, min_lr: float=1e-06, warmup: int=1000) -> float:
    if step < warmup:
        lr = base_lr * (step + 1) / max(1, warmup)
    else:
        progress = (step - warmup) / max(1, max_steps - warmup)
        lr = min_lr + 0.5 * (base_lr - min_lr) * (1 + math.cos(math.pi * min(progress, 1.0)))
    for group in optimizer.param_groups:
        group['lr'] = lr
    return lr

def cycle(loader: Iterable):
    while True:
        for batch in loader:
            yield batch

def create_run_dir(run_dir: str | Path, config: dict[str, Any] | None=None) -> tuple[Path, Any]:
    run_dir = ensure_dir(run_dir)
    ensure_dir(run_dir / 'checkpoints')
    ensure_dir(run_dir / 'logs')
    if config is not None:
        with (run_dir / 'config.json').open('w', encoding='utf-8') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
    return (run_dir, SummaryWriter(log_dir=str(run_dir / 'logs')))

def log_dict(writer: Any, prefix: str, values: dict[str, Any], step: int) -> None:
    for key, value in values.items():
        if isinstance(value, torch.Tensor):
            value = value.detach().float().mean().item()
        if isinstance(value, (int, float)):
            writer.add_scalar(f'{prefix}/{key}', float(value), step)

def walltime() -> str:
    return time.strftime('%Y-%m-%d %H:%M:%S')
