from __future__ import annotations
import torch
import torch.nn.functional as F

def motion_mask(entity_mask: torch.Tensor | None=None, frame_mask: torch.Tensor | None=None, like: torch.Tensor | None=None) -> torch.Tensor | None:
    if entity_mask is None and frame_mask is None:
        return None
    if entity_mask is None:
        assert frame_mask is not None
        mask = frame_mask[:, :, None, None]
    elif frame_mask is None:
        mask = entity_mask[:, None, :, None]
    else:
        mask = frame_mask[:, :, None, None] * entity_mask[:, None, :, None]
    if like is not None:
        mask = mask.to(device=like.device, dtype=like.dtype)
    return mask

def masked_mse(pred: torch.Tensor, target: torch.Tensor, entity_mask: torch.Tensor | None=None, frame_mask: torch.Tensor | None=None) -> torch.Tensor:
    mask = motion_mask(entity_mask, frame_mask, like=pred)
    diff = (pred - target).pow(2)
    if mask is None:
        return diff.mean()
    return (diff * mask).sum() / (mask.sum() * pred.shape[-1]).clamp_min(1.0)

def velocity_smoothness_loss(x: torch.Tensor, entity_mask: torch.Tensor | None=None, frame_mask: torch.Tensor | None=None) -> torch.Tensor:
    if x.shape[1] < 2:
        return x.new_tensor(0.0)
    vel = x[:, 1:] - x[:, :-1]
    target = torch.zeros_like(vel)
    fm = None
    if frame_mask is not None:
        fm = frame_mask[:, 1:] * frame_mask[:, :-1]
    return masked_mse(vel, target, entity_mask=entity_mask, frame_mask=fm)

def covariance_disentanglement_loss(levels: list[torch.Tensor]) -> torch.Tensor:
    if len(levels) < 2:
        return levels[0].new_tensor(0.0)
    losses = []
    for a, b in zip(levels[:-1], levels[1:]):
        af = a.reshape(a.shape[0], -1, a.shape[-1]).mean(dim=1)
        bf = b.reshape(b.shape[0], -1, b.shape[-1]).mean(dim=1)
        af = af - af.mean(dim=0, keepdim=True)
        bf = bf - bf.mean(dim=0, keepdim=True)
        cov = af.t() @ bf / max(af.shape[0] - 1, 1)
        losses.append(cov.pow(2).mean())
    return torch.stack(losses).mean()

def contrastive_logits(a: torch.Tensor, b: torch.Tensor, temperature: float=0.07) -> torch.Tensor:
    a = F.normalize(a, dim=-1)
    b = F.normalize(b, dim=-1)
    return a @ b.t() / temperature

def symmetric_contrastive_loss(a: torch.Tensor, b: torch.Tensor, temperature: float=0.07) -> torch.Tensor:
    logits = contrastive_logits(a, b, temperature)
    labels = torch.arange(logits.shape[0], device=logits.device)
    return 0.5 * (F.cross_entropy(logits, labels) + F.cross_entropy(logits.t(), labels))
