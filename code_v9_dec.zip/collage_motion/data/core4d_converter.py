from __future__ import annotations
import json
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import numpy as np
from tqdm import tqdm
from collage_motion.data.caption_index import CaptionIndex
from collage_motion.data.preprocess_common import clean_caption, find_time_axis, load_npz_motion_features, make_windows, pad_entities, resample_time, stable_hash, standardize_human_entities, standardize_object_features
from collage_motion.utils.io import atomic_np_savez, relative_id, stringify_npz_value, write_jsonl

@dataclass
class Core4DPreprocessConfig:
    raw_root: Path
    caption_csv: Path | None
    out_dir: Path
    source_fps: float = 15.0
    target_fps: float = 15.0
    target_feature_dim: int = 512
    max_humans: int = 2
    include_object: bool = True
    seq_len: int = 196
    stride: int = 98
    min_frames: int = 24
    split_ratio: dict[str, float] | None = None
    seed: int = 1234
    write_windows: bool = True
    prefer_processed_joints: bool = True

def find_core4d_sequence_dirs(raw_root: str | Path) -> list[Path]:
    raw_root = Path(raw_root)
    dirs: set[Path] = set()
    names = ('human_poses.npy', 'object_poses.npy', 'person1_poses.npz', 'human_vertices.npy', 'object_vertices.npy', 'contact_map.npy')
    for name in names:
        for path in raw_root.rglob(name):
            dirs.add(path.parent)
    for path in raw_root.rglob('*object*pose*.npz'):
        dirs.add(path.parent)
    return sorted(dirs)

def load_action_labels(raw_root: str | Path) -> dict[str, str]:
    raw_root = Path(raw_root)
    labels: dict[str, str] = {}
    for path in raw_root.rglob('action_labels.json'):
        try:
            with path.open('r', encoding='utf-8') as f:
                data = json.load(f)
            if isinstance(data, dict):
                for k, v in data.items():
                    if isinstance(v, dict):
                        text = v.get('description') or v.get('label') or v.get('action') or str(v)
                    else:
                        text = str(v)
                    labels[str(k)] = clean_caption(text)
        except Exception:
            continue
    return labels

def _load_human_entities(seq_dir: Path, cfg: Core4DPreprocessConfig) -> list[np.ndarray]:
    human_file = seq_dir / 'human_poses.npy'
    if human_file.exists():
        arr = np.load(human_file, allow_pickle=True)
        humans = standardize_human_entities(arr, max_humans=cfg.max_humans, min_frames=cfg.min_frames)
        return [humans[:, i] for i in range(min(humans.shape[1], cfg.max_humans))]
    entities: list[np.ndarray] = []
    explicit = [seq_dir / f'person{i}_poses.npz' for i in range(1, cfg.max_humans + 1)]
    for path in explicit:
        if path.exists():
            feat, _ = load_npz_motion_features(path, min_frames=cfg.min_frames, prefer_processed_joints=cfg.prefer_processed_joints)
            entities.append(feat)
    if entities:
        return entities
    npz_files = sorted(seq_dir.glob('*poses*.npz')) + sorted(seq_dir.glob('*human*.npz'))
    for path in npz_files[:cfg.max_humans]:
        feat, _ = load_npz_motion_features(path, min_frames=cfg.min_frames, prefer_processed_joints=cfg.prefer_processed_joints)
        entities.append(feat)
    return entities

def _load_object_entity(seq_dir: Path, cfg: Core4DPreprocessConfig) -> np.ndarray | None:
    if not cfg.include_object:
        return None
    path = seq_dir / 'object_poses.npy'
    if path.exists():
        return standardize_object_features(np.load(path, allow_pickle=True), min_frames=cfg.min_frames)
    for alt in sorted(seq_dir.glob('*object*pose*.npz')):
        feat, _ = load_npz_motion_features(alt, min_frames=cfg.min_frames, prefer_processed_joints=False)
        return feat
    return None

def _npz_numeric(data: Any, keys: tuple[str, ...], min_frames: int) -> np.ndarray | None:
    if isinstance(data, np.lib.npyio.NpzFile):
        for key in keys:
            if key in data.files:
                arr = np.asarray(data[key])
                if arr.dtype.kind in 'fiu' and arr.size > 0:
                    return arr.astype(np.float32)
        for key in data.files:
            arr = np.asarray(data[key])
            if arr.dtype.kind in 'fiu' and arr.ndim > 0 and any(s >= min_frames for s in arr.shape):
                return arr.astype(np.float32)
        return None
    arr = np.asarray(data)
    if arr.dtype.kind not in 'fiu' or arr.size == 0:
        return None
    return arr.astype(np.float32)

def _load_optional_array(seq_dir: Path, filenames: tuple[str, ...], keys: tuple[str, ...], min_frames: int) -> np.ndarray | None:
    for name in filenames:
        path = seq_dir / name
        if path.exists():
            try:
                return _npz_numeric(np.load(path, allow_pickle=True), keys, min_frames)
            except Exception:
                continue
    for pattern in filenames:
        for path in sorted(seq_dir.glob(pattern)):
            try:
                arr = _npz_numeric(np.load(path, allow_pickle=True), keys, min_frames)
                if arr is not None:
                    return arr
            except Exception:
                continue
    return None

def _time_first(arr: np.ndarray, min_frames: int) -> np.ndarray:
    axis = find_time_axis(arr, min_frames=min_frames)
    if axis is None:
        return arr.astype(np.float32)
    return np.moveaxis(arr, axis, 0).astype(np.float32)

def _standardize_human_vertices(arr: np.ndarray, max_humans: int, min_frames: int) -> np.ndarray:
    arr = _time_first(np.asarray(arr, dtype=np.float32), min_frames)
    if arr.ndim == 3 and arr.shape[-1] == 3:
        arr = arr[:, None]
    elif arr.ndim >= 4 and arr.shape[-1] == 3:
        if arr.shape[1] > max_humans and arr.shape[0] <= max_humans:
            arr = np.moveaxis(arr, 0, 1)
        arr = arr.reshape(arr.shape[0], arr.shape[1], -1, 3)
    else:
        arr = arr.reshape(arr.shape[0], 1, -1, 3)
    if arr.shape[1] < max_humans:
        pad = np.zeros((arr.shape[0], max_humans - arr.shape[1], arr.shape[2], 3), dtype=np.float32)
        arr = np.concatenate([arr, pad], axis=1)
    return arr[:, :max_humans].astype(np.float32)

def _standardize_object_vertices(arr: np.ndarray, min_frames: int) -> np.ndarray:
    arr = _time_first(np.asarray(arr, dtype=np.float32), min_frames)
    if arr.ndim == 3 and arr.shape[-1] == 3:
        arr = arr[:, None]
    elif arr.ndim >= 4 and arr.shape[-1] == 3:
        arr = arr.reshape(arr.shape[0], arr.shape[1], -1, 3)
    else:
        arr = arr.reshape(arr.shape[0], 1, -1, 3)
    return arr.astype(np.float32)

def _standardize_contact_map(arr: np.ndarray, max_humans: int, min_frames: int) -> np.ndarray:
    arr = _time_first(np.asarray(arr, dtype=np.float32), min_frames)
    if arr.ndim == 1:
        arr = arr[:, None, None]
    elif arr.ndim == 2:
        arr = arr[:, :max_humans, None]
    else:
        arr = arr.reshape(arr.shape[0], arr.shape[1], -1)[:, :max_humans]
    if arr.shape[1] < max_humans:
        pad = np.zeros((arr.shape[0], max_humans - arr.shape[1], arr.shape[2]), dtype=np.float32)
        arr = np.concatenate([arr, pad], axis=1)
    return arr.astype(np.float32)

def _fit_time(arr: np.ndarray, length: int, source_fps: float, target_fps: float, binary: bool=False) -> np.ndarray:
    out = resample_time(arr, source_fps, target_fps) if arr.ndim > 0 else arr
    if out.ndim == 0:
        return out
    if out.shape[0] > length:
        out = out[:length]
    elif out.shape[0] < length:
        pad = np.zeros((length - out.shape[0],) + out.shape[1:], dtype=out.dtype)
        out = np.concatenate([out, pad], axis=0)
    if binary:
        out = (out >= 0.5).astype(np.float32)
    return out.astype(np.float32)

def _load_object_category(seq_dir: Path) -> str:
    for name in ('metadata.json', 'object_metadata.json', 'object_meta.json', 'sequence.json'):
        path = seq_dir / name
        if path.exists():
            try:
                data = json.loads(path.read_text(encoding='utf-8'))
                if isinstance(data, dict):
                    for key in ('object_category', 'category', 'object', 'object_name', 'name'):
                        if key in data:
                            return clean_caption(str(data[key]))
            except Exception:
                pass
    for name in ('object_category.txt', 'category.txt', 'object_name.txt'):
        path = seq_dir / name
        if path.exists():
            text = clean_caption(path.read_text(encoding='utf-8', errors='ignore'))
            if text:
                return text
    return clean_caption(seq_dir.name.split('_')[0])

def _load_optional_geometry(seq_dir: Path, cfg: Core4DPreprocessConfig, motion_len: int) -> dict[str, np.ndarray | str]:
    out: dict[str, np.ndarray | str] = {}
    human_vertices = _load_optional_array(seq_dir, ('human_vertices.npy', 'humans_vertices.npy', 'smplx_vertices.npy', 'human_mesh_vertices.npy', '*human*vert*.npz', '*smplx*vert*.npz'), ('human_vertices', 'humans_vertices', 'vertices', 'verts', 'smplx_vertices'), cfg.min_frames)
    object_vertices = _load_optional_array(seq_dir, ('object_vertices.npy', 'object_mesh_vertices.npy', 'object_geometry.npy', '*object*vert*.npz', '*object*mesh*.npz'), ('object_vertices', 'vertices', 'verts', 'object_geometry'), cfg.min_frames)
    contact_map = _load_optional_array(seq_dir, ('contact_map.npy', 'contacts.npy', 'contact.npy', '*contact*.npz'), ('contact_map', 'contacts', 'contact'), cfg.min_frames)
    signed_distance = _load_optional_array(seq_dir, ('signed_distance.npy', 'signed_distances.npy', 'sdf.npy', '*signed*distance*.npz', '*sdf*.npz'), ('signed_distance', 'signed_distances', 'sdf'), cfg.min_frames)
    if human_vertices is not None:
        out['human_vertices'] = _fit_time(_standardize_human_vertices(human_vertices, cfg.max_humans, cfg.min_frames), motion_len, cfg.source_fps, cfg.target_fps)
    if object_vertices is not None:
        out['object_vertices'] = _fit_time(_standardize_object_vertices(object_vertices, cfg.min_frames), motion_len, cfg.source_fps, cfg.target_fps)
    if contact_map is not None:
        out['contact_map'] = _fit_time(_standardize_contact_map(contact_map, cfg.max_humans, cfg.min_frames), motion_len, cfg.source_fps, cfg.target_fps, binary=True)
    if signed_distance is not None:
        out['signed_distance'] = _fit_time(_time_first(np.asarray(signed_distance, dtype=np.float32), cfg.min_frames), motion_len, cfg.source_fps, cfg.target_fps)
    out['object_category'] = _load_object_category(seq_dir)
    return out

def load_core4d_sequence(seq_dir: str | Path, cfg: Core4DPreprocessConfig) -> tuple[np.ndarray, np.ndarray, np.ndarray, dict[str, np.ndarray | str]]:
    seq_dir = Path(seq_dir)
    entities = _load_human_entities(seq_dir, cfg)
    if not entities:
        raise ValueError(f'No human motion found in {seq_dir}')
    obj = _load_object_entity(seq_dir, cfg)
    if obj is not None:
        entities.append(obj)
    target_entities = cfg.max_humans + (1 if cfg.include_object else 0)
    motion, mask = pad_entities(entities, target_entities=target_entities, target_feature_dim=cfg.target_feature_dim)
    motion = resample_time(motion, cfg.source_fps, cfg.target_fps)
    entity_type = np.zeros(target_entities, dtype=np.int64)
    human_count = min(cfg.max_humans, len(entities))
    entity_type[:human_count] = 1
    if cfg.include_object and obj is not None and cfg.max_humans < target_entities:
        entity_type[cfg.max_humans] = 2
    entity_type[mask < 0.5] = 0
    optional = _load_optional_geometry(seq_dir, cfg, motion.shape[0])
    return (motion, mask, entity_type, optional)

def split_ids(sample_ids: list[str], ratio: dict[str, float], seed: int) -> dict[str, set[str]]:
    rng = random.Random(seed)
    ids = list(sample_ids)
    rng.shuffle(ids)
    n = len(ids)
    n_train = int(round(n * ratio.get('train', 0.8)))
    n_val = int(round(n * ratio.get('val', 0.05)))
    train = set(ids[:n_train])
    val = set(ids[n_train:n_train + n_val])
    test = set(ids[n_train + n_val:])
    return {'train': train, 'val': val, 'test': test}

def infer_split(sample_id: str, split_sets: dict[str, set[str]]) -> str:
    for name, ids in split_sets.items():
        if sample_id in ids:
            return name
    return 'train'

def _slice_optional(optional: dict[str, np.ndarray | str], start: int, end: int) -> dict[str, np.ndarray | str]:
    out: dict[str, np.ndarray | str] = {}
    for key, value in optional.items():
        if isinstance(value, np.ndarray) and value.ndim > 0 and value.shape[0] >= end:
            out[key] = value[start:end]
        else:
            out[key] = value
    return out

def convert_core4d(cfg: Core4DPreprocessConfig) -> list[dict]:
    raw_root = Path(cfg.raw_root)
    out_dir = Path(cfg.out_dir)
    samples_dir = out_dir / 'samples'
    samples_dir.mkdir(parents=True, exist_ok=True)
    caption_index = CaptionIndex.from_csv(cfg.caption_csv)
    action_labels = load_action_labels(raw_root)
    seq_dirs = find_core4d_sequence_dirs(raw_root)
    ratio = cfg.split_ratio or {'train': 0.8, 'val': 0.05, 'test': 0.15}
    base_ids = [relative_id(d, raw_root) for d in seq_dirs]
    split_sets = split_ids(base_ids, ratio, cfg.seed)
    rows: list[dict] = []
    for seq_dir in tqdm(seq_dirs, desc='CORE4D sequences'):
        base_id = relative_id(seq_dir, raw_root)
        try:
            motion, entity_mask, entity_type, optional = load_core4d_sequence(seq_dir, cfg)
        except Exception as exc:
            rows.append({'sample_id': base_id, 'error': str(exc), 'source_path': str(seq_dir)})
            continue
        captions = caption_index.lookup_all(base_id)
        if not captions:
            captions = caption_index.lookup_all(seq_dir.name)
        if not captions:
            captions = [action_labels.get(base_id) or action_labels.get(seq_dir.name) or f'Two humans collaboratively manipulate an object in sequence {base_id}.']
        windows = make_windows(motion.shape[0], cfg.seq_len, cfg.stride, cfg.min_frames) if cfg.write_windows else [(0, motion.shape[0])]
        split = infer_split(base_id, split_sets)
        object_category = str(optional.get('object_category', '')) if optional else ''
        for win_idx, (start, end) in enumerate(windows):
            clip = motion[start:end]
            optional_clip = _slice_optional(optional, start, end)
            for cap_idx, caption in enumerate(captions):
                caption = clean_caption(caption)
                sid = f'core4d_{stable_hash(base_id)}_w{win_idx:04d}_c{cap_idx:02d}'
                out_path = samples_dir / f'{sid}.npz'
                payload: dict[str, Any] = {'motion': clip.astype(np.float32), 'entity_mask': entity_mask.astype(np.float32), 'entity_type': entity_type.astype(np.int64), 'length': np.array([clip.shape[0]], dtype=np.int32), 'caption': np.array(caption), 'sample_id': np.array(sid), 'source': np.array('core4d'), 'source_path': np.array(str(seq_dir)), 'base_sequence': np.array(base_id), 'start': np.array([start], dtype=np.int32), 'end': np.array([end], dtype=np.int32)}
                for key, value in optional_clip.items():
                    if isinstance(value, np.ndarray):
                        payload[key] = value.astype(np.float32)
                    elif value:
                        payload[key] = np.array(str(value))
                atomic_np_savez(out_path, **payload)
                rows.append({'sample_id': sid, 'path': str(out_path.relative_to(out_dir)), 'caption': caption, 'source': 'core4d', 'source_path': str(seq_dir), 'base_sequence': base_id, 'split': split, 'length': int(clip.shape[0]), 'num_entities': int(entity_mask.sum()), 'feature_dim': int(clip.shape[-1]), 'object_category': object_category})
    good_rows = [r for r in rows if 'path' in r]
    error_rows = [r for r in rows if 'error' in r]
    write_jsonl(good_rows, out_dir / 'metadata.jsonl')
    write_jsonl(error_rows, out_dir / 'errors.jsonl')
    for split in ('train', 'val', 'test'):
        write_jsonl([r for r in good_rows if r['split'] == split], out_dir / f'{split}.jsonl')
    return good_rows

def config_from_mapping(mapping: dict) -> Core4DPreprocessConfig:
    return Core4DPreprocessConfig(raw_root=Path(mapping['raw_root']), caption_csv=Path(mapping['caption_csv']) if mapping.get('caption_csv') else None, out_dir=Path(mapping['out_dir']), source_fps=float(mapping.get('source_fps', 15)), target_fps=float(mapping.get('target_fps', 15)), target_feature_dim=int(mapping.get('target_feature_dim', 512)), max_humans=int(mapping.get('max_humans', 2)), include_object=bool(mapping.get('include_object', True)), seq_len=int(mapping.get('seq_len', 196)), stride=int(mapping.get('stride', 98)), min_frames=int(mapping.get('min_frames', 24)), split_ratio=dict(mapping.get('split_ratio', {'train': 0.8, 'val': 0.05, 'test': 0.15})), seed=int(mapping.get('seed', 1234)), write_windows=bool(mapping.get('write_windows', True)), prefer_processed_joints=bool(mapping.get('prefer_processed_joints', True)))
