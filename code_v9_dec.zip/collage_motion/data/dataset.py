from __future__ import annotations
from pathlib import Path
from typing import Any
import numpy as np
import torch
from torch.utils.data import Dataset
from collage_motion.utils.io import read_jsonl, stringify_npz_value

class MotionTextDataset(Dataset):

    def __init__(self, data_root: str | Path, split: str='train', seq_len: int=196, stats_path: str | Path | None=None, random_crop: bool=True, normalize: bool=True, default_num_humans: int=2) -> None:
        self.data_root = Path(data_root)
        self.split = split
        self.seq_len = seq_len
        self.random_crop = random_crop
        self.normalize = normalize
        self.default_num_humans = default_num_humans
        split_file = self.data_root / f'{split}.jsonl'
        if not split_file.exists():
            split_file = self.data_root / 'metadata.jsonl'
        self.rows = read_jsonl(split_file)
        if split_file.name == 'metadata.jsonl':
            self.rows = [r for r in self.rows if r.get('split', split) == split]
        if not self.rows:
            raise FileNotFoundError(f'No rows found for split {split} in {self.data_root}')
        self.mean: np.ndarray | None = None
        self.std: np.ndarray | None = None
        if stats_path is not None and Path(stats_path).exists():
            stats = np.load(stats_path)
            self.mean = stats['mean'].astype(np.float32)
            self.std = stats['std'].astype(np.float32)

    def __len__(self) -> int:
        return len(self.rows)

    def _load_npz(self, row: dict[str, Any]) -> dict[str, Any]:
        path = self.data_root / row['path']
        data = np.load(path, allow_pickle=True)
        return {k: data[k] for k in data.files}

    def _crop_or_pad_motion(self, motion: np.ndarray) -> tuple[np.ndarray, np.ndarray, int, int, int]:
        length = motion.shape[0]
        valid = min(length, self.seq_len)
        start = 0
        end = length
        if length > self.seq_len:
            start = np.random.randint(0, length - self.seq_len + 1) if self.random_crop else 0
            end = start + self.seq_len
            motion = motion[start:end]
            valid = self.seq_len
        elif length < self.seq_len:
            pad = np.zeros((self.seq_len - length, motion.shape[1], motion.shape[2]), dtype=motion.dtype)
            motion = np.concatenate([motion, pad], axis=0)
        frame_mask = np.zeros(self.seq_len, dtype=np.float32)
        frame_mask[:valid] = 1.0
        return (motion.astype(np.float32), frame_mask, valid, start, end)

    def _crop_or_pad_time_array(self, arr: np.ndarray, start: int, end: int, valid: int) -> np.ndarray:
        arr = np.asarray(arr)
        if arr.ndim == 0 or arr.shape[0] < end:
            return arr
        sliced = arr[start:end]
        if sliced.shape[0] < self.seq_len:
            pad_shape = (self.seq_len - sliced.shape[0],) + sliced.shape[1:]
            sliced = np.concatenate([sliced, np.zeros(pad_shape, dtype=sliced.dtype)], axis=0)
        return sliced.astype(np.float32) if sliced.dtype.kind in 'fiu' else sliced

    def _default_entity_type(self, entity_mask: np.ndarray) -> np.ndarray:
        e = int(entity_mask.shape[0])
        out = np.zeros(e, dtype=np.int64)
        h = min(self.default_num_humans, e)
        out[:h] = 1
        if e > h:
            out[h:] = 2
        out[entity_mask < 0.5] = 0
        return out

    def __getitem__(self, index: int) -> dict[str, Any]:
        row = self.rows[index]
        data = self._load_npz(row)
        motion = np.asarray(data['motion'], dtype=np.float32)
        entity_mask = np.asarray(data.get('entity_mask', np.ones(motion.shape[1], dtype=np.float32)), dtype=np.float32)
        motion, frame_mask, valid, start, end = self._crop_or_pad_motion(motion)
        if self.normalize and self.mean is not None and (self.std is not None):
            motion = (motion - self.mean.reshape(1, 1, -1)) / self.std.reshape(1, 1, -1)
        entity_type = np.asarray(data.get('entity_type', self._default_entity_type(entity_mask)), dtype=np.int64)
        caption = stringify_npz_value(data.get('caption', row.get('caption', '')))
        sample_id = stringify_npz_value(data.get('sample_id', row.get('sample_id', str(index))))
        batch: dict[str, Any] = {'motion': torch.from_numpy(motion), 'entity_mask': torch.from_numpy(entity_mask.astype(np.float32)), 'entity_type': torch.from_numpy(entity_type.astype(np.int64)), 'frame_mask': torch.from_numpy(frame_mask), 'length': torch.tensor(valid, dtype=torch.long), 'caption': caption, 'sample_id': sample_id, 'row': row}
        for key in ('human_vertices', 'object_vertices', 'contact_map', 'signed_distance'):
            if key in data:
                arr = self._crop_or_pad_time_array(np.asarray(data[key]), start, end, valid)
                if np.asarray(arr).dtype.kind in 'fiu':
                    batch[key] = torch.from_numpy(np.asarray(arr, dtype=np.float32))
        if 'object_category' in data:
            batch['object_category'] = stringify_npz_value(data['object_category'])
        return batch

def collate_motion_text(batch: list[dict[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {'motion': torch.stack([b['motion'] for b in batch], dim=0), 'entity_mask': torch.stack([b['entity_mask'] for b in batch], dim=0), 'entity_type': torch.stack([b['entity_type'] for b in batch], dim=0), 'frame_mask': torch.stack([b['frame_mask'] for b in batch], dim=0), 'length': torch.stack([b['length'] for b in batch], dim=0), 'caption': [b['caption'] for b in batch], 'sample_id': [b['sample_id'] for b in batch], 'row': [b['row'] for b in batch]}
    for key in ('human_vertices', 'object_vertices', 'contact_map', 'signed_distance'):
        if all((key in b for b in batch)):
            out[key] = torch.stack([b[key] for b in batch], dim=0)
    if any(('object_category' in b for b in batch)):
        out['object_category'] = [b.get('object_category', '') for b in batch]
    return out

def compute_dataset_stats(data_root: str | Path, out_path: str | Path, split: str='train') -> None:
    root = Path(data_root)
    split_file = root / f'{split}.jsonl'
    rows = read_jsonl(split_file) if split_file.exists() else read_jsonl(root / 'metadata.jsonl')
    if not rows:
        raise FileNotFoundError(f'No metadata rows found in {root}')
    total = None
    total_sq = None
    count = 0.0
    for row in rows:
        if split_file.exists() is False and row.get('split', split) != split:
            continue
        data = np.load(root / row['path'], allow_pickle=True)
        motion = data['motion'].astype(np.float64)
        entity_mask = data.get('entity_mask', np.ones(motion.shape[1], dtype=np.float32)).astype(np.float64)
        mask = entity_mask.reshape(1, -1, 1)
        weighted = motion * mask
        if total is None:
            total = weighted.sum(axis=(0, 1))
            total_sq = (weighted * weighted).sum(axis=(0, 1))
        else:
            total += weighted.sum(axis=(0, 1))
            total_sq += (weighted * weighted).sum(axis=(0, 1))
        count += float(mask.sum() * motion.shape[0])
    mean = total / max(count, 1.0)
    var = total_sq / max(count, 1.0) - mean * mean
    std = np.sqrt(np.maximum(var, 1e-06))
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(out_path, mean=mean.astype(np.float32), std=std.astype(np.float32), count=np.array([count], dtype=np.float64))
