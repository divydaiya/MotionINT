from __future__ import annotations
import random
from dataclasses import dataclass
from pathlib import Path
import numpy as np
from tqdm import tqdm
from collage_motion.data.preprocess_common import clean_caption, load_npz_motion_features, make_windows, pad_entities, resample_time, stable_hash, standardize_human_entities
from collage_motion.utils.io import atomic_np_savez, iter_files, relative_id, write_jsonl

@dataclass
class InterHumanPreprocessConfig:
    raw_root: Path
    out_dir: Path
    source_fps: float = 30.0
    target_fps: float = 30.0
    target_feature_dim: int = 512
    max_humans: int = 2
    include_object: bool = False
    seq_len: int = 196
    stride: int = 98
    min_frames: int = 24
    split_ratio: dict[str, float] | None = None
    seed: int = 1234
    write_windows: bool = True

def find_interhuman_motion_files(raw_root: str | Path) -> list[Path]:
    raw_root = Path(raw_root)
    preferred = raw_root / 'motions_processed'
    if preferred.exists():
        files = sorted(iter_files(preferred, ('.npy', '.npz')))
        if files:
            return files
    raw = raw_root / 'motions'
    if raw.exists():
        files = sorted(iter_files(raw, ('.npy', '.npz')))
        if files:
            return files
    return sorted(iter_files(raw_root, ('.npy', '.npz')))

def read_annotation_lines(raw_root: Path, stem: str) -> list[str]:
    candidates = [raw_root / 'annots' / f'{stem}.txt', raw_root / 'texts' / f'{stem}.txt']
    for path in candidates:
        if path.exists():
            lines = [clean_caption(line) for line in path.read_text(encoding='utf-8', errors='replace').splitlines()]
            lines = [line for line in lines if line]
            if lines:
                return lines
    return [f'Two people perform an interaction sequence {stem}.']

def read_official_splits(raw_root: Path) -> dict[str, set[str]]:
    split_dir = raw_root / 'split'
    out: dict[str, set[str]] = {'train': set(), 'val': set(), 'test': set()}
    if not split_dir.exists():
        return out
    for name in out:
        path = split_dir / f'{name}.txt'
        if path.exists():
            out[name] = {line.strip() for line in path.read_text().splitlines() if line.strip()}
    return out

def random_splits(ids: list[str], ratio: dict[str, float], seed: int) -> dict[str, set[str]]:
    rng = random.Random(seed)
    ids = list(ids)
    rng.shuffle(ids)
    n = len(ids)
    n_train = int(round(n * ratio.get('train', 0.8)))
    n_val = int(round(n * ratio.get('val', 0.05)))
    return {'train': set(ids[:n_train]), 'val': set(ids[n_train:n_train + n_val]), 'test': set(ids[n_train + n_val:])}

def split_for(stem: str, splits: dict[str, set[str]]) -> str:
    for name, ids in splits.items():
        if stem in ids or Path(stem).stem in ids:
            return name
    return 'train'

def load_interhuman_motion(path: str | Path, cfg: InterHumanPreprocessConfig) -> tuple[np.ndarray, np.ndarray]:
    path = Path(path)
    if path.suffix == '.npz':
        feat, _ = load_npz_motion_features(path, min_frames=cfg.min_frames, prefer_processed_joints=True)
        humans = standardize_human_entities(feat, max_humans=cfg.max_humans, min_frames=cfg.min_frames)
    else:
        arr = np.load(path, allow_pickle=True)
        humans = standardize_human_entities(arr, max_humans=cfg.max_humans, min_frames=cfg.min_frames)
    entities = [humans[:, i] for i in range(min(humans.shape[1], cfg.max_humans))]
    target_entities = cfg.max_humans + (1 if cfg.include_object else 0)
    motion, mask = pad_entities(entities, target_entities=target_entities, target_feature_dim=cfg.target_feature_dim)
    motion = resample_time(motion, cfg.source_fps, cfg.target_fps)
    return (motion, mask)

def convert_interhuman(cfg: InterHumanPreprocessConfig) -> list[dict]:
    raw_root = Path(cfg.raw_root)
    out_dir = Path(cfg.out_dir)
    samples_dir = out_dir / 'samples'
    samples_dir.mkdir(parents=True, exist_ok=True)
    motion_files = find_interhuman_motion_files(raw_root)
    stems = [relative_id(p, raw_root).split('/')[-1] for p in motion_files]
    official = read_official_splits(raw_root)
    if any(official.values()):
        splits = official
    else:
        splits = random_splits(stems, cfg.split_ratio or {'train': 0.8, 'val': 0.05, 'test': 0.15}, cfg.seed)
    rows: list[dict] = []
    errors: list[dict] = []
    for motion_path in tqdm(motion_files, desc='InterHuman motions'):
        stem = motion_path.stem
        base_id = relative_id(motion_path, raw_root)
        try:
            motion, entity_mask = load_interhuman_motion(motion_path, cfg)
        except Exception as exc:
            errors.append({'sample_id': base_id, 'error': str(exc), 'source_path': str(motion_path)})
            continue
        captions = read_annotation_lines(raw_root, stem)
        windows = make_windows(motion.shape[0], cfg.seq_len, cfg.stride, cfg.min_frames) if cfg.write_windows else [(0, motion.shape[0])]
        split = split_for(stem, splits)
        for win_idx, (start, end) in enumerate(windows):
            clip = motion[start:end]
            for cap_idx, caption in enumerate(captions):
                caption = clean_caption(caption)
                sid = f'interhuman_{stable_hash(base_id)}_w{win_idx:04d}_c{cap_idx:02d}'
                out_path = samples_dir / f'{sid}.npz'
                atomic_np_savez(out_path, motion=clip.astype(np.float32), entity_mask=entity_mask.astype(np.float32), length=np.array([clip.shape[0]], dtype=np.int32), caption=np.array(caption), sample_id=np.array(sid), source=np.array('interhuman'), source_path=np.array(str(motion_path)), base_sequence=np.array(base_id), start=np.array([start], dtype=np.int32), end=np.array([end], dtype=np.int32))
                rows.append({'sample_id': sid, 'path': str(out_path.relative_to(out_dir)), 'caption': caption, 'source': 'interhuman', 'source_path': str(motion_path), 'base_sequence': base_id, 'split': split, 'length': int(clip.shape[0]), 'num_entities': int(entity_mask.sum()), 'feature_dim': int(clip.shape[-1])})
    write_jsonl(rows, out_dir / 'metadata.jsonl')
    write_jsonl(errors, out_dir / 'errors.jsonl')
    for split in ('train', 'val', 'test'):
        write_jsonl([r for r in rows if r['split'] == split], out_dir / f'{split}.jsonl')
    return rows

def config_from_mapping(mapping: dict) -> InterHumanPreprocessConfig:
    return InterHumanPreprocessConfig(raw_root=Path(mapping['raw_root']), out_dir=Path(mapping['out_dir']), source_fps=float(mapping.get('source_fps', 30)), target_fps=float(mapping.get('target_fps', 30)), target_feature_dim=int(mapping.get('target_feature_dim', 512)), max_humans=int(mapping.get('max_humans', 2)), include_object=bool(mapping.get('include_object', False)), seq_len=int(mapping.get('seq_len', 196)), stride=int(mapping.get('stride', 98)), min_frames=int(mapping.get('min_frames', 24)), split_ratio=dict(mapping.get('split_ratio', {'train': 0.8, 'val': 0.05, 'test': 0.15})), seed=int(mapping.get('seed', 1234)), write_windows=bool(mapping.get('write_windows', True)))
