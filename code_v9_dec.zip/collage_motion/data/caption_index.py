from __future__ import annotations
import re
from pathlib import Path
from typing import Iterable
import pandas as pd
_ID_RE = re.compile('\\d+')

def normalize_key(value: object) -> str:
    text = str(value).strip().replace('\\', '/')
    text = text.strip('./')
    text = re.sub('\\s+', '_', text)
    return text.lower()

def digit_key(value: object) -> str | None:
    matches = _ID_RE.findall(str(value))
    if not matches:
        return None
    joined = ''.join(matches)
    stripped = joined.lstrip('0')
    return stripped or '0'

class CaptionIndex:

    def __init__(self, rows: Iterable[tuple[object, str]]=()):
        self._by_key: dict[str, list[str]] = {}
        for key, caption in rows:
            self.add(key, caption)

    def add(self, key: object, caption: str) -> None:
        if caption is None or str(caption).strip() == '':
            return
        caption = str(caption).strip()
        variants = {normalize_key(key)}
        variants.add(Path(str(key)).stem.lower())
        dkey = digit_key(key)
        if dkey is not None:
            variants.add(dkey)
        for variant in variants:
            self._by_key.setdefault(variant, []).append(caption)

    @classmethod
    def from_csv(cls, path: str | Path | None) -> 'CaptionIndex':
        if path is None:
            return cls()
        path = Path(path)
        if not path.exists():
            return cls()
        df = pd.read_csv(path)
        lower = {c.lower().strip(): c for c in df.columns}
        id_col = lower.get('motion_number') or lower.get('motion_id') or lower.get('id') or df.columns[0]
        text_col = lower.get('description') or lower.get('caption') or lower.get('text') or df.columns[-1]
        rows = [(row[id_col], row[text_col]) for _, row in df.iterrows()]
        return cls(rows)

    def lookup_all(self, candidate: object) -> list[str]:
        keys = [normalize_key(candidate), Path(str(candidate)).stem.lower()]
        dkey = digit_key(candidate)
        if dkey is not None:
            keys.append(dkey)
        path = normalize_key(candidate)
        parts = path.split('/')
        keys.extend(parts)
        keys.extend((Path(p).stem.lower() for p in parts))
        out: list[str] = []
        seen: set[str] = set()
        for key in keys:
            for caption in self._by_key.get(key, []):
                if caption not in seen:
                    out.append(caption)
                    seen.add(caption)
        return out

    def lookup_one(self, candidate: object, fallback: str | None=None) -> str:
        found = self.lookup_all(candidate)
        if found:
            return found[0]
        if fallback is not None:
            return fallback
        return str(candidate)

    def __len__(self) -> int:
        return sum((len(v) for v in self._by_key.values()))
