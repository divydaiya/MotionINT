from __future__ import annotations
import hashlib
from pathlib import Path
from typing import Any
import numpy as np
from collage_motion.utils.io import safe_load_numpy, stringify_npz_value
from collage_motion.utils.rotation import transform_to_features
PREFERRED_KEYS = ('joints', 'joint_positions', 'positions', 'motion', 'poses_processed', 'poses', 'transl', 'global_orient', 'body_pose', 'left_hand_pose', 'right_hand_pose', 'jaw_pose', 'leye_pose', 'reye_pose', 'betas')

def stable_hash(text: str, length: int=12) -> str:
    return hashlib.sha1(text.encode('utf-8')).hexdigest()[:length]

def as_float_array(value: Any) -> np.ndarray | None:
    try:
        arr = np.asarray(value)
    except Exception:
        return None
    if arr.dtype.kind not in 'fiu':
        return None
    arr = arr.astype(np.float32)
    if arr.size == 0 or not np.isfinite(arr).any():
        return None
    return arr

def find_time_axis(arr: np.ndarray, min_frames: int=2) -> int | None:
    if arr.ndim == 0:
        return None
    candidates = [i for i, s in enumerate(arr.shape) if s >= min_frames]
    if not candidates:
        return None
    if arr.shape[0] >= min_frames:
        return 0
    return max(candidates, key=lambda i: arr.shape[i])

def time_first_flatten(arr: np.ndarray, min_frames: int=2) -> np.ndarray | None:
    arr = as_float_array(arr)
    if arr is None:
        return None
    axis = find_time_axis(arr, min_frames=min_frames)
    if axis is None:
        return None
    arr = np.moveaxis(arr, axis, 0)
    if arr.ndim >= 3 and arr.shape[-2:] == (4, 4):
        arr = transform_to_features(arr)
    else:
        arr = arr.reshape(arr.shape[0], -1)
    return arr.astype(np.float32)

def load_npz_motion_features(path: str | Path, min_frames: int=2, prefer_processed_joints: bool=True) -> tuple[np.ndarray, dict[str, str]]:
    data = safe_load_numpy(path)
    meta: dict[str, str] = {}
    if isinstance(data, np.lib.npyio.NpzFile):
        keys = list(data.files)
        if prefer_processed_joints:
            for key in ('motion', 'joints', 'joint_positions', 'positions', 'poses_processed'):
                if key in data.files:
                    direct = time_first_flatten(data[key], min_frames=min_frames)
                    if direct is not None:
                        return (direct, meta)
        ordered = [k for k in PREFERRED_KEYS if k in keys] + sorted((k for k in keys if k not in PREFERRED_KEYS))
        features = []
        lengths = []
        for key in ordered:
            arr = as_float_array(data[key])
            if arr is None:
                try:
                    meta[key] = stringify_npz_value(data[key])
                except Exception:
                    pass
                continue
            flat = time_first_flatten(arr, min_frames=min_frames)
            if flat is not None:
                features.append(flat)
                lengths.append(flat.shape[0])
        if not features:
            raise ValueError(f'No numeric time-series features found in {path}')
        t = min(lengths)
        return (np.concatenate([f[:t] for f in features], axis=-1).astype(np.float32), meta)
    arr = np.asarray(data, dtype=np.float32)
    flat = time_first_flatten(arr, min_frames=min_frames)
    if flat is None:
        raise ValueError(f'Could not infer time axis from {path} with shape {arr.shape}')
    return (flat, meta)

def standardize_human_entities(arr: np.ndarray, max_humans: int=2, min_frames: int=2) -> np.ndarray:
    arr = np.asarray(arr, dtype=np.float32)
    if arr.ndim == 1:
        arr = arr[None, :, None]
    if arr.ndim == 2:
        if arr.shape[1] % max_humans == 0 and arr.shape[1] >= max_humans * 2:
            return arr.reshape(arr.shape[0], max_humans, arr.shape[1] // max_humans)
        return arr[:, None, :]
    if arr.ndim >= 3:
        if arr.shape[0] <= max_humans and arr.shape[1] >= min_frames:
            arr = np.moveaxis(arr, 0, 1)
        elif arr.shape[1] <= max_humans and arr.shape[0] >= min_frames:
            pass
        else:
            axis = find_time_axis(arr, min_frames=min_frames) or 0
            arr = np.moveaxis(arr, axis, 0)
            if arr.shape[1] > max_humans:
                arr = arr.reshape(arr.shape[0], 1, -1)
        return arr.reshape(arr.shape[0], arr.shape[1], -1)
    raise ValueError(f'Unsupported human motion shape {arr.shape}')

def standardize_object_features(arr: np.ndarray, min_frames: int=2) -> np.ndarray:
    arr = np.asarray(arr, dtype=np.float32)
    if arr.ndim >= 3 and arr.shape[-2:] == (4, 4):
        return transform_to_features(arr).reshape(arr.shape[0], -1).astype(np.float32)
    flat = time_first_flatten(arr, min_frames=min_frames)
    if flat is None:
        raise ValueError(f'Unsupported object pose shape {arr.shape}')
    return flat

def fit_feature_dim(x: np.ndarray, target_dim: int) -> np.ndarray:
    x = np.asarray(x, dtype=np.float32)
    if x.shape[-1] == target_dim:
        return x
    if x.shape[-1] > target_dim:
        return x[..., :target_dim]
    pad = np.zeros(x.shape[:-1] + (target_dim - x.shape[-1],), dtype=np.float32)
    return np.concatenate([x, pad], axis=-1)

def resample_time(x: np.ndarray, source_fps: float, target_fps: float) -> np.ndarray:
    if source_fps <= 0 or target_fps <= 0 or abs(source_fps - target_fps) < 1e-06:
        return x.astype(np.float32)
    t_old = np.arange(x.shape[0], dtype=np.float32) / float(source_fps)
    duration = t_old[-1] if len(t_old) > 1 else 0.0
    n_new = max(1, int(round(duration * target_fps)) + 1)
    t_new = np.arange(n_new, dtype=np.float32) / float(target_fps)
    flat = x.reshape(x.shape[0], -1)
    out = np.empty((n_new, flat.shape[1]), dtype=np.float32)
    for i in range(flat.shape[1]):
        out[:, i] = np.interp(t_new, t_old, flat[:, i])
    return out.reshape((n_new,) + x.shape[1:]).astype(np.float32)

def make_windows(length: int, seq_len: int, stride: int, min_frames: int) -> list[tuple[int, int]]:
    if length < min_frames:
        return []
    if length <= seq_len:
        return [(0, length)]
    starts = list(range(0, length - seq_len + 1, max(1, stride)))
    if starts[-1] != length - seq_len:
        starts.append(length - seq_len)
    return [(s, s + seq_len) for s in starts]

def pad_entities(entities: list[np.ndarray], target_entities: int, target_feature_dim: int) -> tuple[np.ndarray, np.ndarray]:
    if not entities:
        raise ValueError('At least one entity is required')
    t = min((e.shape[0] for e in entities))
    fitted = [fit_feature_dim(e[:t], target_feature_dim) for e in entities[:target_entities]]
    mask = np.zeros(target_entities, dtype=np.float32)
    mask[:len(fitted)] = 1.0
    while len(fitted) < target_entities:
        fitted.append(np.zeros((t, target_feature_dim), dtype=np.float32))
    motion = np.stack(fitted, axis=1).astype(np.float32)
    return (motion, mask)

def clean_caption(text: str) -> str:
    return ' '.join(str(text).replace('\n', ' ').split()).strip()
