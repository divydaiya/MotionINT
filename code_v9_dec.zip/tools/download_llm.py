from __future__ import annotations
import argparse
from pathlib import Path

def main() -> None:
    parser = argparse.ArgumentParser(description='collage')
    parser.add_argument('--model-id', default='Qwen/Qwen2.5-7B-Instruct', help='Hugging Face model id to download.')
    parser.add_argument('--out-dir', default='llm_models/qwen2_5_7b_instruct', help='Local destination directory.')
    parser.add_argument('--revision', default='main', help='Model revision, branch, or commit.')
    parser.add_argument('--token', default=None, help='Optional Hugging Face token for gated models such as Llama.')
    parser.add_argument('--trust-remote-code', action='store_true', help='Allow custom model/tokenizer code when a model requires it.')
    parser.add_argument('--verify-tokenizer', action='store_true', help='Load tokenizer after download.')
    parser.add_argument('--verify-model', action='store_true', help='Load the full model after download. Requires enough CPU/GPU RAM.')
    parser.add_argument('--local-files-only', action='store_true', help='Do not contact the internet; verify only existing files.')
    parser.add_argument('--ignore-pattern', action='append', default=[], help='Pattern to skip. Can be repeated.')
    args = parser.parse_args()
    try:
        from huggingface_hub import snapshot_download
    except ImportError as exc:
        raise SystemExit('Install with: pip install huggingface_hub transformers accelerate sentencepiece') from exc
    out_dir = Path(args.out_dir).expanduser().resolve()
    out_dir.parent.mkdir(parents=True, exist_ok=True)
    ignore_patterns = list(args.ignore_pattern)
    if not args.verify_model:
        ignore_patterns.extend(['*.msgpack', '*.h5', '*.ot'])
    path = snapshot_download(repo_id=args.model_id, revision=args.revision, local_dir=str(out_dir), local_dir_use_symlinks=False, token=args.token, ignore_patterns=ignore_patterns or None, local_files_only=args.local_files_only)
    print(f'Downloaded {args.model_id} to {path}')
    if args.verify_tokenizer or args.verify_model:
        from transformers import AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(path, trust_remote_code=args.trust_remote_code)
        print(f'Tokenizer loaded; vocab size={len(tokenizer)}')
    if args.verify_model:
        import torch
        from transformers import AutoModelForCausalLM
        dtype = torch.float16 if torch.cuda.is_available() else torch.float32
        model = AutoModelForCausalLM.from_pretrained(path, torch_dtype=dtype, device_map='auto' if torch.cuda.is_available() else None, trust_remote_code=args.trust_remote_code)
        total = sum((p.numel() for p in model.parameters()))
        print(f'Model loaded; parameters={total:,}')
if __name__ == '__main__':
    main()
