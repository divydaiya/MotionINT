from __future__ import annotations
import argparse
from collage_motion.data.core4d_converter import config_from_mapping, convert_core4d
from collage_motion.utils.config import apply_cli_overrides, load_config, to_plain_dict

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', required=True)
    parser.add_argument('--raw-root')
    parser.add_argument('--caption-csv')
    parser.add_argument('--out-dir')
    parser.add_argument('--target-feature-dim', type=int)
    parser.add_argument('--seq-len', type=int)
    parser.add_argument('--stride', type=int)
    parser.add_argument('--source-fps', type=float)
    parser.add_argument('--target-fps', type=float)
    return parser.parse_args()

def main() -> None:
    args = parse_args()
    cfg = load_config(args.config)
    cfg = apply_cli_overrides(cfg, {'raw_root': args.raw_root, 'caption_csv': args.caption_csv, 'out_dir': args.out_dir, 'target_feature_dim': args.target_feature_dim, 'seq_len': args.seq_len, 'stride': args.stride, 'source_fps': args.source_fps, 'target_fps': args.target_fps})
    rows = convert_core4d(config_from_mapping(to_plain_dict(cfg)))
    print(f'Wrote {len(rows)} CORE4D samples to {cfg.out_dir}')
if __name__ == '__main__':
    main()
