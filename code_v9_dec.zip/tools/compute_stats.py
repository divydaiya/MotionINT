from __future__ import annotations
import argparse
from collage_motion.data.dataset import compute_dataset_stats

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-root', required=True)
    parser.add_argument('--out', required=True)
    parser.add_argument('--split', default='train')
    args = parser.parse_args()
    compute_dataset_stats(args.data_root, args.out, split=args.split)
    print(f'Wrote stats to {args.out}')
if __name__ == '__main__':
    main()
