from __future__ import annotations
import argparse
import csv
import importlib.util
import json
from pathlib import Path
from typing import Any
import numpy as np
from collage_motion.utils.metrics import confidence_interval, contact_summary, diversity, frechet_distance, motion_embeddings, motion_l2, multimodal_distance, multimodality, r_precision, rr_je, rr_ve, velocity_l2

def load_npz(path: Path) -> dict[str, Any]:
    data = np.load(path, allow_pickle=True)
    return {k: data[k] for k in data.files}

def _scalar_text(value: Any) -> str:
    arr = np.asarray(value)
    if arr.shape == ():
        return str(arr.item())
    return str(value)

def index_reference(root: str | Path | None) -> dict[str, Path]:
    if root is None:
        return {}
    root = Path(root)
    if not root.exists():
        return {}
    out: dict[str, Path] = {}
    for folder in (root, root / 'samples'):
        if not folder.exists():
            continue
        for path in folder.glob('*.npz'):
            data = load_npz(path)
            sid = _scalar_text(data.get('sample_id', path.stem))
            cap = _scalar_text(data.get('caption', ''))
            out[sid] = path
            if cap:
                out.setdefault(cap, path)
    meta = root / 'metadata.jsonl'
    if meta.exists():
        for line in meta.read_text(encoding='utf-8').splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            path = root / row['path']
            if path.exists():
                out[str(row.get('sample_id', path.stem))] = path
                if row.get('caption'):
                    out.setdefault(str(row['caption']), path)
    return out

def load_evaluator(module_path: str | Path | None) -> Any | None:
    if not module_path:
        return None
    path = Path(module_path)
    spec = importlib.util.spec_from_file_location('collage_external_evaluator', path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'Could not load evaluator module from {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if hasattr(module, 'build_evaluator'):
        return module.build_evaluator()
    if hasattr(module, 'Evaluator'):
        return module.Evaluator()
    return module

def run_external_evaluator(evaluator: Any, generated_dir: Path, reference_root: str | Path | None, runs: int, mmodality_runs: int) -> dict[str, Any]:
    if hasattr(evaluator, 'evaluate'):
        return dict(evaluator.evaluate(generated_dir=str(generated_dir), reference_root=str(reference_root) if reference_root else None, runs=runs, mmodality_runs=mmodality_runs))
    if hasattr(evaluator, 'compute_metrics'):
        return dict(evaluator.compute_metrics(str(generated_dir), str(reference_root) if reference_root else None, runs=runs, mmodality_runs=mmodality_runs))
    if callable(evaluator):
        return dict(evaluator(str(generated_dir), str(reference_root) if reference_root else None, runs=runs, mmodality_runs=mmodality_runs))
    raise RuntimeError('The evaluator module must expose evaluate, compute_metrics, build_evaluator, Evaluator, or be callable')

def _motion_contact_map(motion: np.ndarray, mask: np.ndarray | None=None, threshold: float=0.12) -> np.ndarray:
    motion = np.asarray(motion, dtype=np.float32)
    if motion.ndim != 3 or motion.shape[1] < 3:
        return np.zeros((motion.shape[0], min(2, motion.shape[1]), 1), dtype=np.float32)
    usable = min(motion.shape[-1] // 3 * 3, 22 * 3)
    if usable < 3:
        return np.zeros((motion.shape[0], 2, 1), dtype=np.float32)
    pts = motion[..., :usable].reshape(motion.shape[0], motion.shape[1], usable // 3, 3)
    human_count = min(2, motion.shape[1] - 1)
    obj_idx = motion.shape[1] - 1
    maps = []
    for h in range(human_count):
        if mask is not None and (mask[h] < 0.5 or mask[obj_idx] < 0.5):
            maps.append(np.zeros((motion.shape[0], 1), dtype=np.float32))
            continue
        d = np.linalg.norm(pts[:, h, :, None, :] - pts[:, obj_idx, None, :, :], axis=-1).min(axis=(1, 2))
        maps.append((d < threshold).astype(np.float32)[:, None])
    return np.stack(maps, axis=1).astype(np.float32)

def _cacc(pred: np.ndarray, ref: np.ndarray, pred_contact: np.ndarray | None, ref_contact: np.ndarray | None, mask: np.ndarray | None=None) -> float:
    pc = np.asarray(pred_contact, dtype=np.float32) if pred_contact is not None else _motion_contact_map(pred, mask)
    rc = np.asarray(ref_contact, dtype=np.float32) if ref_contact is not None else _motion_contact_map(ref, mask)
    n = min(pc.shape[0], rc.shape[0])
    h = min(pc.shape[1], rc.shape[1]) if pc.ndim > 1 and rc.ndim > 1 else 1
    o = min(pc.shape[2], rc.shape[2]) if pc.ndim > 2 and rc.ndim > 2 else 1
    pc = pc[:n].reshape(n, h, -1)[..., :o] >= 0.5
    rc = rc[:n].reshape(n, h, -1)[..., :o] >= 0.5
    return float((pc == rc).mean() * 100.0)

def eval_generated(generated_dir: str | Path, reference_root: str | Path | None=None, evaluator_module: str | Path | None=None, allow_proxy: bool=False, runs: int=20, mmodality_runs: int=5) -> dict[str, Any]:
    generated_dir = Path(generated_dir)
    evaluator = load_evaluator(evaluator_module)
    files = sorted(generated_dir.glob('*.npz'))
    if not files:
        raise FileNotFoundError(f'No npz files found in {generated_dir}')
    official_summary: dict[str, Any] = {}
    if evaluator is not None:
        official_summary = run_external_evaluator(evaluator, generated_dir, reference_root, runs, mmodality_runs)
    elif not allow_proxy:
        raise RuntimeError('Text-conditioned metrics require the official evaluator module. Pass --evaluator-module for paper metrics or --allow-proxy for smoke tests only.')
    ref_index = index_reference(reference_root)
    rows: list[dict[str, Any]] = []
    motions: list[np.ndarray] = []
    captions: list[str] = []
    ref_motions: list[np.ndarray] = []
    l2_values: list[float] = []
    vel_values: list[float] = []
    rrje_values: list[float] = []
    rrve_values: list[float] = []
    cacc_values: list[float] = []
    contact_rates: list[float] = []
    min_dists: list[float] = []
    grouped: dict[str, list[np.ndarray]] = {}
    for path in files:
        data = load_npz(path)
        motion = np.asarray(data['motion'], dtype=np.float32)
        mask = np.asarray(data.get('entity_mask', np.ones(motion.shape[1], dtype=np.float32)), dtype=np.float32)
        caption = _scalar_text(data.get('caption', path.stem))
        sample_id = _scalar_text(data.get('sample_id', path.stem))
        csum = contact_summary(motion, mask)
        row: dict[str, Any] = {'file': path.name, 'sample_id': sample_id, 'caption': caption, 'contact_rate': csum['contact_rate'], 'min_distance': csum['min_distance']}
        contact_rates.append(csum['contact_rate'])
        min_dists.append(csum['min_distance'])
        motions.append(motion)
        captions.append(caption)
        grouped.setdefault(caption, []).append(motion)
        ref_path = ref_index.get(sample_id) or ref_index.get(caption)
        if ref_path is not None:
            ref = load_npz(ref_path)
            ref_motion = np.asarray(ref['motion'], dtype=np.float32)
            n = min(motion.shape[0], ref_motion.shape[0])
            e = min(motion.shape[1], ref_motion.shape[1])
            f = min(motion.shape[2], ref_motion.shape[2])
            pred = motion[:n, :e, :f]
            gt = ref_motion[:n, :e, :f]
            m = mask[:e]
            row['reference_motion_l2'] = motion_l2(pred, gt, m)
            row['reference_velocity_l2'] = velocity_l2(pred, gt, m)
            row['RR.Je_mm'] = rr_je(pred, gt, m)
            row['RR.Ve_mm'] = rr_ve(pred, gt, m)
            pred_contact = np.asarray(data['contact_map'], dtype=np.float32) if 'contact_map' in data else None
            ref_contact = np.asarray(ref['contact_map'], dtype=np.float32) if 'contact_map' in ref else None
            row['Cacc_percent'] = _cacc(pred, gt, pred_contact, ref_contact, m)
            l2_values.append(row['reference_motion_l2'])
            vel_values.append(row['reference_velocity_l2'])
            rrje_values.append(row['RR.Je_mm'])
            rrve_values.append(row['RR.Ve_mm'])
            cacc_values.append(row['Cacc_percent'])
            ref_motions.append(gt)
        rows.append(row)
    summary: dict[str, Any] = {'num_files': len(files), 'rows': rows, 'official_metric_runs': int(runs), 'official_mmodality_runs': int(mmodality_runs)}
    summary.update(official_summary)
    if allow_proxy:
        from collage_motion.models.text import HashTextEncoder
        same_shape = len({m.shape for m in motions}) == 1
        gen_emb = motion_embeddings(motions)
        text_emb = HashTextEncoder(dim=gen_emb.shape[1]).encode(captions).numpy()
        summary.update({'proxy_Diversity': diversity(np.stack(motions, axis=0)) if same_shape else float('nan'), 'proxy_MModality': multimodality(grouped), 'proxy_MM_Dist': multimodal_distance(gen_emb, text_emb)})
        summary.update({f'proxy_{k}': v for k, v in r_precision(gen_emb, text_emb, top_k=(1, 2, 3)).items()})
        if ref_motions:
            ref_emb = motion_embeddings(ref_motions)
            n = min(len(ref_emb), len(gen_emb))
            summary['proxy_FID'] = frechet_distance(ref_emb[:n], gen_emb[:n])
    summary['mean_contact_rate'] = float(np.mean(contact_rates)) if contact_rates else 0.0
    summary['mean_min_distance'] = float(np.mean(min_dists)) if min_dists else 0.0
    if ref_motions:
        summary['mean_reference_motion_l2'] = float(np.mean(l2_values))
        summary['mean_reference_velocity_l2'] = float(np.mean(vel_values))
        summary['RR.Je_mm'] = float(np.mean(rrje_values))
        summary['RR.Ve_mm'] = float(np.mean(rrve_values))
        summary['Cacc_percent'] = float(np.mean(cacc_values))
        for name, vals in [('RR.Je_mm', rrje_values), ('RR.Ve_mm', rrve_values), ('Cacc_percent', cacc_values)]:
            _, ci = confidence_interval(vals)
            summary[f'{name}_95ci'] = ci
    else:
        summary['mean_reference_motion_l2'] = None
        summary['mean_reference_velocity_l2'] = None
        summary['RR.Je_mm'] = None
        summary['RR.Ve_mm'] = None
        summary['Cacc_percent'] = None
    for name, vals in [('mean_contact_rate', contact_rates), ('mean_min_distance', min_dists)]:
        _, ci = confidence_interval(vals)
        summary[f'{name}_95ci'] = ci
    return summary

def write_outputs(summary: dict[str, Any], out_json: str | Path, out_csv: str | Path | None=None) -> None:
    out_json = Path(out_json)
    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding='utf-8')
    if out_csv:
        rows = summary.get('rows', [])
        if rows:
            keys = sorted(set().union(*(r.keys() for r in rows)))
            with Path(out_csv).open('w', encoding='utf-8', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=keys)
                writer.writeheader()
                writer.writerows(rows)

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--generated-dir', required=True)
    parser.add_argument('--reference-root')
    parser.add_argument('--out-json', required=True)
    parser.add_argument('--out-csv')
    parser.add_argument('--evaluator-module')
    parser.add_argument('--allow-proxy', action='store_true')
    parser.add_argument('--runs', type=int, default=20)
    parser.add_argument('--mmodality-runs', type=int, default=5)
    args = parser.parse_args()
    summary = eval_generated(args.generated_dir, args.reference_root, args.evaluator_module, args.allow_proxy, args.runs, args.mmodality_runs)
    write_outputs(summary, args.out_json, args.out_csv)
    printable = {k: v for k, v in summary.items() if k != 'rows'}
    print(json.dumps(printable, indent=2, ensure_ascii=False))
if __name__ == '__main__':
    main()
