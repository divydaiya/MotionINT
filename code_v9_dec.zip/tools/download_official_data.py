from __future__ import annotations
import argparse
import shutil
import subprocess
import sys
from pathlib import Path
CORE4D_HOMEPAGE = 'https://core4d.github.io/'
CORE4D_GITHUB = 'https://github.com/leolyliu/CORE4D-Instructions'
CORE4D_HF_REPO = 'leolyliu/CORE4D'
CORE4D_HF_URL = 'https://huggingface.co/datasets/leolyliu/CORE4D'
INTERHUMAN_HOMEPAGE = 'https://tr3e.github.io/intergen-page/'
INTERHUMAN_GITHUB = 'https://github.com/tr3e/intergen'
INTERHUMAN_DRIVE_URL = 'https://drive.google.com/drive/folders/1oyozJ4E7Sqgsr7Q747Na35tWo5CjNYk3?usp=sharing'

def print_links() -> None:
    print('Official sources:')
    print(f'CORE4D homepage: {CORE4D_HOMEPAGE}')
    print(f'CORE4D code/docs: {CORE4D_GITHUB}')
    print(f'CORE4D Hugging Face dataset: {CORE4D_HF_URL}')
    print(f'InterHuman homepage: {INTERHUMAN_HOMEPAGE}')
    print(f'InterGen/InterHuman code/docs: {INTERHUMAN_GITHUB}')
    print(f'InterHuman Google Drive: {INTERHUMAN_DRIVE_URL}')

def download_core4d(out_root: Path, token: str | None, revision: str, allow_patterns: list[str] | None, ignore_patterns: list[str] | None) -> None:
    try:
        from huggingface_hub import snapshot_download
    except ImportError as exc:
        raise SystemExit('Install with: pip install huggingface_hub') from exc
    dst = out_root / 'CORE4D'
    dst.mkdir(parents=True, exist_ok=True)
    path = snapshot_download(repo_id=CORE4D_HF_REPO, repo_type='dataset', revision=revision, local_dir=str(dst), local_dir_use_symlinks=False, token=token, allow_patterns=allow_patterns or None, ignore_patterns=ignore_patterns or None)
    print(f'CORE4D downloaded to {path}')

def download_interhuman(out_root: Path, url: str) -> None:
    dst = out_root / 'InterHuman'
    dst.mkdir(parents=True, exist_ok=True)
    exe = shutil.which('gdown')
    if exe is None:
        raise SystemExit(f'gdown is required for Google Drive folder download. Install with `pip install gdown`, or manually download InterHuman from {url} and place it under {dst}.')
    subprocess.check_call([exe, '--folder', url, '-O', str(dst)])
    print(f'InterHuman downloaded to {dst}')

def main() -> None:
    parser = argparse.ArgumentParser(description='collage')
    parser.add_argument('--dataset', choices=['core4d', 'interhuman', 'both', 'links'], default='links')
    parser.add_argument('--out-root', default='/data', help='Destination root; subfolders CORE4D and InterHuman are created.')
    parser.add_argument('--hf-token', default=None, help='Optional Hugging Face token.')
    parser.add_argument('--revision', default='main')
    parser.add_argument('--allow-pattern', action='append', default=[], help='CORE4D Hugging Face allow pattern, repeatable. Example: CORE4D_Real_human_object_motions_v2/*')
    parser.add_argument('--ignore-pattern', action='append', default=[], help='CORE4D Hugging Face ignore pattern, repeatable.')
    parser.add_argument('--interhuman-drive-url', default=INTERHUMAN_DRIVE_URL)
    args = parser.parse_args()
    print_links()
    if args.dataset == 'links':
        return
    out_root = Path(args.out_root).expanduser().resolve()
    out_root.mkdir(parents=True, exist_ok=True)
    if args.dataset in {'core4d', 'both'}:
        download_core4d(out_root, args.hf_token, args.revision, args.allow_pattern, args.ignore_pattern)
    if args.dataset in {'interhuman', 'both'}:
        download_interhuman(out_root, args.interhuman_drive_url)
if __name__ == '__main__':
    main()
