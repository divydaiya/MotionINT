from __future__ import annotations
import argparse
from contextlib import nullcontext
from pathlib import Path
from typing import Any
import torch
from torch.utils.data import DataLoader
from collage_motion.data.dataset import MotionTextDataset, collate_motion_text
from collage_motion.models.h_vqvae import HierarchicalVQVAE, VQVAELossWeights
from collage_motion.models.planner import PlanEncoder
from collage_motion.training.train_utils import count_parameters, create_run_dir, cycle, load_checkpoint, log_dict, make_optimizer, save_checkpoint, walltime, cosine_lr
from collage_motion.utils.config import apply_cli_overrides, load_config, to_plain_dict
from collage_motion.utils.seed import seed_everything

def build_model(cfg: Any) -> HierarchicalVQVAE:
    return HierarchicalVQVAE(input_dim=int(cfg.model.input_dim), latent_dim=int(cfg.model.get('latent_dim', 512)), hidden_dim=int(cfg.model.get('hidden_dim', cfg.model.get('latent_dim', 512))), text_dim=int(cfg.model.get('text_dim', 512)), num_entities=int(cfg.model.get('num_entities', 3)), num_humans=int(cfg.model.get('num_humans', 2)), num_objects=cfg.model.get('num_objects'), num_levels=int(cfg.model.get('num_levels', 6)), codebook_size=int(cfg.model.get('codebook_size', 512)), conv_depth=int(cfg.model.get('conv_depth', 2)), attn_heads=int(cfg.model.get('attn_heads', 8)), dropout=float(cfg.model.get('dropout', 0.0)), ema_decay=float(cfg.model.get('ema_decay', 0.99)))

def make_loader(cfg: Any, split: str, shuffle: bool) -> DataLoader:
    ds = MotionTextDataset(cfg.data_root, split=split, seq_len=int(cfg.seq_len), stats_path=cfg.get('stats_path'), random_crop=shuffle, normalize=True)
    return DataLoader(ds, batch_size=int(cfg.batch_size), shuffle=shuffle, num_workers=int(cfg.get('num_workers', 0)), pin_memory=torch.cuda.is_available(), drop_last=shuffle and len(ds) >= int(cfg.batch_size), collate_fn=collate_motion_text)

@torch.no_grad()
def validate(model: HierarchicalVQVAE, loader: DataLoader, plan: PlanEncoder, weights: VQVAELossWeights, device: torch.device, max_batches: int=16) -> dict[str, float]:
    model.eval()
    totals: dict[str, float] = {}
    counts = 0
    for batch_idx, batch in enumerate(loader):
        if batch_idx >= max_batches:
            break
        motion = batch['motion'].to(device)
        entity_mask = batch['entity_mask'].to(device)
        frame_mask = batch['frame_mask'].to(device)
        entity_type = batch['entity_type'].to(device)
        cues = plan.encode(batch['caption'], device=device)
        entity_cues = plan.encode_entities(batch['caption'], device=device)
        optional = {k: batch[k].to(device) for k in ('human_vertices', 'object_vertices', 'contact_map', 'signed_distance') if k in batch}
        out = model(motion, cues, entity_mask=entity_mask, entity_types=entity_type, entity_cues=entity_cues)
        losses = model.compute_loss(motion, out, cues, entity_mask, frame_mask, weights, entity_types=entity_type, entity_cues=entity_cues, **optional)
        n = motion.shape[0]
        counts += n
        for k, v in losses.items():
            totals[k] = totals.get(k, 0.0) + float(v.detach().cpu()) * n
    model.train()
    return {k: v / max(counts, 1) for k, v in totals.items()}

def train(cfg: Any) -> None:
    threads = int(cfg.get('torch_num_threads', 0) or 0)
    if threads > 0:
        torch.set_num_threads(threads)
        try:
            torch.set_num_interop_threads(max(1, min(threads, 4)))
        except RuntimeError:
            pass
    seed_everything(int(cfg.get('seed', 1234)))
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    run_dir, writer = create_run_dir(cfg.run_dir, to_plain_dict(cfg))
    train_loader = make_loader(cfg, cfg.get('split', 'train'), shuffle=True)
    val_loader = make_loader(cfg, cfg.get('val_split', 'val'), shuffle=False)
    plan = PlanEncoder(levels=int(cfg.planner.get('levels', cfg.model.get('num_levels', 6))), text_dim=int(cfg.planner.get('text_dim', cfg.model.get('text_dim', 512))), text_encoder=cfg.planner.get('text_encoder', 'clip'), text_model_name=cfg.planner.get('text_model_name'), plan_cache=cfg.planner.get('plan_cache'), backend=cfg.planner.get('backend', 'cache_or_heuristic'), openai_model=cfg.planner.get('openai_model', 'gpt-4'))
    model = build_model(cfg).to(device)
    optimizer = make_optimizer(model, float(cfg.lr), float(cfg.get('weight_decay', 1e-05)), kind=cfg.get('optimizer', 'adamw'))
    start_step = 0
    if cfg.get('resume'):
        ckpt = load_checkpoint(cfg.resume, model, optimizer, map_location=device)
        start_step = int(ckpt.get('step', 0))
    weights = VQVAELossWeights(**to_plain_dict(cfg.get('loss', {})))
    amp_enabled = bool(cfg.get('amp', False)) and device.type == 'cuda'
    scaler = torch.cuda.amp.GradScaler(enabled=amp_enabled)
    print(f'[{walltime()}] training VQ-VAE on {device}; parameters={count_parameters(model):,}; run_dir={run_dir}')
    iterator = cycle(train_loader)
    best_val = float('inf')
    stage1_steps = int(cfg.max_steps)
    stage2_steps = int(cfg.get('stage2_steps', 0) or 0)
    total_steps = stage1_steps + stage2_steps
    for step in range(start_step + 1, total_steps + 1):
        batch = next(iterator)
        motion = batch['motion'].to(device, non_blocking=True)
        entity_mask = batch['entity_mask'].to(device, non_blocking=True)
        frame_mask = batch['frame_mask'].to(device, non_blocking=True)
        entity_type = batch['entity_type'].to(device, non_blocking=True)
        cues = plan.encode(batch['caption'], device=device)
        entity_cues = plan.encode_entities(batch['caption'], device=device)
        optional = {k: batch[k].to(device, non_blocking=True) for k in ('human_vertices', 'object_vertices', 'contact_map', 'signed_distance') if k in batch}
        if cfg.get('scheduler', 'cosine') == 'cosine':
            cosine_lr(optimizer, step - 1 if step <= stage1_steps else step - stage1_steps - 1, stage1_steps if step <= stage1_steps else max(stage2_steps, 1), float(cfg.lr) if step <= stage1_steps else float(cfg.get('stage2_lr', cfg.get('min_lr', 1e-05))), float(cfg.get('min_lr', 1e-06)) if step <= stage1_steps else float(cfg.get('stage2_min_lr', cfg.get('stage2_lr', 1e-05))), int(cfg.get('warmup_steps', 1000)) if step <= stage1_steps else 0)
        optimizer.zero_grad(set_to_none=True)
        autocast_ctx = torch.autocast(device_type=device.type, dtype=torch.float16, enabled=amp_enabled) if device.type == 'cuda' else nullcontext()
        with autocast_ctx:
            out = model(motion, cues, entity_mask=entity_mask, entity_types=entity_type, entity_cues=entity_cues)
            losses = model.compute_loss(motion, out, cues, entity_mask, frame_mask, weights, entity_types=entity_type, entity_cues=entity_cues, **optional)
        scaler.scale(losses['loss']).backward()
        if float(cfg.get('grad_clip', 0.0)) > 0:
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), float(cfg.grad_clip))
        scaler.step(optimizer)
        scaler.update()
        if step % int(cfg.get('log_every', 50)) == 0 or step == 1:
            metrics = {k: float(v.detach().cpu()) for k, v in losses.items()}
            log_dict(writer, 'train', metrics, step)
            print(f"[{walltime()}] step={step} loss={metrics['loss']:.5f} recon={metrics.get('recon', 0):.5f} ppl={metrics.get('perplexity', 0):.2f}")
        if step % int(cfg.get('val_every', 1000)) == 0 or step == total_steps:
            vals = validate(model, val_loader, plan, weights, device)
            log_dict(writer, 'val', vals, step)
            val_loss = vals.get('loss', float('inf'))
            print(f'[{walltime()}] validation step={step} loss={val_loss:.5f}')
            if val_loss < best_val:
                best_val = val_loss
                save_checkpoint(run_dir / 'checkpoints' / 'best.pt', model, optimizer, step, to_plain_dict(cfg), {'val_loss': best_val})
        if step % int(cfg.get('save_every', 2000)) == 0 or step == total_steps:
            save_checkpoint(run_dir / 'checkpoints' / 'latest.pt', model, optimizer, step, to_plain_dict(cfg))
    writer.close()

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', required=True)
    parser.add_argument('--data-root')
    parser.add_argument('--stats-path')
    parser.add_argument('--run-dir')
    parser.add_argument('--max-steps', type=int)
    parser.add_argument('--batch-size', type=int)
    parser.add_argument('--num-workers', type=int)
    parser.add_argument('--resume')
    parser.add_argument('--plan-cache')
    args = parser.parse_args()
    cfg = load_config(args.config)
    cfg = apply_cli_overrides(cfg, {'data_root': args.data_root, 'stats_path': args.stats_path, 'run_dir': args.run_dir, 'max_steps': args.max_steps, 'batch_size': args.batch_size, 'num_workers': args.num_workers, 'resume': args.resume, 'planner.plan_cache': args.plan_cache})
    train(cfg)
if __name__ == '__main__':
    main()
