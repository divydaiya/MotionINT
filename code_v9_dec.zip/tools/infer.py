from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
from typing import Any
import numpy as np
import torch
from collage_motion.models.association import CodeCueAssociation
from collage_motion.models.diffusion import DiffusionConfig, LatentDenoiserUNet, LatentDiffusion
from collage_motion.models.h_vqvae import HierarchicalVQVAE
from collage_motion.models.planner import PlanEncoder
from collage_motion.training.train_utils import load_checkpoint, walltime
from collage_motion.utils.config import apply_cli_overrides, load_config
from collage_motion.utils.io import atomic_np_savez, write_jsonl
from collage_motion.utils.seed import seed_everything


def cfgv(cfg: Any, key: str, default: Any=None) -> Any:
    if key in cfg:
        return cfg[key]
    if 'model' in cfg and key in cfg.model:
        return cfg.model[key]
    return default


def build_vqvae(cfg: Any) -> HierarchicalVQVAE:
    return HierarchicalVQVAE(input_dim=int(cfgv(cfg, 'input_dim', cfgv(cfg, 'feature_dim', 512))), latent_dim=int(cfgv(cfg, 'latent_dim', 512)), hidden_dim=int(cfgv(cfg, 'hidden_dim', cfgv(cfg, 'latent_dim', 512))), text_dim=int(cfgv(cfg, 'text_dim', 512)), num_entities=int(cfgv(cfg, 'num_entities', 3)), num_humans=int(cfgv(cfg, 'num_humans', 2)), num_objects=cfgv(cfg, 'num_objects'), num_levels=int(cfgv(cfg, 'num_levels', 6)), codebook_size=int(cfgv(cfg, 'codebook_size', 512)), conv_depth=int(cfgv(cfg, 'conv_depth', 2)), attn_heads=int(cfgv(cfg, 'attn_heads', 8)), dropout=float(cfgv(cfg, 'dropout', 0.0)))


def build_diffusion(cfg: Any) -> LatentDiffusion:
    denoiser = LatentDenoiserUNet(latent_dim=int(cfgv(cfg, 'latent_dim', 512)), hidden_dim=int(cfgv(cfg, 'hidden_dim', cfgv(cfg, 'latent_dim', 512))), text_dim=int(cfgv(cfg, 'text_dim', 512)), num_levels=int(cfgv(cfg, 'num_levels', 6)), mm_blocks=int(cfgv(cfg, 'mm_blocks', 4)), attn_heads=int(cfgv(cfg, 'attn_heads', 8)), dropout=float(cfgv(cfg, 'dropout', 0.0)))
    steps = int(cfgv(cfg, 'diffusion_steps', 1000))
    beta_schedule = cfgv(cfg, 'beta_schedule', 'cosine')
    if 'diffusion' in cfg:
        steps = int(cfg.diffusion.get('steps', steps))
        beta_schedule = cfg.diffusion.get('beta_schedule', beta_schedule)
    return LatentDiffusion(denoiser, DiffusionConfig(steps=steps, beta_schedule=beta_schedule, cond_drop_prob=0.0))


def build_assoc(cfg: Any) -> CodeCueAssociation:
    return CodeCueAssociation(num_levels=int(cfgv(cfg, 'num_levels', 6)), latent_dim=int(cfgv(cfg, 'latent_dim', 512)), text_dim=int(cfgv(cfg, 'text_dim', 512)), projection_dim=int(cfgv(cfg, 'projection_dim', cfgv(cfg, 'text_dim', 512))), top_k=int(cfgv(cfg, 'top_k', 8)), temperature=float(cfgv(cfg, 'temperature', 0.07)))


def read_caption_file(path: str | Path) -> list[str]:
    path = Path(path)
    text = path.read_text(encoding='utf-8-sig').strip()
    if not text:
        return []
    if path.suffix.lower() == '.csv':
        captions: list[str] = []
        with path.open('r', encoding='utf-8-sig', newline='') as f:
            reader = csv.DictReader(f)
            if reader.fieldnames:
                desc_key = None
                for name in reader.fieldnames:
                    if name.strip().lower() in {'description', 'caption', 'text', 'prompt'}:
                        desc_key = name
                        break
                if desc_key is not None:
                    for row in reader:
                        if row.get(desc_key, '').strip():
                            captions.append(row[desc_key].strip())
                    return captions
        return [line.strip() for line in text.splitlines() if line.strip()]
    return [line.strip() for line in text.splitlines() if line.strip()]


def denormalize(motion: np.ndarray, stats_path: str | Path | None) -> np.ndarray:
    if not stats_path or not Path(stats_path).exists():
        return motion
    stats = np.load(stats_path)
    mean = stats['mean'].astype(np.float32).reshape(1, 1, -1)
    std = stats['std'].astype(np.float32).reshape(1, 1, -1)
    return motion * std + mean


def normalize_motion(motion: np.ndarray, stats_path: str | Path | None) -> np.ndarray:
    if not stats_path or not Path(stats_path).exists():
        return motion
    stats = np.load(stats_path)
    mean = stats['mean'].astype(np.float32).reshape(1, 1, -1)
    std = stats['std'].astype(np.float32).reshape(1, 1, -1)
    return (motion - mean) / std


def fit_time_feature(arr: np.ndarray, seq_len: int, feature_dim: int) -> np.ndarray:
    arr = np.asarray(arr, dtype=np.float32)
    if arr.ndim > 2:
        arr = arr.reshape(arr.shape[0], -1)
    if arr.shape[0] > seq_len:
        arr = arr[:seq_len]
    elif arr.shape[0] < seq_len:
        arr = np.concatenate([arr, np.zeros((seq_len - arr.shape[0], arr.shape[1]), dtype=np.float32)], axis=0)
    if arr.shape[1] > feature_dim:
        arr = arr[:, :feature_dim]
    elif arr.shape[1] < feature_dim:
        arr = np.concatenate([arr, np.zeros((arr.shape[0], feature_dim - arr.shape[1]), dtype=np.float32)], axis=1)
    return arr.astype(np.float32)


def read_object_conditioning(path: str | Path, seq_len: int, num_humans: int, feature_dim: int) -> np.ndarray:
    data = np.load(path, allow_pickle=True)
    if isinstance(data, np.lib.npyio.NpzFile):
        for key in ('object_motion', 'object_geometry', 'object', 'object_poses', 'object_vertices'):
            if key in data.files:
                return fit_time_feature(np.asarray(data[key]), seq_len, feature_dim)
        if 'motion' in data.files:
            motion = np.asarray(data['motion'], dtype=np.float32)
            if motion.ndim == 3 and motion.shape[1] > num_humans:
                return fit_time_feature(motion[:, num_humans], seq_len, feature_dim)
            return fit_time_feature(motion, seq_len, feature_dim)
    return fit_time_feature(np.asarray(data), seq_len, feature_dim)


@torch.no_grad()
def generate(cfg: Any, captions: list[str], out_dir: str | Path) -> list[dict[str, Any]]:
    threads = int(cfg.get('torch_num_threads', 0) or 0)
    if threads > 0:
        torch.set_num_threads(threads)
        try:
            torch.set_num_interop_threads(max(1, min(threads, 4)))
        except RuntimeError:
            pass
    seed_everything(int(cfg.get('seed', 1234)))
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    vqvae = build_vqvae(cfg).to(device)
    diffusion = build_diffusion(cfg).to(device)
    load_checkpoint(cfg.vqvae_ckpt, vqvae, map_location=device)
    load_checkpoint(cfg.diffusion_ckpt, diffusion, map_location=device)
    vqvae.eval()
    diffusion.eval()
    assoc = None
    if cfg.get('assoc_ckpt') and Path(cfg.assoc_ckpt).exists():
        assoc = build_assoc(cfg).to(device)
        load_checkpoint(cfg.assoc_ckpt, assoc, map_location=device)
        assoc.eval()
    elif not bool(cfg.get('allow_missing_assoc', False)):
        raise FileNotFoundError('Association checkpoint is required for paper-faithful COLLAGE inference. Set assoc_ckpt or allow_missing_assoc=true.')
    planner_cfg = cfg.get('planner', {})
    plan = PlanEncoder(levels=int(planner_cfg.get('levels', cfgv(cfg, 'num_levels', 6))), text_dim=int(planner_cfg.get('text_dim', cfgv(cfg, 'text_dim', 512))), text_encoder=planner_cfg.get('text_encoder', 'clip'), text_model_name=planner_cfg.get('text_model_name'), plan_cache=planner_cfg.get('plan_cache'), backend=planner_cfg.get('backend', 'cache_or_heuristic'), openai_model=planner_cfg.get('openai_model', 'gpt-4'))
    seq_len = int(cfgv(cfg, 'seq_len', 196))
    num_entities = int(cfgv(cfg, 'num_entities', 3))
    num_humans = int(cfgv(cfg, 'num_humans', 2))
    num_objects = int(cfgv(cfg, 'num_objects', max(0, num_entities - num_humans)))
    latent_dim = int(cfgv(cfg, 'latent_dim', 512))
    feature_dim = int(cfgv(cfg, 'feature_dim', cfgv(cfg, 'input_dim', 512)))
    sample_steps = int(cfg.get('sample_steps', 55))
    sampler = cfg.get('sampler', 'ddim')
    guidance = float(cfg.get('guidance_scale', 1.0))
    num_samples = int(cfg.get('num_samples', 1))
    object_path = cfg.get('object_conditioning') or cfg.get('object_motion') or cfg.get('object_geometry')
    object_motion_raw = read_object_conditioning(object_path, seq_len, num_humans, feature_dim) if object_path else None
    rows: list[dict[str, Any]] = []
    print(f'[{walltime()}] generating {len(captions) * num_samples} motion samples on {device}')
    for cidx, caption in enumerate(captions):
        for sample_idx in range(num_samples):
            cues = plan.encode_entity_tensor([caption], num_humans=num_humans, num_objects=num_objects, device=device)
            if assoc is not None:
                codebooks = {k: [x.detach() for x in v] for k, v in vqvae.codebooks().items()}
                cues = assoc.augment_cues(cues, codebooks)
            entity_mask = torch.ones(1, num_entities, device=device)
            entity_type = vqvae.default_entity_types(1, device)
            adjacency = (entity_mask[:, :, None] > 0.5) & (entity_mask[:, None, :] > 0.5)
            conditioning_latent = None
            conditioning_mask = None
            if object_motion_raw is not None and num_objects > 0:
                cond_motion_np = np.zeros((1, seq_len, num_entities, feature_dim), dtype=np.float32)
                cond_motion_np[0, :, num_humans, :] = object_motion_raw
                cond_motion_np = normalize_motion(cond_motion_np[0], cfg.get('stats_path'))[None]
                cond_motion = torch.from_numpy(cond_motion_np).to(device)
                cond_cues = plan.encode([caption], device=device)
                cond_entity_cues = plan.encode_entities([caption], device=device)
                enc_cond = vqvae.encode(cond_motion, cond_cues, entity_mask=entity_mask, entity_types=entity_type, entity_cues=cond_entity_cues)
                conditioning_latent = enc_cond['latent']
                conditioning_mask = torch.zeros(1, seq_len, num_entities, device=device)
                conditioning_mask[:, :, num_humans:num_humans + num_objects] = 1.0
            latent = diffusion.sample(shape=(1, seq_len, num_entities, latent_dim), cues=cues, entity_mask=entity_mask, sample_steps=sample_steps, sampler=sampler, guidance_scale=guidance, adjacency=adjacency, conditioning_latent=conditioning_latent, conditioning_mask=conditioning_mask)
            recon = vqvae.decode_latent(latent, entity_mask=entity_mask, entity_types=entity_type)[0].detach().cpu().numpy().astype(np.float32)
            recon = denormalize(recon, cfg.get('stats_path'))
            if object_motion_raw is not None and num_objects > 0:
                recon[:, num_humans, :] = object_motion_raw
            sample_id = f'gen_{cidx:05d}_{sample_idx:03d}'
            path = out_dir / f'{sample_id}.npz'
            raw_plans = plan.plans([caption])[0]
            save_kwargs = dict(motion=recon, latent=latent[0].detach().cpu().numpy().astype(np.float32), entity_mask=np.ones(num_entities, dtype=np.float32), entity_type=entity_type[0].detach().cpu().numpy().astype(np.int64), length=np.array([seq_len], dtype=np.int32), caption=np.array(caption), sample_id=np.array(sample_id), plans=np.array(json.dumps(raw_plans, ensure_ascii=False)), source=np.array('generated'))
            if object_path:
                save_kwargs['object_conditioning'] = np.array(str(object_path))
            atomic_np_savez(path, **save_kwargs)
            if bool(cfg.get('render', False)):
                from collage_motion.utils.visualization import render_motion
                render_motion(recon, out_dir / f'{sample_id}.gif', np.ones(num_entities, dtype=np.float32), fps=int(cfg.get('render_fps', 15)))
            rows.append({'sample_id': sample_id, 'path': path.name, 'caption': caption, 'length': seq_len, 'num_entities': num_entities, 'feature_dim': recon.shape[-1], 'object_conditioned': bool(object_path)})
            print(f'[{walltime()}] wrote {path}')
    write_jsonl(rows, out_dir / 'metadata.jsonl')
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', required=True)
    parser.add_argument('--caption')
    parser.add_argument('--caption-file')
    parser.add_argument('--out-dir', required=True)
    parser.add_argument('--vqvae-ckpt')
    parser.add_argument('--diffusion-ckpt')
    parser.add_argument('--assoc-ckpt')
    parser.add_argument('--stats-path')
    parser.add_argument('--num-samples', type=int)
    parser.add_argument('--sample-steps', type=int)
    parser.add_argument('--guidance-scale', type=float)
    parser.add_argument('--seed', type=int)
    parser.add_argument('--render', action='store_true')
    parser.add_argument('--plan-cache')
    parser.add_argument('--object-conditioning')
    parser.add_argument('--object-motion')
    args = parser.parse_args()
    captions: list[str] = []
    if args.caption:
        captions.append(args.caption)
    if args.caption_file:
        captions.extend(read_caption_file(args.caption_file))
    if not captions:
        raise SystemExit('Provide --caption or --caption-file')
    cfg = apply_cli_overrides(load_config(args.config), {'vqvae_ckpt': args.vqvae_ckpt, 'diffusion_ckpt': args.diffusion_ckpt, 'assoc_ckpt': args.assoc_ckpt, 'stats_path': args.stats_path, 'num_samples': args.num_samples, 'sample_steps': args.sample_steps, 'guidance_scale': args.guidance_scale, 'seed': args.seed, 'render': True if args.render else None, 'planner.plan_cache': args.plan_cache, 'object_conditioning': args.object_conditioning, 'object_motion': args.object_motion})
    generate(cfg, captions, args.out_dir)


if __name__ == '__main__':
    main()
