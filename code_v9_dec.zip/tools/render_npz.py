from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
from collage_motion.utils.visualization import render_motion

def render_one(path: Path, out_dir: Path, fps: int, every: int) -> Path:
    data = np.load(path, allow_pickle=True)
    motion = data['motion'].astype(np.float32)
    mask = data['entity_mask'].astype(np.float32) if 'entity_mask' in data.files else np.ones(motion.shape[1], dtype=np.float32)
    out_path = out_dir / f'{path.stem}.gif'
    render_motion(motion, out_path, mask, fps=fps, every=every)
    return out_path

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True, help='A .npz file or directory containing .npz files')
    parser.add_argument('--out-dir', required=True)
    parser.add_argument('--fps', type=int, default=15)
    parser.add_argument('--every', type=int, default=1)
    args = parser.parse_args()
    inp = Path(args.input)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    files = [inp] if inp.is_file() else sorted(inp.glob('*.npz'))
    if not files:
        raise FileNotFoundError(f'No .npz files found at {inp}')
    for path in files:
        out = render_one(path, out_dir, args.fps, args.every)
        print(out)
if __name__ == '__main__':
    main()
