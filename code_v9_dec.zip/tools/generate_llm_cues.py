from __future__ import annotations
import argparse
import csv
from pathlib import Path
from typing import Any
from tqdm import tqdm
from collage_motion.llm.local_planner import LLMPlannerConfig, LocalLLMPlanner
from collage_motion.llm.openai_planner import OpenAIPlanner, OpenAIPlannerConfig
from collage_motion.llm.plan_schema import normalize_plan_record
from collage_motion.models.planner import HierarchicalPlanner
from collage_motion.utils.io import append_jsonl, read_jsonl

def _first_present(row: dict[str, Any], keys: tuple[str, ...]) -> str | None:
    for key in keys:
        if key in row and row[key] is not None and str(row[key]).strip():
            return str(row[key]).strip()
    return None

def read_caption_rows(path: str | Path) -> list[dict[str, str | None]]:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(path)
    suffix = path.suffix.lower()
    rows: list[dict[str, str | None]] = []
    if suffix == '.csv':
        with path.open('r', encoding='utf-8-sig', newline='') as f:
            reader = csv.DictReader(f)
            if reader.fieldnames is None:
                raise ValueError(f'CSV has no header: {path}')
            for row in reader:
                caption = _first_present(row, ('Description', 'description', 'caption', 'Caption', 'text', 'prompt'))
                if not caption:
                    continue
                motion_id = _first_present(row, ('motion_number', 'Motion Number', 'motion_id', 'id', 'sample_id', 'sequence'))
                rows.append({'motion_number': motion_id, 'caption': caption})
        return rows
    if suffix == '.jsonl':
        for row in read_jsonl(path):
            caption = _first_present(row, ('caption', 'Description', 'description', 'text', 'prompt'))
            if not caption:
                continue
            motion_id = _first_present(row, ('motion_number', 'motion_id', 'id', 'sample_id', 'sequence_id'))
            rows.append({'motion_number': motion_id, 'caption': caption})
        return rows
    with path.open('r', encoding='utf-8-sig') as f:
        for idx, line in enumerate(f):
            caption = line.strip()
            if caption:
                rows.append({'motion_number': str(idx), 'caption': caption})
    return rows

def existing_keys(path: str | Path) -> set[tuple[str | None, str]]:
    keys: set[tuple[str | None, str]] = set()
    for row in read_jsonl(path):
        caption = str(row.get('caption') or row.get('description') or '').strip()
        if not caption:
            continue
        motion_id = row.get('motion_number') or row.get('motion_id') or row.get('sample_id')
        keys.add((None if motion_id is None else str(motion_id), caption))
    return keys

def heuristic_fallback(caption: str, motion_id: str | None, levels: int, model_id: str) -> dict[str, Any]:
    planner = HierarchicalPlanner(levels=levels)
    record = planner.record_one(caption)
    record['motion_number'] = motion_id
    record['motion_id'] = motion_id
    record['model_id'] = f'{model_id}:heuristic_fallback'
    return record

def build_planner(args: argparse.Namespace):
    if args.backend == 'openai':
        return OpenAIPlanner(OpenAIPlannerConfig(model=args.openai_model, api_key_env=args.api_key_env, base_url_env=args.base_url_env, base_url=args.base_url, temperature=args.temperature, max_tokens=args.max_new_tokens, levels=args.levels, timeout=args.timeout))
    if args.backend == 'local':
        cfg = LLMPlannerConfig(model_path=args.model_path, model_id=args.model_id, levels=args.levels, max_new_tokens=args.max_new_tokens, temperature=args.temperature, top_p=args.top_p, repetition_penalty=args.repetition_penalty, torch_dtype=args.torch_dtype, device_map=None if args.device_map.lower() in {'none', 'cpu'} else args.device_map, trust_remote_code=args.trust_remote_code, load_in_4bit=args.load_in_4bit, load_in_8bit=args.load_in_8bit)
        return LocalLLMPlanner(cfg)
    return None

def main() -> None:
    parser = argparse.ArgumentParser(description='Generate COLLAGE Fig. 2 hierarchical LLM cues.')
    parser.add_argument('--input', required=True, help='Caption CSV, processed metadata JSONL, or one-caption-per-line TXT.')
    parser.add_argument('--output', required=True, help='Output JSONL cue cache.')
    parser.add_argument('--backend', choices=['openai', 'local', 'heuristic'], default='openai')
    parser.add_argument('--openai-model', default='gpt-4', help='OpenAI/API-compatible model for paper-style cue generation.')
    parser.add_argument('--api-key-env', default='OPENAI_API_KEY', help='Environment variable containing the API key.')
    parser.add_argument('--base-url-env', default='OPENAI_BASE_URL', help='Optional environment variable for OpenAI-compatible base URL.')
    parser.add_argument('--base-url', default=None, help='Optional OpenAI-compatible endpoint URL; overrides --base-url-env.')
    parser.add_argument('--timeout', type=float, default=60.0)
    parser.add_argument('--model-path', default='llm_models/qwen2_5_7b_instruct', help='Local model directory for --backend local.')
    parser.add_argument('--model-id', default='Qwen/Qwen2.5-7B-Instruct', help='Local model metadata id.')
    parser.add_argument('--levels', type=int, default=6)
    parser.add_argument('--max-new-tokens', type=int, default=900)
    parser.add_argument('--temperature', type=float, default=0.0)
    parser.add_argument('--top-p', type=float, default=0.95)
    parser.add_argument('--repetition-penalty', type=float, default=1.05)
    parser.add_argument('--torch-dtype', default='auto', choices=['auto', 'bf16', 'bfloat16', 'fp16', 'float16', 'fp32', 'float32'])
    parser.add_argument('--device-map', default='auto')
    parser.add_argument('--trust-remote-code', action='store_true')
    parser.add_argument('--load-in-4bit', action='store_true')
    parser.add_argument('--load-in-8bit', action='store_true')
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--retry', type=int, default=1)
    parser.add_argument('--limit', type=int, default=0)
    parser.add_argument('--allow-heuristic-fallback', action='store_true')
    args = parser.parse_args()
    rows = read_caption_rows(args.input)
    if args.limit > 0:
        rows = rows[:args.limit]
    if not rows:
        raise SystemExit(f'No captions found in {args.input}')
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    seen = existing_keys(out_path) if args.resume else set()
    planner = build_planner(args)
    wrote = 0
    for row in tqdm(rows, desc='LLM cue generation'):
        motion_id = row.get('motion_number')
        caption = str(row['caption'])
        if (motion_id, caption) in seen:
            continue
        try:
            if planner is None:
                record = heuristic_fallback(caption, motion_id, args.levels, 'heuristic')
            else:
                record = planner.plan(caption=caption, motion_id=motion_id, retry=args.retry)
        except Exception:
            if not args.allow_heuristic_fallback:
                raise
            record = heuristic_fallback(caption, motion_id, args.levels, args.backend)
        record = normalize_plan_record(record.get('llm_plan', record), caption=caption, motion_id=motion_id, levels=args.levels, model_id=record.get('model_id') or args.backend)
        append_jsonl(record, out_path)
        wrote += 1
    print(f'Wrote {wrote} new cue records to {out_path}')
if __name__ == '__main__':
    main()
